import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { SITE } from "@/lib/site";

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  title: { default: "Paroles Inspirées — Média chrétien francophone", template: "%s — Paroles Inspirées" },
  description: SITE.tagline,
  openGraph: { siteName: SITE.name, locale: "fr_FR", type: "website" },
};

export const viewport: Viewport = { themeColor: "#04326E" };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fr">
      <body className="bg-white font-sans text-ink antialiased">{children}</body>
    </html>
  );
}
