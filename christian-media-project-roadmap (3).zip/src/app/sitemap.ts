import type { MetadataRoute } from "next";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { contents, shows } from "@/db/schema";
import { isPublished } from "@/lib/queries";
import { SECTIONS, SITE, contentHref } from "@/lib/site";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = SITE.url.replace(/\/$/, "");
  const statics = ["", "/evenements", "/a-propos", "/contact", "/newsletter", "/mentions-legales", "/confidentialite",
    ...Object.values(SECTIONS).map((s) => `/${s.slug}`)];
  const items = await db
    .select({ type: contents.type, slug: contents.slug, updatedAt: contents.updatedAt })
    .from(contents).where(isPublished()).orderBy(desc(contents.publishedAt));
  const showList = await db.select({ slug: shows.slug }).from(shows);
  return [
    ...statics.map((p) => ({ url: `${base}${p}` })),
    ...items.map((i) => ({ url: `${base}${contentHref(i)}`, lastModified: i.updatedAt })),
    ...showList.map((s) => ({ url: `${base}/emissions/${s.slug}` })),
  ];
}
