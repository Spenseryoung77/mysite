import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export default function NotFound() {
  return (
    <>
      <Header />
      <main id="contenu" className="container-pi py-24 text-center">
        <p className="text-sm font-bold uppercase tracking-widest text-brand">Erreur 404</p>
        <h1 className="mt-2 font-display text-4xl font-black">Page introuvable</h1>
        <p className="mt-4 text-slate-600">Cette page n’existe pas ou n’est plus disponible.</p>
        <form action="/recherche" className="mx-auto mt-8 flex max-w-md gap-2">
          <label htmlFor="q404" className="sr-only">Rechercher</label>
          <input id="q404" name="q" type="search" placeholder="Rechercher…" className="input flex-1" />
          <button className="btn-primary">Rechercher</button>
        </form>
        <Link href="/" className="link mt-6 inline-block">Retour à l’accueil</Link>
      </main>
      <Footer />
    </>
  );
}
