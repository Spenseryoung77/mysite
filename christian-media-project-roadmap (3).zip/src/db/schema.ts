import {
  boolean,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  // admin | editor | writer | media
  role: text("role").notNull().default("writer"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(),
  userId: integer("user_id").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});

export const authors = pgTable("authors", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  title: text("title"),
  bio: text("bio"),
  photoUrl: text("photo_url"),
});

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  // section : actualite | foi | meditation | temoignage | episode
  section: text("section").notNull(),
  description: text("description"),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const shows = pgTable("shows", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  description: text("description"),
  host: text("host"),
  // video | podcast
  format: text("format").notNull().default("video"),
  imageUrl: text("image_url"),
});

export const contents = pgTable("contents", {
  id: serial("id").primaryKey(),
  // actualite | foi | meditation | temoignage | episode
  type: text("type").notNull(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  excerpt: text("excerpt"),
  body: text("body").notNull().default(""),
  // brouillon | relecture | valide | publie | archive
  status: text("status").notNull().default("brouillon"),
  publishedAt: timestamp("published_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  createdById: integer("created_by_id"),
  authorId: integer("author_id"),
  categoryId: integer("category_id"),
  showId: integer("show_id"),
  imageUrl: text("image_url"),
  imageAlt: text("image_alt"),
  imageCredit: text("image_credit"),
  sources: text("sources"),
  correction: text("correction"),
  // fait | opinion | enseignement | sponsorise
  nature: text("nature").notNull().default("fait"),
  bibleRef: text("bible_ref"),
  bibleTranslation: text("bible_translation"),
  prayer: text("prayer"),
  // texte | video | audio
  mediaFormat: text("media_format").notNull().default("texte"),
  mediaUrl: text("media_url"),
  duration: text("duration"),
  transcript: text("transcript"),
  anonymized: boolean("anonymized").notNull().default(false),
  consentVerified: boolean("consent_verified").notNull().default(false),
  seoTitle: text("seo_title"),
  seoDescription: text("seo_description"),
});

export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  description: text("description"),
  startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
  timezone: text("timezone").notNull().default("Europe/Paris"),
  location: text("location"),
  onlineUrl: text("online_url"),
  organizer: text("organizer"),
  contact: text("contact"),
  registrationUrl: text("registration_url"),
  isOrganizer: boolean("is_organizer").notNull().default(false),
  // actif | annule | archive
  status: text("status").notNull().default("actif"),
  published: boolean("published").notNull().default(true),
});

export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject"),
  message: text("message").notNull(),
  handled: boolean("handled").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const testimonySubmissions = pgTable("testimony_submissions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  title: text("title").notNull(),
  story: text("story").notNull(),
  wantsAnonymity: boolean("wants_anonymity").notNull().default(false),
  consent: boolean("consent").notNull().default(false),
  // nouveau | en_cours | retenu | refuse
  status: text("status").notNull().default("nouveau"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const subscribers = pgTable("subscribers", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  token: text("token").notNull(),
  confirmed: boolean("confirmed").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  confirmedAt: timestamp("confirmed_at", { withTimezone: true }),
});

export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
});

export type Content = typeof contents.$inferSelect;
export type User = typeof users.$inferSelect;
export type Author = typeof authors.$inferSelect;
export type Category = typeof categories.$inferSelect;
export type Show = typeof shows.$inferSelect;
export type EventRow = typeof events.$inferSelect;
