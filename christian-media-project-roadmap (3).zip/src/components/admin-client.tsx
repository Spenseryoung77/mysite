"use client";

import { useActionState, type ReactNode } from "react";
import { useFormStatus } from "react-dom";
import { loginAction, saveContentAction } from "@/app/admin/actions";

export function LoginForm() {
  const [state, action, pending] = useActionState(loginAction, null);
  return (
    <form action={action} className="space-y-4">
      <div><label htmlFor="email" className="label">E-mail</label><input id="email" name="email" type="email" required autoComplete="username" className="input w-full" /></div>
      <div><label htmlFor="password" className="label">Mot de passe</label><input id="password" name="password" type="password" required autoComplete="current-password" className="input w-full" /></div>
      {state && !state.ok && <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-800">{state.message}</p>}
      <button disabled={pending} className="btn-primary w-full">{pending ? "Connexion…" : "Se connecter"}</button>
    </form>
  );
}

export function ContentFormShell({ children }: { children: ReactNode }) {
  const [state, action, pending] = useActionState(saveContentAction, null);
  return (
    <form action={action} className="space-y-6">
      {state && !state.ok && <p role="alert" className="sticky top-2 z-10 rounded-lg border border-red-200 bg-red-50 p-3 text-sm font-semibold text-red-800">{state.message}</p>}
      {children}
      <div className="sticky bottom-0 -mx-4 flex gap-3 border-t border-slate-200 bg-white/95 px-4 py-3">
        <button disabled={pending} className="btn-primary">{pending ? "Enregistrement…" : "Enregistrer"}</button>
      </div>
    </form>
  );
}

export function ConfirmSubmit({ children, message, className = "btn-danger" }: { children: ReactNode; message: string; className?: string }) {
  const { pending } = useFormStatus();
  return (
    <button
      disabled={pending}
      className={className}
      onClick={(e) => { if (!confirm(message)) e.preventDefault(); }}
    >
      {children}
    </button>
  );
}
