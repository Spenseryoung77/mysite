import Link from "next/link";
import type { ReactNode } from "react";
import type { Card } from "@/lib/queries";
import { NATURES, SECTIONS, contentHref, formatDate, type ContentType } from "@/lib/site";
import { Flame } from "@/components/Logo";

export function Badge({ children, tone = "brand" }: { children: ReactNode; tone?: "brand" | "amber" | "slate" }) {
  const cls = {
    brand: "bg-brand-50 text-brand",
    amber: "bg-amber-100 text-amber-900",
    slate: "bg-slate-100 text-slate-700",
  }[tone];
  return <span className={`inline-block rounded-md px-2 py-0.5 text-xs font-bold uppercase tracking-wide ${cls}`}>{children}</span>;
}

export function NatureBadge({ nature }: { nature: string }) {
  if (nature === "fait") return null;
  return <Badge tone={nature === "opinion" || nature === "sponsorise" ? "amber" : "slate"}>{NATURES[nature as keyof typeof NATURES] ?? nature}</Badge>;
}

export function Thumb({ src, alt, className = "" }: { src: string | null; alt: string | null; className?: string }) {
  if (!src)
    return (
      <div className={`flex items-center justify-center bg-gradient-to-br from-brand to-brand-700 text-white/80 ${className}`} aria-hidden="true">
        <Flame className="h-12 w-10" />
      </div>
    );
  // eslint-disable-next-line @next/next/no-img-element
  return <img src={src} alt={alt ?? ""} loading="lazy" decoding="async" className={`object-cover ${className}`} />;
}

export function ContentCard({ item, showSection = false }: { item: Card; showSection?: boolean }) {
  const href = contentHref(item);
  return (
    <article className="group relative flex flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white transition hover:shadow-md">
      <Thumb src={item.imageUrl} alt={item.imageAlt} className="aspect-[16/9] w-full" />
      <div className="flex flex-1 flex-col p-5">
        <div className="flex flex-wrap items-center gap-2">
          {showSection && <Badge>{SECTIONS[item.type as ContentType]?.label}</Badge>}
          {item.categoryName && <Badge tone="slate">{item.categoryName}</Badge>}
          {item.mediaFormat !== "texte" && <Badge tone="slate">{item.mediaFormat === "video" ? "Vidéo" : "Audio"}{item.duration ? ` · ${item.duration}` : ""}</Badge>}
          <NatureBadge nature={item.nature} />
        </div>
        <h3 className="mt-3 font-display text-lg font-bold leading-snug text-ink">
          <Link href={href} className="after:absolute after:inset-0 group-hover:underline decoration-2 underline-offset-4">
            {item.title}
          </Link>
        </h3>
        {item.bibleRef && <p className="mt-1 text-sm font-semibold text-brand">{item.bibleRef}</p>}
        {item.excerpt && <p className="mt-2 line-clamp-3 text-sm text-slate-600">{item.excerpt}</p>}
        <p className="mt-auto pt-4 text-xs text-slate-500">
          <time dateTime={item.publishedAt?.toISOString()}>{formatDate(item.publishedAt)}</time>
          {item.authorName && !item.anonymized ? ` · ${item.authorName}` : ""}
        </p>
      </div>
    </article>
  );
}

export function CardGrid({ items, showSection }: { items: Card[]; showSection?: boolean }) {
  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {items.map((i) => <ContentCard key={i.id} item={i} showSection={showSection} />)}
    </div>
  );
}

function inline(text: string): ReactNode[] {
  const parts = text.split(/(\*\*[^*]+\*\*|\[[^\]]+\]\([^)]+\))/g);
  return parts.map((p, i) => {
    if (p.startsWith("**") && p.endsWith("**")) return <strong key={i}>{p.slice(2, -2)}</strong>;
    const m = p.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
    if (m && /^(https?:\/\/|\/)/.test(m[2])) return <a key={i} href={m[2]} className="link">{m[1]}</a>;
    return p;
  });
}

/** Rendu simple et sûr : paragraphes, ## titres, > citations, - listes, **gras**, [liens](url) */
export function Prose({ text }: { text: string }) {
  const blocks = text.replace(/\r/g, "").split(/\n{2,}/).map((b) => b.trim()).filter(Boolean);
  return (
    <div className="prose-pi">
      {blocks.map((b, i) => {
        if (b.startsWith("## ")) return <h2 key={i}>{b.slice(3)}</h2>;
        if (b.startsWith("### ")) return <h3 key={i}>{b.slice(4)}</h3>;
        if (b.startsWith("> ")) return <blockquote key={i}>{inline(b.replace(/^> ?/gm, ""))}</blockquote>;
        if (/^- /.test(b))
          return <ul key={i}>{b.split("\n").map((l, j) => <li key={j}>{inline(l.replace(/^- /, ""))}</li>)}</ul>;
        return <p key={i}>{inline(b)}</p>;
      })}
    </div>
  );
}

export function PageHero({ title, description, kicker }: { title: string; description?: string; kicker?: string }) {
  return (
    <section className="bg-brand-50">
      <div className="container-pi py-12 md:py-16">
        {kicker && <p className="text-sm font-bold uppercase tracking-widest text-brand">{kicker}</p>}
        <h1 className="mt-1 font-display text-3xl font-black text-ink md:text-5xl">{title}</h1>
        {description && <p className="mt-3 max-w-2xl text-lg text-slate-700">{description}</p>}
      </div>
    </section>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center text-slate-600">{children}</div>;
}

export function Breadcrumbs({ items }: { items: { href?: string; label: string }[] }) {
  return (
    <nav aria-label="Fil d’Ariane" className="text-sm text-slate-600">
      <ol className="flex flex-wrap items-center gap-1">
        {items.map((it, i) => (
          <li key={i} className="flex items-center gap-1">
            {i > 0 && <span aria-hidden="true">›</span>}
            {it.href ? <Link href={it.href} className="link">{it.label}</Link> : <span aria-current="page">{it.label}</span>}
          </li>
        ))}
      </ol>
    </nav>
  );
}
