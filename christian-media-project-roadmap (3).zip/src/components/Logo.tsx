export function Flame({ className = "h-7 w-7" }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 40" className={className} aria-hidden="true" fill="currentColor">
      <path d="M16 1c1.6 6.2-1.4 9.3-4.3 12.6C8.8 16.9 6 20.2 6 25.6 6 32.4 10.6 38 16 38s10-5.2 10-11.7c0-4.6-2-8-4.3-10.5.3 2.8-.6 5.2-2.6 6.3.7-5.8-1.3-12.6-3.1-21.1zm.4 22.3c3.2 2.8 4.6 5.2 4.6 7.7 0 3-2.2 5-5 5s-5-2-5-4.8c0-3 2.3-4.6 4.4-6.3.8 1.4.8 2.7.4 4 1.5-.9 2.2-3 .6-5.6z" />
    </svg>
  );
}

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <span className="inline-flex items-center gap-2.5 rounded-xl bg-brand px-3 py-2 text-white">
      <Flame className="h-7 w-6 shrink-0" />
      <span className={`font-display font-black uppercase leading-[0.95] tracking-wide ${compact ? "text-xs" : "text-sm"}`}>
        Paroles
        <br />
        Inspirées
      </span>
    </span>
  );
}
