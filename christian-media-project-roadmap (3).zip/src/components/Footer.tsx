import Link from "next/link";
import { Logo } from "@/components/Logo";
import { NewsletterForm } from "@/components/NewsletterForm";
import { SITE } from "@/lib/site";

export function Footer() {
  return (
    <footer className="mt-20 bg-brand text-white">
      <div className="container-pi grid gap-10 py-14 md:grid-cols-4">
        <div className="md:col-span-1">
          <Link href="/" aria-label="Paroles Inspirées — accueil" className="inline-block rounded-xl ring-1 ring-white/30">
            <Logo />
          </Link>
          <p className="mt-4 text-sm text-blue-100">{SITE.tagline}</p>
        </div>
        <div>
          <h2 className="font-display text-sm font-bold uppercase tracking-wider">Rubriques</h2>
          <ul className="mt-3 space-y-2 text-sm">
            {[
              ["/actualites", "Actualités"],
              ["/foi-bible", "Foi & Bible"],
              ["/meditations", "Méditations"],
              ["/temoignages", "Témoignages"],
              ["/videos", "Vidéos & podcasts"],
              ["/evenements", "Événements"],
            ].map(([h, l]) => (
              <li key={h}><Link className="link-light" href={h}>{l}</Link></li>
            ))}
          </ul>
        </div>
        <div>
          <h2 className="font-display text-sm font-bold uppercase tracking-wider">Le média</h2>
          <ul className="mt-3 space-y-2 text-sm">
            {[
              ["/a-propos", "À propos & équipe"],
              ["/a-propos#charte", "Charte éditoriale"],
              ["/contact", "Contact"],
              ["/proposer-un-temoignage", "Proposer un témoignage"],
              ["/mentions-legales", "Mentions légales & conditions"],
              ["/confidentialite", "Politique de confidentialité"],
            ].map(([h, l]) => (
              <li key={h}><Link className="link-light" href={h}>{l}</Link></li>
            ))}
          </ul>
        </div>
        <div>
          <h2 className="font-display text-sm font-bold uppercase tracking-wider">Newsletter</h2>
          <p className="mt-3 text-sm text-blue-100">Recevez les nouvelles publications. Désinscription possible à tout moment.</p>
          <div className="mt-3"><NewsletterForm dark /></div>
        </div>
      </div>
      <div className="border-t border-white/15">
        <div className="container-pi flex flex-col justify-between gap-2 py-5 text-xs text-blue-100 sm:flex-row">
          <p>© {new Date().getFullYear()} Paroles Inspirées. Tous droits réservés.</p>
          <p>Citations bibliques : Louis Segond 1910 (domaine public), sauf mention contraire.</p>
        </div>
      </div>
    </footer>
  );
}
