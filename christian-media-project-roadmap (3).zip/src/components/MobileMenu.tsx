"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { NAV } from "@/lib/site";

export function MobileMenu() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  useEffect(() => setOpen(false), [pathname]);

  return (
    <div className="lg:hidden">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        aria-controls="menu-mobile"
        className="btn-ghost px-3"
      >
        <span className="sr-only">{open ? "Fermer le menu" : "Ouvrir le menu"}</span>
        <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
          {open ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
        </svg>
      </button>
      {open && (
        <nav id="menu-mobile" aria-label="Menu mobile" className="absolute inset-x-0 top-full z-40 border-b border-slate-200 bg-white shadow-lg">
          <form action="/recherche" className="flex gap-2 p-4">
            <label htmlFor="q-mobile" className="sr-only">Rechercher</label>
            <input id="q-mobile" name="q" type="search" placeholder="Rechercher…" className="input flex-1" />
            <button className="btn-primary">OK</button>
          </form>
          <ul className="pb-4">
            {NAV.map((n) => (
              <li key={n.href}>
                <Link
                  href={n.href}
                  aria-current={pathname === n.href ? "page" : undefined}
                  className="block px-5 py-3 text-base font-semibold text-ink hover:bg-brand-50 aria-[current=page]:text-brand"
                >
                  {n.label}
                </Link>
              </li>
            ))}
            <li className="px-5 pt-2">
              <Link href="/newsletter" className="btn-primary w-full">S’abonner à la newsletter</Link>
            </li>
          </ul>
        </nav>
      )}
    </div>
  );
}
