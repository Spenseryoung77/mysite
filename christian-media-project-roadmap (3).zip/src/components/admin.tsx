import type { ReactNode } from "react";
import { STATUSES, type Status } from "@/lib/site";

export function StatusPill({ status, publishedAt }: { status: string; publishedAt: Date | null }) {
  const scheduled = status === "publie" && publishedAt && publishedAt > new Date();
  const label = scheduled ? "Programmé" : status === "publie" ? "Publié" : STATUSES[status as Status] ?? status;
  const cls = scheduled
    ? "bg-purple-100 text-purple-900"
    : ({
        brouillon: "bg-slate-100 text-slate-700",
        relecture: "bg-amber-100 text-amber-900",
        valide: "bg-blue-100 text-blue-900",
        publie: "bg-green-100 text-green-900",
        archive: "bg-slate-200 text-slate-600",
      } as Record<string, string>)[status] ?? "bg-slate-100";
  return <span className={`inline-block rounded px-2 py-0.5 text-xs font-bold ${cls}`}>{label}</span>;
}

export function Field({ label, htmlFor, help, children }: { label: string; htmlFor: string; help?: string; children: ReactNode }) {
  return (
    <div>
      <label htmlFor={htmlFor} className="label">{label}</label>
      {children}
      {help && <p className="mt-1 text-xs text-slate-500">{help}</p>}
    </div>
  );
}

export function Fieldset({ legend, children }: { legend: string; children: ReactNode }) {
  return (
    <fieldset className="card space-y-4">
      <legend className="px-1 font-display text-base font-black">{legend}</legend>
      {children}
    </fieldset>
  );
}

export function Flash({ ok, err, okMsg = "Modifications enregistrées.", errMsg = "Une erreur est survenue. Vérifiez les champs." }: { ok?: string; err?: string; okMsg?: string; errMsg?: string }) {
  if (ok) return <p role="status" className="rounded-lg bg-green-50 p-3 text-sm text-green-900">{okMsg}</p>;
  if (err) return <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-800">{errMsg}</p>;
  return null;
}

export function toLocalInput(d: Date | null | undefined) {
  if (!d) return "";
  const off = d.getTimezoneOffset();
  return new Date(d.getTime() - off * 60000).toISOString().slice(0, 16);
}
