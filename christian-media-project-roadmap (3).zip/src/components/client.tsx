"use client";

import { useState } from "react";

export function ShareButtons({ url, title }: { url: string; title: string }) {
  const [copied, setCopied] = useState(false);
  const full = typeof window !== "undefined" ? new URL(url, window.location.origin).toString() : url;
  const enc = encodeURIComponent(full);
  const t = encodeURIComponent(title);
  return (
    <div className="flex flex-wrap items-center gap-2" aria-label="Partager">
      <span className="text-sm font-semibold text-slate-700">Partager :</span>
      <button
        type="button"
        className="btn-ghost text-sm"
        onClick={async () => {
          if (navigator.share) {
            try { await navigator.share({ title, url: full }); return; } catch { /* annulé */ }
          }
          await navigator.clipboard.writeText(full);
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
        }}
      >
        {copied ? "Lien copié ✓" : "Copier le lien"}
      </button>
      <a className="btn-ghost text-sm" href={`https://wa.me/?text=${t}%20${enc}`} target="_blank" rel="noopener noreferrer">WhatsApp</a>
      <a className="btn-ghost text-sm" href={`https://www.facebook.com/sharer/sharer.php?u=${enc}`} target="_blank" rel="noopener noreferrer">Facebook</a>
      <a className="btn-ghost text-sm" href={`mailto:?subject=${t}&body=${enc}`}>E-mail</a>
    </div>
  );
}

function embedUrl(url: string): string | null {
  try {
    const u = new URL(url);
    if (u.hostname.includes("youtube.com")) {
      const id = u.searchParams.get("v") || u.pathname.split("/").pop();
      return id ? `https://www.youtube-nocookie.com/embed/${id}` : null;
    }
    if (u.hostname === "youtu.be") return `https://www.youtube-nocookie.com/embed${u.pathname}`;
    if (u.hostname.includes("vimeo.com")) return `https://player.vimeo.com/video/${u.pathname.split("/").filter(Boolean).pop()}`;
    if (u.hostname.includes("spotify.com")) return url.replace("open.spotify.com/", "open.spotify.com/embed/");
    return null;
  } catch {
    return null;
  }
}

export function MediaPlayer({ url, title, format }: { url: string; title: string; format: string }) {
  const [active, setActive] = useState(false);
  const isAudioFile = /\.(mp3|m4a|ogg|wav)(\?|$)/i.test(url);
  const isVideoFile = /\.(mp4|webm)(\?|$)/i.test(url);
  const embed = embedUrl(url);

  if (!embed && !isAudioFile && !isVideoFile) {
    return (
      <a href={url} target="_blank" rel="noopener noreferrer" className="btn-primary">
        {format === "audio" ? "Écouter" : "Regarder"} sur la plateforme officielle ↗
      </a>
    );
  }

  if (!active) {
    return (
      <button
        type="button"
        onClick={() => setActive(true)}
        className="flex aspect-video w-full flex-col items-center justify-center gap-3 rounded-2xl bg-gradient-to-br from-brand to-brand-700 text-white"
      >
        <span className="flex h-16 w-16 items-center justify-center rounded-full bg-white text-brand">
          <svg viewBox="0 0 24 24" className="ml-1 h-7 w-7" fill="currentColor" aria-hidden="true"><path d="M8 5v14l11-7z" /></svg>
        </span>
        <span className="font-semibold">{format === "audio" ? "Lancer l’écoute" : "Charger la vidéo"}</span>
        <span className="text-xs text-blue-100">Le lecteur se charge uniquement à votre demande.</span>
      </button>
    );
  }
  if (isAudioFile) return <audio controls src={url} className="w-full" />;
  if (isVideoFile) return <video controls src={url} className="w-full rounded-2xl" />;
  return (
    <iframe
      src={embed!}
      title={title}
      className={`${format === "audio" ? "h-40" : "aspect-video"} w-full rounded-2xl`}
      allow="accelerometer; clipboard-write; encrypted-media; picture-in-picture"
      allowFullScreen
    />
  );
}
