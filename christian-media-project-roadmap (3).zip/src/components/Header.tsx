import Link from "next/link";
import { Logo } from "@/components/Logo";
import { MobileMenu } from "@/components/MobileMenu";
import { NAV } from "@/lib/site";

export function Header() {
  return (
    <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur">
      <a href="#contenu" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded focus:bg-white focus:px-4 focus:py-2">
        Aller au contenu
      </a>
      <div className="container-pi relative flex items-center justify-between gap-4 py-3">
        <Link href="/" aria-label="Paroles Inspirées — accueil" className="shrink-0 rounded-xl">
          <Logo />
        </Link>
        <nav aria-label="Menu principal" className="hidden lg:block">
          <ul className="flex items-center gap-1">
            {NAV.slice(1).map((n) => (
              <li key={n.href}>
                <Link href={n.href} className="rounded-lg px-2.5 py-2 text-sm font-semibold text-ink hover:bg-brand-50 hover:text-brand">
                  {n.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        <div className="flex items-center gap-2">
          <Link href="/recherche" className="btn-ghost hidden px-3 sm:inline-flex" aria-label="Rechercher">
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
              <circle cx="11" cy="11" r="7" /><path d="M20 20l-3.5-3.5" />
            </svg>
          </Link>
          <Link href="/newsletter" className="btn-primary hidden sm:inline-flex">S’abonner</Link>
          <MobileMenu />
        </div>
      </div>
    </header>
  );
}
