import Link from "next/link";
import type { ContentDetail } from "@/lib/queries";
import type { Card } from "@/lib/queries";
import { Badge, Breadcrumbs, CardGrid, NatureBadge, Prose, Thumb } from "@/components/content";
import { MediaPlayer, ShareButtons } from "@/components/client";
import { SECTIONS, contentHref, formatDate, type ContentType } from "@/lib/site";

export function ContentDetailView({ data, relatedItems }: { data: ContentDetail; relatedItems: Card[] }) {
  const { c, author, category, show } = data;
  const section = SECTIONS[c.type as ContentType];
  const updated = c.publishedAt && c.updatedAt.getTime() - c.publishedAt.getTime() > 60 * 60 * 1000;
  const authorLabel = c.type === "temoignage" && c.anonymized ? "Témoignage anonymisé" : author?.name;

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": c.type === "actualite" ? "NewsArticle" : c.type === "episode" ? "CreativeWork" : "Article",
    headline: c.title,
    datePublished: c.publishedAt?.toISOString(),
    dateModified: c.updatedAt.toISOString(),
    author: author ? { "@type": "Person", name: author.name } : undefined,
    image: c.imageUrl ?? undefined,
    publisher: { "@type": "Organization", name: "Paroles Inspirées" },
  };

  return (
    <article>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <header className="bg-brand-50">
        <div className="container-pi max-w-4xl py-10 md:py-14">
          <Breadcrumbs items={[{ href: "/", label: "Accueil" }, { href: `/${section.slug}`, label: section.label }, { label: c.title }]} />
          <div className="mt-5 flex flex-wrap items-center gap-2">
            <Badge>{section.singular}</Badge>
            {category && <Link href={`/${section.slug}?categorie=${category.slug}`}><Badge tone="slate">{category.name}</Badge></Link>}
            <NatureBadge nature={c.nature} />
            {c.mediaFormat !== "texte" && <Badge tone="slate">{c.mediaFormat === "video" ? "Vidéo" : "Audio"}</Badge>}
          </div>
          <h1 className="mt-3 font-display text-3xl font-black leading-tight text-ink md:text-5xl">{c.title}</h1>
          {c.excerpt && <p className="mt-4 text-xl text-slate-700">{c.excerpt}</p>}
          <p className="mt-5 text-sm text-slate-600">
            {authorLabel && (author && !(c.type === "temoignage" && c.anonymized) ? <>Par <Link className="link" href={`/auteurs/${author.slug}`}>{authorLabel}</Link></> : authorLabel)}
            {c.publishedAt && <> · Publié le <time dateTime={c.publishedAt.toISOString()}>{formatDate(c.publishedAt)}</time></>}
            {updated && <> · Mis à jour le <time dateTime={c.updatedAt.toISOString()}>{formatDate(c.updatedAt)}</time></>}
            {c.duration && <> · Durée : {c.duration}</>}
          </p>
          {show && <p className="mt-2 text-sm">Émission : <Link className="link" href={`/emissions/${show.slug}`}>{show.title}</Link></p>}
        </div>
      </header>

      <div className="container-pi max-w-4xl py-10">
        {c.mediaUrl ? (
          <div className="mb-8"><MediaPlayer url={c.mediaUrl} title={c.title} format={c.mediaFormat} /></div>
        ) : c.imageUrl ? (
          <figure className="mb-8">
            <Thumb src={c.imageUrl} alt={c.imageAlt} className="aspect-[16/9] w-full rounded-2xl" />
            {c.imageCredit && <figcaption className="mt-2 text-xs text-slate-500">Crédit photo : {c.imageCredit}</figcaption>}
          </figure>
        ) : null}

        {c.correction && (
          <aside className="mb-8 rounded-xl border-l-4 border-amber-500 bg-amber-50 p-4 text-sm" aria-label="Correction">
            <strong>Correction :</strong> {c.correction}
          </aside>
        )}
        {c.nature === "opinion" && (
          <p className="mb-6 rounded-xl bg-slate-50 p-4 text-sm text-slate-700">Ce texte est une opinion : il engage son auteur et ne reflète pas nécessairement la position de la rédaction.</p>
        )}
        {c.nature === "sponsorise" && (
          <p className="mb-6 rounded-xl bg-amber-50 p-4 text-sm text-amber-900">Contenu sponsorisé, réalisé en partenariat.</p>
        )}

        {c.bibleRef && (
          <p className="mb-6 text-lg font-bold text-brand">
            {c.bibleRef}
            {c.bibleTranslation && <span className="block text-xs font-normal text-slate-500">Traduction : {c.bibleTranslation}</span>}
          </p>
        )}

        <Prose text={c.body} />

        {c.prayer && (
          <section className="mt-10 rounded-2xl bg-brand p-6 text-white md:p-8" aria-labelledby="priere">
            <h2 id="priere" className="font-display text-xl font-black">Prière</h2>
            <p className="mt-3 text-lg italic leading-relaxed">{c.prayer}</p>
          </section>
        )}

        {c.transcript && (
          <details className="mt-10 rounded-2xl border border-slate-200 p-5">
            <summary className="cursor-pointer font-semibold">Transcription</summary>
            <div className="mt-4"><Prose text={c.transcript} /></div>
          </details>
        )}

        {c.sources && (
          <section className="mt-10 rounded-2xl border border-slate-200 p-5 text-sm" aria-labelledby="sources">
            <h2 id="sources" className="font-display font-bold">Sources</h2>
            <ul className="mt-2 list-disc space-y-1 pl-5 text-slate-700">
              {c.sources.split("\n").filter(Boolean).map((s, i) => (
                <li key={i}>{/^https?:\/\//.test(s.trim()) ? <a className="link break-all" href={s.trim()} rel="noopener noreferrer" target="_blank">{s.trim()}</a> : s}</li>
              ))}
            </ul>
          </section>
        )}
        {c.bibleTranslation && !c.bibleRef && <p className="mt-6 text-xs text-slate-500">Citations bibliques : {c.bibleTranslation}</p>}

        <div className="mt-10 border-t border-slate-200 pt-6"><ShareButtons url={contentHref(c)} title={c.title} /></div>

        {author && !(c.type === "temoignage" && c.anonymized) && (
          <div className="mt-8 flex gap-4 rounded-2xl bg-slate-50 p-5">
            <div>
              <p className="font-display font-bold"><Link href={`/auteurs/${author.slug}`} className="link">{author.name}</Link></p>
              {author.title && <p className="text-sm text-slate-600">{author.title}</p>}
              {author.bio && <p className="mt-2 text-sm text-slate-700">{author.bio}</p>}
            </div>
          </div>
        )}
      </div>

      {relatedItems.length > 0 && (
        <section className="container-pi py-6" aria-labelledby="lies">
          <h2 id="lies" className="mb-6 font-display text-2xl font-black">{c.type === "meditation" ? "Méditations proches" : "À lire aussi"}</h2>
          <CardGrid items={relatedItems} />
        </section>
      )}
    </article>
  );
}
