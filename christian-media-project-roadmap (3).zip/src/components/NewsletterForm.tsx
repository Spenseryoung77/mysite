"use client";

import { useActionState, useId } from "react";
import { subscribeAction, contactAction, testimonyAction, type FormState } from "@/app/actions";

function Honeypot() {
  return (
    <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
      <label>Ne pas remplir <input name="website" tabIndex={-1} autoComplete="off" /></label>
    </div>
  );
}

function Feedback({ state, dark }: { state: FormState; dark?: boolean }) {
  if (!state) return null;
  return (
    <div role="status" aria-live="polite" className={`mt-3 rounded-lg p-3 text-sm ${state.ok ? (dark ? "bg-white/10 text-white" : "bg-green-50 text-green-900") : "bg-red-50 text-red-800"}`}>
      {state.message}
      {state.link && (
        <a href={state.link} className={`mt-1 block font-semibold underline ${dark ? "text-white" : "text-brand"}`}>
          Confirmer mon inscription
        </a>
      )}
    </div>
  );
}

export function NewsletterForm({ dark = false }: { dark?: boolean }) {
  const [state, action, pending] = useActionState(subscribeAction, null);
  const id = useId();
  return (
    <form action={action} className="relative">
      <Honeypot />
      <label htmlFor={id} className={`block text-sm font-semibold ${dark ? "text-white" : "text-ink"}`}>Adresse e-mail</label>
      <div className="mt-1 flex flex-col gap-2 sm:flex-row">
        <input id={id} name="email" type="email" required autoComplete="email" placeholder="vous@exemple.fr" className="input flex-1 text-ink" />
        <button disabled={pending} className={dark ? "btn-light" : "btn-primary"}>{pending ? "Envoi…" : "S’abonner"}</button>
      </div>
      <p className={`mt-2 text-xs ${dark ? "text-blue-100" : "text-slate-600"}`}>
        Votre adresse sert uniquement à l’envoi de la newsletter. Double confirmation, désinscription en un clic.
      </p>
      <Feedback state={state} dark={dark} />
    </form>
  );
}

export function ContactForm() {
  const [state, action, pending] = useActionState(contactAction, null);
  if (state?.ok) return <Feedback state={state} />;
  return (
    <form action={action} className="relative space-y-4">
      <Honeypot />
      <div className="grid gap-4 sm:grid-cols-2">
        <div><label htmlFor="c-name" className="label">Nom *</label><input id="c-name" name="name" required className="input w-full" autoComplete="name" /></div>
        <div><label htmlFor="c-email" className="label">E-mail *</label><input id="c-email" name="email" type="email" required className="input w-full" autoComplete="email" /></div>
      </div>
      <div><label htmlFor="c-subject" className="label">Objet</label><input id="c-subject" name="subject" className="input w-full" /></div>
      <div><label htmlFor="c-message" className="label">Message *</label><textarea id="c-message" name="message" required rows={6} minLength={10} className="input w-full" /></div>
      <p className="text-xs text-slate-600">Vos données servent uniquement à répondre à votre message. Aucune inscription automatique à la newsletter.</p>
      <button disabled={pending} className="btn-primary">{pending ? "Envoi…" : "Envoyer le message"}</button>
      <Feedback state={state} />
    </form>
  );
}

export function TestimonyForm() {
  const [state, action, pending] = useActionState(testimonyAction, null);
  if (state?.ok) return <Feedback state={state} />;
  return (
    <form action={action} className="relative space-y-4">
      <Honeypot />
      <div className="grid gap-4 sm:grid-cols-2">
        <div><label htmlFor="t-name" className="label">Prénom et nom *</label><input id="t-name" name="name" required className="input w-full" /></div>
        <div><label htmlFor="t-email" className="label">E-mail *</label><input id="t-email" name="email" type="email" required className="input w-full" /></div>
      </div>
      <div><label htmlFor="t-title" className="label">Titre de votre témoignage *</label><input id="t-title" name="title" required className="input w-full" /></div>
      <div>
        <label htmlFor="t-story" className="label">Votre témoignage *</label>
        <textarea id="t-story" name="story" required rows={8} minLength={50} className="input w-full" aria-describedby="t-story-help" />
        <p id="t-story-help" className="mt-1 text-xs text-slate-600">N’indiquez pas d’informations sur des tiers sans leur accord, ni de données de santé inutiles.</p>
      </div>
      <label className="flex items-start gap-3 text-sm"><input type="checkbox" name="anonymous" className="mt-1 h-4 w-4" /> Je souhaite que mon témoignage soit anonymisé s’il est publié.</label>
      <label className="flex items-start gap-3 text-sm"><input type="checkbox" name="consent" required className="mt-1 h-4 w-4" /> J’accepte que la rédaction lise ma proposition et me recontacte. Je comprends qu’elle ne sera pas publiée sans mon accord explicite. *</label>
      <button disabled={pending} className="btn-primary">{pending ? "Envoi…" : "Envoyer ma proposition"}</button>
      <Feedback state={state} />
    </form>
  );
}
