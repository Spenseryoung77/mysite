export const SITE = {
  name: "Paroles Inspirées",
  tagline: "Média chrétien francophone — s’informer, nourrir sa foi, partager l’espérance.",
  url: process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000",
  contactEmail: "contact@parolesinspirees.org",
};

export type ContentType = "actualite" | "foi" | "meditation" | "temoignage" | "episode";

export const SECTIONS: Record<
  ContentType,
  { slug: string; label: string; singular: string; description: string }
> = {
  actualite: {
    slug: "actualites",
    label: "Actualités",
    singular: "Article",
    description: "Initiatives, vie des Églises et événements chrétiens, vérifiés et sourcés.",
  },
  foi: {
    slug: "foi-bible",
    label: "Foi & Bible",
    singular: "Enseignement",
    description: "Ressources pour découvrir la Bible, la prière et la vie chrétienne.",
  },
  meditation: {
    slug: "meditations",
    label: "Méditations",
    singular: "Méditation",
    description: "Un rendez-vous spirituel régulier : un texte, une réflexion, une prière.",
  },
  temoignage: {
    slug: "temoignages",
    label: "Témoignages",
    singular: "Témoignage",
    description: "Des parcours de foi et des expériences humaines partagés avec respect.",
  },
  episode: {
    slug: "videos",
    label: "Vidéos & podcasts",
    singular: "Épisode",
    description: "Les émissions vidéo et audio de Paroles Inspirées.",
  },
};

export const CONTENT_TYPES = Object.keys(SECTIONS) as ContentType[];

export function typeFromSlug(slug: string): ContentType | null {
  const found = CONTENT_TYPES.find((t) => SECTIONS[t].slug === slug);
  return found ?? null;
}

export function contentHref(c: { type: string; slug: string }) {
  const s = SECTIONS[c.type as ContentType];
  return s ? `/${s.slug}/${c.slug}` : "/";
}

export const NAV = [
  { href: "/", label: "Accueil" },
  { href: "/actualites", label: "Actualités" },
  { href: "/foi-bible", label: "Foi & Bible" },
  { href: "/meditations", label: "Méditations" },
  { href: "/temoignages", label: "Témoignages" },
  { href: "/videos", label: "Vidéos & podcasts" },
  { href: "/evenements", label: "Événements" },
  { href: "/a-propos", label: "À propos" },
];

export const STATUSES = {
  brouillon: "Brouillon",
  relecture: "À relire",
  valide: "Validé",
  publie: "Publié / programmé",
  archive: "Archivé",
} as const;
export type Status = keyof typeof STATUSES;

export const NATURES = {
  fait: "Information",
  enseignement: "Enseignement",
  opinion: "Opinion",
  sponsorise: "Contenu sponsorisé",
} as const;

export const ROLES = {
  admin: "Administrateur",
  editor: "Responsable éditorial",
  writer: "Rédacteur",
  media: "Gestionnaire média",
} as const;
export type Role = keyof typeof ROLES;

export const PERMS = {
  publish: ["admin", "editor"],
  editAll: ["admin", "editor", "media"],
  taxonomy: ["admin", "editor"],
  messages: ["admin", "editor"],
  homepage: ["admin", "editor"],
  events: ["admin", "editor"],
  users: ["admin"],
} as const satisfies Record<string, readonly Role[]>;

export function can(role: string, perm: keyof typeof PERMS) {
  return (PERMS[perm] as readonly string[]).includes(role);
}

export function formatDate(d: Date | string | null | undefined, withTime = false) {
  if (!d) return "";
  const date = typeof d === "string" ? new Date(d) : d;
  return date.toLocaleDateString("fr-FR", {
    day: "numeric",
    month: "long",
    year: "numeric",
    ...(withTime ? { hour: "2-digit", minute: "2-digit" } : {}),
    timeZone: "Europe/Paris",
  });
}

export function slugify(s: string) {
  return s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

export const HOME_SECTIONS = {
  une: "À la une",
  meditation: "Méditation",
  derniers: "Derniers articles",
  media: "À regarder / à écouter",
  temoignage: "Témoignage",
  mission: "Notre mission",
  evenements: "Événements à venir",
  newsletter: "Newsletter",
} as const;
export type HomeSectionKey = keyof typeof HOME_SECTIONS;

export type HomeSettings = {
  order: { key: HomeSectionKey; visible: boolean }[];
  featuredId: number | null;
  testimonyId: number | null;
};

export const DEFAULT_HOME: HomeSettings = {
  order: [
    { key: "une", visible: true },
    { key: "meditation", visible: true },
    { key: "derniers", visible: true },
    { key: "media", visible: true },
    { key: "temoignage", visible: true },
    { key: "mission", visible: true },
    { key: "evenements", visible: true },
    { key: "newsletter", visible: true },
  ],
  featuredId: null,
  testimonyId: null,
};
