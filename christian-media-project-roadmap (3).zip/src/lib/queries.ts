import "server-only";
import { and, asc, desc, eq, gte, ilike, lte, ne, or, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { authors, categories, contents, events, settings, shows } from "@/db/schema";
import { DEFAULT_HOME, type ContentType, type HomeSettings } from "@/lib/site";
import { ensureSeed } from "@/lib/seed";

export const isPublished = () =>
  and(eq(contents.status, "publie"), lte(contents.publishedAt, new Date()));

const cardFields = {
  id: contents.id,
  type: contents.type,
  slug: contents.slug,
  title: contents.title,
  excerpt: contents.excerpt,
  imageUrl: contents.imageUrl,
  imageAlt: contents.imageAlt,
  publishedAt: contents.publishedAt,
  nature: contents.nature,
  mediaFormat: contents.mediaFormat,
  duration: contents.duration,
  bibleRef: contents.bibleRef,
  categoryName: categories.name,
  authorName: authors.name,
  anonymized: contents.anonymized,
};

export type Card = {
  id: number;
  type: string;
  slug: string;
  title: string;
  excerpt: string | null;
  imageUrl: string | null;
  imageAlt: string | null;
  publishedAt: Date | null;
  nature: string;
  mediaFormat: string;
  duration: string | null;
  bibleRef: string | null;
  categoryName: string | null;
  authorName: string | null;
  anonymized: boolean;
};

function cardQuery(where: SQL | undefined) {
  return db
    .select(cardFields)
    .from(contents)
    .leftJoin(categories, eq(categories.id, contents.categoryId))
    .leftJoin(authors, eq(authors.id, contents.authorId))
    .where(where)
    .orderBy(desc(contents.publishedAt));
}

export async function listPublished(opts: {
  type?: ContentType;
  categorySlug?: string;
  showId?: number;
  authorId?: number;
  limit?: number;
  offset?: number;
  excludeId?: number;
}): Promise<{ items: Card[]; total: number }> {
  await ensureSeed();
  const conds: (SQL | undefined)[] = [isPublished()];
  if (opts.type) conds.push(eq(contents.type, opts.type));
  if (opts.showId) conds.push(eq(contents.showId, opts.showId));
  if (opts.authorId) conds.push(eq(contents.authorId, opts.authorId));
  if (opts.excludeId) conds.push(ne(contents.id, opts.excludeId));
  if (opts.categorySlug) conds.push(eq(categories.slug, opts.categorySlug));
  const where = and(...conds);
  const items = await cardQuery(where)
    .limit(opts.limit ?? 12)
    .offset(opts.offset ?? 0);
  const [{ total }] = await db
    .select({ total: sql<number>`count(*)::int` })
    .from(contents)
    .leftJoin(categories, eq(categories.id, contents.categoryId))
    .where(where);
  return { items, total };
}

export async function getPublishedBySlug(type: ContentType, slug: string) {
  await ensureSeed();
  const rows = await db
    .select({ c: contents, author: authors, category: categories, show: shows })
    .from(contents)
    .leftJoin(authors, eq(authors.id, contents.authorId))
    .leftJoin(categories, eq(categories.id, contents.categoryId))
    .leftJoin(shows, eq(shows.id, contents.showId))
    .where(and(eq(contents.type, type), eq(contents.slug, slug), isPublished()))
    .limit(1);
  return rows[0] ?? null;
}

export async function getAnyById(id: number) {
  const rows = await db
    .select({ c: contents, author: authors, category: categories, show: shows })
    .from(contents)
    .leftJoin(authors, eq(authors.id, contents.authorId))
    .leftJoin(categories, eq(categories.id, contents.categoryId))
    .leftJoin(shows, eq(shows.id, contents.showId))
    .where(eq(contents.id, id))
    .limit(1);
  return rows[0] ?? null;
}

export type ContentDetail = NonNullable<Awaited<ReturnType<typeof getAnyById>>>;

export async function related(c: { id: number; type: string; categoryId: number | null }) {
  const conds = [isPublished(), eq(contents.type, c.type), ne(contents.id, c.id)];
  const items = await cardQuery(
    c.categoryId
      ? and(...conds, eq(contents.categoryId, c.categoryId))
      : and(...conds),
  ).limit(3);
  if (items.length >= 2 || !c.categoryId) return items;
  return cardQuery(and(...conds)).limit(3);
}

export async function sectionCategories(type: ContentType) {
  return db
    .select()
    .from(categories)
    .where(eq(categories.section, type))
    .orderBy(asc(categories.sortOrder), asc(categories.name));
}

export async function searchPublished(q: string) {
  await ensureSeed();
  const term = `%${q.replace(/[%_]/g, "")}%`;
  return cardQuery(
    and(
      isPublished(),
      or(
        ilike(contents.title, term),
        ilike(contents.excerpt, term),
        ilike(contents.body, term),
        ilike(contents.bibleRef, term),
      ),
    ),
  ).limit(30);
}

export async function getHomeSettings(): Promise<HomeSettings> {
  await ensureSeed();
  const rows = await db.select().from(settings).where(eq(settings.key, "home")).limit(1);
  const v = rows[0]?.value as Partial<HomeSettings> | undefined;
  if (!v) return DEFAULT_HOME;
  const order = [...(v.order ?? [])];
  for (const d of DEFAULT_HOME.order) if (!order.find((o) => o.key === d.key)) order.push(d);
  return { ...DEFAULT_HOME, ...v, order };
}

export async function upcomingEvents(limit = 20) {
  await ensureSeed();
  return db
    .select()
    .from(events)
    .where(and(eq(events.published, true), ne(events.status, "archive"), gte(events.startsAt, new Date())))
    .orderBy(asc(events.startsAt))
    .limit(limit);
}

export async function pastEvents(limit = 20) {
  return db
    .select()
    .from(events)
    .where(and(eq(events.published, true), lte(events.startsAt, new Date())))
    .orderBy(desc(events.startsAt))
    .limit(limit);
}

export async function showsWithEpisodes() {
  await ensureSeed();
  return db
    .select({
      id: shows.id,
      slug: shows.slug,
      title: shows.title,
      description: shows.description,
      host: shows.host,
      format: shows.format,
      imageUrl: shows.imageUrl,
      episodes: sql<number>`count(${contents.id})::int`,
    })
    .from(shows)
    .innerJoin(contents, and(eq(contents.showId, shows.id), isPublished()))
    .groupBy(shows.id)
    .orderBy(asc(shows.title));
}
