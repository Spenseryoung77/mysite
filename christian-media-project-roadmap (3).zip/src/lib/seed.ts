import "server-only";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { authors, categories, contents, settings, shows, users } from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { DEFAULT_HOME } from "@/lib/site";

let seeding: Promise<void> | null = null;

export function ensureSeed() {
  if (!seeding) {
    seeding = run().catch((e) => {
      seeding = null;
      console.error("Seed error", e);
    });
  }
  return seeding;
}

const day = 24 * 60 * 60 * 1000;
const ago = (n: number) => new Date(Date.now() - n * day);

async function run() {
  const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(users);
  if (count > 0) return;

  await db.insert(users).values({
    name: "Administrateur",
    email: (process.env.ADMIN_EMAIL || "admin@parolesinspirees.org").toLowerCase(),
    passwordHash: hashPassword(process.env.ADMIN_PASSWORD || "ParolesInspirees2026!"),
    role: "admin",
  }).onConflictDoNothing();

  const [redac] = await db
    .insert(authors)
    .values([
      {
        slug: "la-redaction",
        name: "La rédaction",
        title: "Équipe éditoriale de Paroles Inspirées",
        bio: "Les contenus signés « La rédaction » sont préparés et relus collectivement par l’équipe éditoriale de Paroles Inspirées.",
      },
    ])
    .returning();

  const cats = await db
    .insert(categories)
    .values([
      { slug: "vie-des-eglises", name: "Vie des Églises", section: "actualite", sortOrder: 1 },
      { slug: "initiatives-solidaires", name: "Initiatives solidaires", section: "actualite", sortOrder: 2 },
      { slug: "culture-chretienne", name: "Culture chrétienne", section: "actualite", sortOrder: 3 },
      { slug: "societe", name: "Société", section: "actualite", sortOrder: 4 },
      { slug: "bible", name: "Bible", section: "foi", sortOrder: 1 },
      { slug: "priere", name: "Prière", section: "foi", sortOrder: 2 },
      { slug: "vie-chretienne", name: "Vie chrétienne", section: "foi", sortOrder: 3 },
      { slug: "questions-de-foi", name: "Questions de foi", section: "foi", sortOrder: 4 },
    ])
    .returning();
  const cat = (slug: string) => cats.find((c) => c.slug === slug)?.id ?? null;

  const [show] = await db
    .insert(shows)
    .values({
      slug: "la-parole-en-dix-minutes",
      title: "La Parole en dix minutes",
      description: "Une courte émission pour lire et comprendre un passage biblique.",
      host: "La rédaction",
      format: "video",
    })
    .returning();

  const LSG = "Louis Segond 1910 (domaine public)";
  const base = { authorId: redac.id, status: "publie" as const };

  await db.insert(contents).values([
    {
      ...base,
      type: "actualite",
      slug: "paroles-inspirees-un-nouveau-media-chretien-francophone",
      title: "Paroles Inspirées : un nouveau média chrétien francophone",
      excerpt:
        "Actualités, enseignements, méditations, témoignages et émissions : présentation du projet et de ses engagements éditoriaux.",
      body: `Paroles Inspirées naît d’un désir simple : offrir aux lecteurs francophones un lieu pour s’informer, nourrir leur foi et découvrir des témoignages, sur téléphone comme sur ordinateur.

## Ce que vous trouverez ici

Des **actualités** sur les initiatives chrétiennes, des **enseignements** pour découvrir la Bible et la prière, des **méditations** régulières, des **témoignages** partagés avec l’accord des personnes concernées, ainsi que des **vidéos et podcasts**.

## Nos engagements

Chaque article indique son auteur, sa date et ses sources lorsque le sujet l’exige. Les erreurs sont corrigées et signalées. Les enseignements et les opinions sont clairement distingués des informations.

> Le site s’enrichira progressivement : nous préférons publier moins, mais publier juste.

Pour suivre les nouvelles publications, inscrivez-vous à la newsletter.`,
      categoryId: cat("vie-des-eglises"),
      nature: "fait",
      imageUrl: "https://images.pexels.com/photos/16102717/pexels-photo-16102717.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      imageAlt: "Assemblée réunie dans une église",
      imageCredit: "Luis Quintero / Pexels",
      sources: "Communiqué de l’équipe Paroles Inspirées",
      publishedAt: ago(2),
    },
    {
      ...base,
      type: "foi",
      slug: "comment-commencer-a-lire-la-bible",
      title: "Comment commencer à lire la Bible ?",
      excerpt: "Quelques repères simples pour entrer dans la lecture des Écritures, pas à pas.",
      body: `La Bible est une bibliothèque de soixante-six livres écrits sur plusieurs siècles. Il est normal de ne pas savoir par où commencer.

## Commencer par un Évangile

L’Évangile selon Marc est court et vivant. Il permet de découvrir la personne de Jésus, ses paroles et ses actes.

## Lire peu, mais régulièrement

Mieux vaut lire quelques versets chaque jour que de longs passages de temps en temps. Notez une phrase qui vous touche et revenez-y dans la journée.

## Lire avec d’autres

Un groupe de lecture, une Église locale ou un ami peuvent aider à comprendre le contexte d’un passage.

> « Ta parole est une lampe à mes pieds, et une lumière sur mon sentier. » — Psaume 119.105`,
      categoryId: cat("bible"),
      nature: "enseignement",
      bibleRef: "Psaume 119.105",
      bibleTranslation: LSG,
      imageUrl: "https://images.pexels.com/photos/8268309/pexels-photo-8268309.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      imageAlt: "Bible ouverte posée sur une table en bois",
      imageCredit: "Ella Wei / Pexels",
      publishedAt: ago(5),
    },
    {
      ...base,
      type: "foi",
      slug: "la-priere-un-dialogue-simple",
      title: "La prière, un dialogue simple",
      excerpt: "Prier n’est pas réservé aux spécialistes : c’est parler à Dieu avec confiance.",
      body: `Beaucoup pensent qu’il faut des mots compliqués pour prier. Jésus enseigne au contraire la simplicité.

## Le Notre Père comme modèle

Dans Matthieu 6, Jésus donne une prière courte : elle loue Dieu, demande le pain quotidien, le pardon et la protection.

## Quelques pistes

- Prendre un moment calme, même bref.
- Remercier pour une chose précise de la journée.
- Confier une personne ou une situation.
- Écouter, en silence.

> « Quand tu pries, entre dans ta chambre, ferme ta porte, et prie ton Père qui est là dans le lieu secret. » — Matthieu 6.6`,
      categoryId: cat("priere"),
      nature: "enseignement",
      bibleRef: "Matthieu 6.6",
      bibleTranslation: LSG,
      imageUrl: "https://images.pexels.com/photos/8674110/pexels-photo-8674110.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      imageAlt: "Personnes en prière dans une église",
      imageCredit: "RDNE Stock project / Pexels",
      publishedAt: ago(4),
    },
    {
      ...base,
      type: "meditation",
      slug: "venez-a-moi-vous-tous-qui-etes-fatigues",
      title: "Venez à moi, vous tous qui êtes fatigués",
      excerpt: "Une invitation au repos, au cœur de nos journées chargées.",
      body: `« Venez à moi, vous tous qui êtes fatigués et chargés, et je vous donnerai du repos. » — Matthieu 11.28

Nos agendas se remplissent, nos préoccupations s’accumulent. Jésus ne commence pas par nous demander davantage d’efforts : il nous invite à venir.

Venir, c’est déposer. C’est reconnaître que nous ne portons pas tout seuls. Le repos promis n’est pas l’absence de travail, mais une paix intérieure qui naît de la confiance.

Aujourd’hui, quelle charge pourriez-vous lui confier ?`,
      bibleRef: "Matthieu 11.28",
      bibleTranslation: LSG,
      prayer:
        "Seigneur, je viens à toi avec ce qui m’alourdit. Donne-moi ton repos et apprends-moi à marcher avec toi, pas à pas. Amen.",
      nature: "enseignement",
      imageUrl: "https://images.pexels.com/photos/4567409/pexels-photo-4567409.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      imageAlt: "Bible ouverte au sol dans la lumière naturelle",
      imageCredit: "Nothing Ahead / Pexels",
      publishedAt: ago(1),
    },
    {
      ...base,
      type: "meditation",
      slug: "l-eternel-est-mon-berger",
      title: "L’Éternel est mon berger",
      excerpt: "Le Psaume 23, une parole de confiance pour les jours calmes comme pour les vallées sombres.",
      body: `« L’Éternel est mon berger : je ne manquerai de rien. » — Psaume 23.1

Le berger connaît ses brebis, les conduit et les protège. Le psalmiste ne nie pas l’existence des vallées sombres ; il affirme qu’il n’y marche pas seul.

Cette confiance n’est pas naïve : elle s’enracine dans la fidélité de Dieu, éprouvée au fil des jours.`,
      bibleRef: "Psaume 23.1",
      bibleTranslation: LSG,
      prayer: "Merci, Seigneur, d’être mon berger. Conduis-moi aujourd’hui. Amen.",
      nature: "enseignement",
      imageUrl: "https://images.pexels.com/photos/6186376/pexels-photo-6186376.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      imageAlt: "Bible ouverte posée sur une souche en pleine nature",
      imageCredit: "Abdiel Hernandez / Pexels",
      publishedAt: ago(8),
    },
    {
      ...base,
      type: "meditation",
      slug: "que-la-paix-de-christ-regne",
      title: "Que la paix de Christ règne dans vos cœurs",
      excerpt: "Méditation programmée : elle apparaîtra automatiquement à sa date de publication.",
      body: `« Et que la paix de Christ, à laquelle vous avez été appelés pour former un seul corps, règne dans vos cœurs. » — Colossiens 3.15

La paix n’est pas seulement un sentiment personnel ; elle se vit ensemble, dans la communauté.`,
      bibleRef: "Colossiens 3.15",
      bibleTranslation: LSG,
      nature: "enseignement",
      publishedAt: new Date(Date.now() + 3 * day),
    },
    {
      type: "temoignage",
      status: "brouillon",
      authorId: redac.id,
      slug: "exemple-de-temoignage",
      title: "Exemple de témoignage (modèle à remplacer)",
      excerpt: "Brouillon de démonstration : ne pas publier. Remplacer par un témoignage réel avec accord écrit.",
      body: "Ce brouillon montre la mise en page d’un témoignage. Il ne doit pas être publié tel quel.",
      mediaFormat: "texte",
      anonymized: true,
      nature: "fait",
    },
    {
      type: "episode",
      status: "brouillon",
      authorId: redac.id,
      showId: show.id,
      slug: "episode-pilote",
      title: "Épisode pilote (à compléter)",
      excerpt: "Brouillon : ajouter l’URL de la vidéo autorisée avant publication.",
      body: "Présentation de l’épisode.",
      mediaFormat: "video",
      nature: "enseignement",
    },
  ]);

  await db.insert(settings).values({ key: "home", value: DEFAULT_HOME }).onConflictDoNothing();
}
