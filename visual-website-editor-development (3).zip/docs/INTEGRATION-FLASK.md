# Adapter l’Atelier à Python / Flask sans refaire l’interface

## Statut

Ceci est une **proposition de contrat et d’intégration**, pas une description du site ou des API Flask existants. Aucune connaissance de leur format, de leurs comptes ou de leurs migrations n’est présumée. Le prototype est autonome et n’a aucune connexion de production.

## Stratégie

1. Inventorier les routes, modèles, contenus, autorisations, médias, formulaires et composants partagés du site existant. Faire une sauvegarde cohérente et tester sa restauration avant toute migration.
2. Conserver l’interface, les composants, les styles et les interactions du dossier `src/components/atelier`. Adapter les variables `--accent`, `--ink`, `--surface`, etc. dans `globals.css`. Le rendu du document et l’interface d’administration ont des classes distinctes.
3. Le navigateur peut rester en JavaScript. Deux options : conserver le bundle React et le servir comme fichiers statiques avec Flask, ou monter une route frontend séparée sous le même domaine et proxifier uniquement l’API. Il n’est pas nécessaire d’exécuter un serveur Node en production si le bundle et le point de démarrage sont adaptés à la chaîne de construction Flask.
4. `src/lib/atelier/api.ts` est l’adaptateur HTTP unique. Conserver ses résultats et ses erreurs, et changer ses URL, son mécanisme de session et son en-tête CSRF pour Flask. Ne pas réécrire les panneaux visuels pour remplacer le serveur.
5. Reproduire les opérations de `repository.ts` en Python avec l’ORM du site. Valider le format v1 côté Python (Pydantic, Marshmallow ou JSON Schema) et mettre en place les mêmes listes d’autorisation. Zod côté navigateur n’est pas une frontière de sécurité.
6. Remplacer le moteur de démonstration par des adaptateurs explicites des vrais modèles, sans inférer leur format. Une conversion crée toujours un brouillon distinct ; elle ne publie et ne remplace jamais une page automatiquement.
7. Monter la route finale `/admin/atelier` en remplacement ou évolution de l’Atelier existant, derrière le système d’authentification et d’autorisation existant. Ne pas laisser un deuxième atelier permanent.

## Contrat proposé à adapter

Toutes les réponses sont du JSON sauf le faux site public. Les erreurs ont `{error: message_francais}` et un statut pertinent. Les écritures de démo utilisent le cookie HttpOnly signé et `x-atelier-csrf`. Les lectures sont accessibles en démo ; en production elles doivent également être authentifiées et contrôlées par rôle et par page.

| Méthode et chemin du prototype       | Entrée                                                                       | Sortie                                                                    |
| ------------------------------------ | ---------------------------------------------------------------------------- | ------------------------------------------------------------------------- |
| GET `/api/atelier`                   | —                                                                            | `{pages, csrf, environment, role}` ; établit une session publique de démo |
| POST `/api/atelier`                  | `title, slug, sourceId?, blank?`                                             | Page créée, code 201 ; adresse unique                                     |
| GET `/api/atelier/:id`               | —                                                                            | Métadonnées, `draft`, `published`, `revision`, `publishedRevision`        |
| PUT `/api/atelier/:id`               | `{expectedRevision, document}`                                               | Brouillon complet enregistré et nouvelle révision                         |
| POST `/api/atelier/:id`              | `{action: 'review'}`                                                         | Brouillon, publication et jeton signé de vérification valable 10 minutes  |
| POST `/api/atelier/:id`              | `{action: 'publish', token, confirmed: true}`                                | Page après publication de l’instantané vérifié                            |
| GET `/api/atelier/:id?mode=versions` | —                                                                            | Versions publiées avec documents et dates                                 |
| POST `/api/atelier/:id`              | `{action: 'restore', versionId, expectedPublishedRevision, confirmed: true}` | Nouvelle version publiée ; brouillon inchangé                             |
| POST `/api/atelier/:id`              | `{action: 'delete', confirmed: true}`                                        | `{ok:true}` ; suppression seulement si aucune publication                 |

400 : validation ; 401 : session de démo expirée ; 403 : origine, CSRF ou opération interdite ; 404 : absent ; 409 : révision, jeton ou adresse en conflit ; 413 : taille excessive ; 503 : stockage indisponible. Une réponse réseau illisible ou perdue n’est pas annoncée comme un succès. La personne doit vérifier le serveur avant de recommencer.

Les médias sont actuellement des fichiers locaux livrés. Les liaisons sont dans le document et portent sur son tableur. Il n’existe pas de service d’upload, de connecteur réel, de SQL ni d’API de propagation partagée dans ce lot. Ne pas inventer ces services. Prévoir plus tard des routes dédiées autorisées et documentées.

## Préconditions atomiques de publication

Le prototype utilise une transaction PostgreSQL et `SELECT FOR UPDATE` sur la page. Le jeton signé lie ensemble l’identifiant, la révision du brouillon, la révision publique, le SHA-256 exact du document et l’expiration. La transaction vérifie à nouveau ces valeurs, insère un instantané dans l’historique et remplace la publication. Les sauvegardes prennent le même verrou ; les révisions empêchent une dernière écriture silencieuse. Le document ne contient ni HTML brut, ni CSS libre, ni JavaScript exécutable.

Dans Flask, conserver cette atomicité et ajouter : rôle réel, appartenance, permissions sur chaque source, composants partagés/versionnés, état du thème et réglage d’accueil. Si l’accueil est changé, verrouiller aussi la ligne de configuration et contrôler sa révision dans la même transaction. Si une dépendance pertinente change entre vérification et publication, renvoyer 409 et exiger une nouvelle vérification. Le choix d’accueil et la propagation partagée ne sont **pas implémentés** dans le prototype ; sa transaction ne les garantit donc pas.

Prévoir des clés d’idempotence et un journal d’audit pour les écritures de production. Le prototype ne fournit pas une garantie d’exécution exactement une fois en cas de perte de réponse. Après un doute réseau, recharger l’état et l’historique avant d’agir.

## Données, confidentialité et rendu

- Tables de démo : `atelier_demo_pages` et `atelier_demo_versions`. Ne jamais les substituer aux tables existantes sans migration étudiée.
- Brouillon et publication sont deux champs distincts ; les versions publiées sont des instantanés distincts et immuables via l’API.
- La restauration crée une nouvelle publication et laisse le brouillon inchangé.
- Le faux site `/site/:id` utilise le même moteur de rendu que l’éditeur et retire les lignes non publiées et le graphe avant l’envoi au navigateur. En production, appliquer le filtrage d’autorisation à la source, pas seulement au rendu.
- Les en-têtes/pieds de page des exemples sont signalés comme partagés mais ne pointent pas vers une ressource partagée de production. Ils sont protégés jusqu’à détachement local. La propagation globale n’est pas disponible.
- Aucune donnée personnelle ni donnée membre n’est simulée. Espace membre et administration sont explicitement non compatibles et ne peuvent être enregistrés par l’API.
- Aucun service de notifications, commentaire, recherche membre ou publication d’article n’est annoncé comme connecté.

## Sécurité à réaliser avant tout déploiement réel

Authentification existante, rôles et permissions côté serveur pour toutes les lectures et écritures ; CSRF du site ; cookies Secure/HttpOnly/SameSite ; expiration et révocation des sessions ; CSP et restrictions d’images/liens ; tailles et profondeurs de JSON avant analyse ; quotas, débit et journaux d’audit ; analyse antivirus et type réel pour les fichiers ; contrôle d’accès aux médias ; prévention SSRF pour tout futur import distant ; validation des cibles et liens ; nettoyage des métadonnées sensibles.

La démo donne intentionnellement une session d’administrateur de démonstration à chaque visiteur. Ce n’est pas un système d’authentification. Les vérifications de compatibilité, CSRF, révision et publication sont réelles mais ne remplacent pas les règles métier du site.

## Import des données existantes et retour arrière

Le format de l’ancien Atelier n’a pas été fourni. Ne pas le deviner. Écrire un adaptateur séparé après inventaire, avec rapport de champs reconnus/inconnus, identifiants préservés, aucun écrasement et conversion en brouillons. Conserver les originaux et les médias existants.

Avant migration : sauvegarde complète de PostgreSQL, médias et configuration. Après migration en préproduction : test de rechargement, publication, conflit, restauration, permissions et retour à l’ancien moteur. Pour un rollback : arrêter les écritures, restaurer une copie cohérente de la base et des médias, remettre l’ancien moteur et vérifier les comptes, liens, SEO, brouillons et pages. Les migrations de production, les sauvegardes complètes et leur restauration ne sont pas réalisées dans cet environnement de démo.
