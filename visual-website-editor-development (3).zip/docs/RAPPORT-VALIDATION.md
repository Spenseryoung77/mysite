# Rapport de validation — lot 1

## Environnement testé

Application Next.js en mode production, PostgreSQL isolé et Chromium Headless via Playwright. Toutes les données sont fictives. Aucun site Flask ni service réel n’a été raccordé.

## Résultats

- **16 / 16 tests unitaires réussis** : format du document, validations, commandes non mutantes, URL, duplication, déplacement, protection, héritage, liaisons et graphe.
- **7 / 7 scénarios API et navigateur réussis** :
  1. Session/CSRF, composant partagé protégé, compatibilité, adresse unique, URL sûre, conflits de révision, publication exacte et restauration.
  2. Sélection, édition directe, annulation et changement de format.
  3. Modification, sauvegarde serveur, rechargement, comparaison et confirmation de publication fictive.
  4. Modification réelle du tableur, nouvelle ligne, conservation serveur et résultat du blueprint.
  5. Propriétés sur petit écran, ouverture du menu mobile, attributs accessibles et Échap fermant le menu sans fermer l’aperçu.
  6. Échec simulé du stockage, absence de faux succès et export JSON contenant exactement le texte non enregistré.
- Génération des types de routes : réussie.
- TypeScript sans émission : réussi.
- Build de production : réussi.
- Démarrage de production et contrôle `/api/health` : réussis.

Le septième scénario vérifie qu’une copie créée depuis l’interface contient aussi les modifications qui n’étaient pas encore enregistrées avant la création.

## Contrôle de présentation complémentaire

Contrôle Chromium aux dimensions 1440 × 1000, 1280 × 800, 768 × 1024 et 390 × 844 : aucun débordement horizontal global. Le format initial est mobile sur téléphone ; l’utilisateur peut choisir un autre format et une largeur personnalisée.

Aucune erreur JavaScript constatée durant les captures des vues éditeur, blueprint, tableur et mobile. Le contrôle géométrique du départ d’un câble de blueprint a mesuré un écart de 0 pixel par rapport au centre du port. Les captures sont livrées dans `artifacts/atelier-*.png` dans l’archive.

Après nettoyage des scénarios : 12 pages fictives d’origine, aucune page `/test-*` restante. Les tests n’effacent que leurs propres pages dans la base de démonstration.

## Audit npm

13 avis modérés, aucun élevé ni critique. Ils concernent Drizzle Kit/esbuild et la chaîne ESLint/TypeScript-ESLint. Des corrections proposées impliquent des changements majeurs de versions ; aucune rétrogradation automatique n’a été appliquée. Réévaluer l’audit avant intégration et déploiement.

## Ce que cette validation ne prouve pas

- Aucun essai sur appareil tactile matériel, Safari, Firefox ou lecteur d’écran réel.
- Aucune validation des comptes, permissions, pages, migrations ou données du site Flask.
- Aucune garantie de production sur le stockage, la sauvegarde indépendante ou la restauration complète de la base.
- Aucune intégration des notifications, commentaires, médias téléversés, thèmes membres ou composants propagés.
- Les fonctions marquées partielles dans le lot de 20 restent partielles, même si les parcours implémentés réussissent.

Les commandes exactes de reproduction figurent dans le README. Le serveur doit être démarré séparément avant les tests Playwright ; une base isolée est obligatoire. L’archive de source ne contient pas la base ni les secrets et ne remplace pas une sauvegarde des données.
