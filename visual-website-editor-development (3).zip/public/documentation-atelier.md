# L’Atelier — Paroles Inspirées

## Livraison : lot 1 de 20 fonctionnalités

Prototype autonome en français, démonstration isolée, juin 2026. Le site réel et ses API ne sont pas connectés. L’inventaire est fictif et représentatif, pas un inventaire du site Flask. Adresse cible : `/admin/atelier`. Le prototype y est disponible, ainsi qu’à `/`. Le faux site public est à `/site/accueil`.

Les mentions **fonctionnelle**, **partielle**, **maquette** et **non réalisée** ont des sens distincts. Rien dans ce lot n’est présenté comme une intégration de production. Le tableau indique la fonction utilisable et sa limite, pas une promesse de couverture totale du cahier des charges.

## Lancement et dépendances

Node.js 20.9+ (22 recommandé), npm, PostgreSQL 14+ isolé. Définir `DATABASE_URL` dans `.env`, puis `npm install`, `npx drizzle-kit push`, `npm run dev`. Ouvrir http://localhost:3000/admin/atelier. Les tables `atelier_demo_pages` et `atelier_demo_versions` sont séparées de tout autre stockage. L’initialisation insère les exemples avec une transaction idempotente et ne remplace aucune ligne existante.

`ATELIER_SESSION_SECRET` : secret aléatoire stable facultatif pour la session de démonstration ; sinon un secret mémoire est généré, les sessions expirant au redémarrage. `ATELIER_SECURE_COOKIE=true` : activer Secure en HTTPS. Aucun secret ni fichier `.env` n’est livré dans l’archive.

Bibliothèques : Next.js 16 et React 19 (MIT), Drizzle ORM 0.45 et drizzle-kit 0.31 (Apache-2.0), pg 8 (MIT), Zod 4 (MIT), Tailwind 4 (MIT), Lucide React (ISC), tsx (MIT), TypeScript 5 et Playwright (Apache-2.0), dotenv (BSD-2-Clause). Inter Variable (SIL OFL 1.1 ; conditionnement Fontsource MIT). Versions exactes : `package-lock.json`. Les licences complètes restent dans les dépendances npm.

Photographies Pexels locales : Quang Nguyen Vinh, image 11334345 ; Nothing Ahead, image 4567409 ; RAY LEI, image 13865966. Voir https://www.pexels.com/license/. Les photographies ne relèvent pas de la licence des bibliothèques ou du code.

## Architecture et séparation

- **Interface** : `src/components/atelier/atelier.tsx`, `sidebar.tsx`, `inspector.tsx`, `ui.tsx`, `data-studio.tsx`.
- **Rendu unique** : `page-renderer.tsx`, utilisé par la planche, l’aperçu et le faux site public. `published-page.tsx` choisit le format selon la fenêtre.
- **Modèle et commandes pures** : `src/lib/atelier/model.ts` ; schémas Zod côté serveur et navigateur ; sélection, duplication, suppression, déplacement, styles et comparaison sans dépendance au stockage.
- **Exemples** : `seed.ts`. Douze pages : accueil, actualités, foi et Bible, méditations, témoignages, Bible, médias, agenda, soutien, modèle d’article, espace membre et administration. Les deux dernières sont signalées non compatibles.
- **Adaptateur navigateur** : `api.ts`, seul point d’appel au serveur.
- **Métier et stockage** : `repository.ts` ; Drizzle uniquement pour PostgreSQL. Les révisions et transactions ne sont pas confiées au navigateur.
- **Sécurité de démonstration** : `security.ts` ; session signée, origine et CSRF sur les écritures. Tout visiteur reçoit un rôle administrateur de démo. Ce mécanisme n’authentifie pas un administrateur réel.
- **Schéma PostgreSQL** : `src/db/schema.ts`.
- **Couleurs** : variables CSS de l’interface au début de `globals.css` ; couleurs et police de page dans le document. L’interface ne dépend pas des couleurs actuelles du site réel.

## Modèle de document v1

Le type TypeScript et la validation exécutable complets sont dans `model.ts`. Le schéma n’accepte pas de propriétés inconnues.

Un document contient :

- `version: 1`, `title` et `slug` (adresse interne simple, validée et unique dans le catalogue).
- `theme` : `primary`, `background`, `font` (Georgia, Arial ou Inter).
- `elements` : arbre ordonné de composants.
- `graph` : nœuds et connexions du blueprint.
- `sheet` : jusqu’à 500 lignes de données fictives.

Un élément contient :

- `id` unique dans le document, `kind`, `name`, `children`.
- `text`, `href`, `src`, `alt` selon le type ; aucun HTML brut.
- `styles.desktop`, `styles.tablet`, `styles.mobile` : valeurs optionnelles autorisées. Taille de police, graisse, couleurs, fond, dimensions, translation X/Y, espacement, padding, arrondi, alignement, direction, opacité et visibilité. Aucune chaîne de CSS arbitraire.
- `locked`, `hidden`, `shared`, `role` (variante de rendu interne, pas un rôle de permission).
- `binding?` : source `articles`, identifiant de ligne, champ et valeur de remplacement.
- `interaction?` : déclencheur clic/survol, action ouvrir un lien ou basculer la visibilité, cible validée.

Types initiaux extensibles : en-tête, pied de page, section, conteneur, titre, texte, bouton, image, carte. Les cartes contiennent de vrais éléments éditables. Les éléments inconnus sont refusés, pas supprimés silencieusement.

Invariants : identifiants uniques, maximum 500 éléments, profondeur maximale 12 après validation, propriétés numériques bornées, couleurs structurées, URL relatives sûres ou HTTPS (mailto/tel seulement pour les liens), pas d’HTML/JS/CSS libre. Un document inconnu ou invalide n’est pas enregistré. Le travail actuel reste dans le navigateur, exportable. La limite de corps d’écriture est de 1,5 Mo ; un contrôle encore plus précoce de profondeur JSON doit être ajouté pour un service exposé en production.

Héritage responsive : ordinateur → tablette → mobile. Une valeur absente hérite ; une modification ne concerne que le format actif. La flèche de réinitialisation retire les réglages de ce format. Il n’existe pas encore de provenance par propriété ni de retour à l’héritage pour une seule propriété : le retour concerne le bloc du format.

Le tableur contient `id`, `title`, `category`, `author`, `status`, `date`. Les statuts sont Publié, Brouillon, Masqué. Une liaison publique ne résout que les lignes Publié ; le serveur retire les autres lignes avant l’envoi du document public. Les lignes supprimées ou absentes utilisent la valeur de remplacement.

Les en-têtes/pieds sont des exemples signalés partagés, protégés jusqu’au détachement d’une copie locale. La propagation et la ressource partagée multi-page ne sont pas implémentées.

## Lot 1 — Suivi des 20 fonctionnalités distinctes

| #   | Fonction et résultat attendu                                             | Dépendances                          | État réel     | Critère de test                                                                                                   | Limites / suite                                                                                                                   |
| --- | ------------------------------------------------------------------------ | ------------------------------------ | ------------- | ----------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------- |
| 1   | Espace de création français : barre, planche, panneaux et mode avancé    | Interface, rendu                     | Fonctionnelle | Ouvrir /admin/atelier ; focus clavier ; replier le panneau gauche ; propriétés sur mobile                         | Panneaux non redimensionnables ; inspector desktop non repliable                                                                  |
| 2   | Catalogue central avec recherche, catégorie, statut et compatibilité     | API, PostgreSQL                      | Fonctionnelle | Filtrer les 12 exemples ; ouvrir une rubrique ; refuser les pages non compatibles                                 | Inventaire réel et conversion non raccordés                                                                                       |
| 3   | Création, nom et adresse de page sans écrasement                         | Catalogue, validation                | Fonctionnelle | Créer une page vierge ; changer nom/adresse ; créer un doublon d’adresse → 409                                    | Pas de dossiers, redirection ni changement d’accueil                                                                              |
| 4   | Copie et bibliothèque de sections/pages réutilisables                    | Modèle, duplication                  | Fonctionnelle | Créer depuis la page ou le modèle ; insérer une section indépendante                                              | Favoris personnels, variantes sauvegardées et partage à réaliser                                                                  |
| 5   | Sélection imbriquée et multiple synchronisée aux calques                 | Arbre d’éléments                     | Fonctionnelle | Cliquer un titre dans une carte ; sélectionner le même calque ; Maj+clic                                          | Transformations/alignements collectifs non réalisés                                                                               |
| 6   | Édition des textes, boutons et destinations                              | Sélection, URL validées              | Fonctionnelle | Double-clic texte ; saisie dans l’inspecteur ; une URL javascript est refusée                                     | Pas de texte riche à styles multiples ni SEO                                                                                      |
| 7   | Images existantes, remplacement non destructif et texte alternatif       | Médias locaux, rendu                 | Fonctionnelle | Choisir une image, changer alt, enregistrer et recharger                                                          | Pas d’upload, de recadrage avancé ni de gestionnaire média serveur                                                                |
| 8   | Identité visuelle locale et styles de l’élément                          | Thème, inspecteur                    | Partielle     | Choisir un thème de page ; changer couleurs, police, taille, fond et opacité                                      | Pas de styles globaux propagés ni de thèmes temporaires membres                                                                   |
| 9   | Réorganisation visuelle en structure automatique                         | Arbre, glisser-déposer               | Partielle     | Déposer après une cible ; observer le repère ; sauvegarder et recharger                                           | Placement libre, guides d’alignement, drag tactile et insertion dans un groupe par drag à réaliser ; X/Y sont des translations    |
| 10  | Redimensionnement par poignées et nombres                                | Rendu, styles                        | Fonctionnelle | Tirer une poignée ; constater les dimensions réelles ; changer L/H                                                | Pas de verrouillage du ratio ; aimantation 8 px appliquée au resize seulement                                                     |
| 11  | Gestion des calques : nom, visibilité et verrouillage                    | Sélection, modèle                    | Fonctionnelle | Renommer, masquer/afficher, verrouiller ; une suppression verrouillée est refusée                                 | Verrou de confort d’édition, pas un droit utilisateur ; propagation partagée désactivée                                           |
| 12  | Groupes de composants indépendants                                       | Sélection multiple, arbre            | Partielle     | Grouper deux frères via Ctrl+G ; clic droit → dégrouper                                                           | Seulement même parent ; flux conservé mais pas garantie de géométrie pixel parfaite                                               |
| 13  | Historique local et actions d’édition au clavier/menu                    | Commandes pures                      | Fonctionnelle | Annuler/rétablir ; copier/coller internes ; Ctrl+D ; clic droit ; saisir normalement dans un champ                | Historique limité à 80 commandes par ouverture, presse-papiers interne seulement                                                  |
| 14  | Ordinateur/tablette/mobile et styles hérités                             | Moteur responsive                    | Partielle     | Largeurs 1200/768/390 ; modifier le format mobile sans changer desktop ; réinitialiser                            | Pas d’analyse de débordement ni de provenance par propriété ; réglages du menu limités au modèle de démo                          |
| 15  | Brouillons serveur, autosave, erreur et conflit                          | API, Drizzle, révisions              | Fonctionnelle | Sauvegarde manuelle/4,5 s ; recharger ; écriture obsolète → 409 ; échec visible et export                         | Pas de fusion collaborative ni copie locale durable automatique ; réessayez manuellement après erreur                             |
| 16  | Aperçu fidèle et test des interactions séparé                            | Rendu partagé                        | Fonctionnelle | Aperçu par appareil ; liens inactifs en édition ; menu mobile ouvre/ferme/Échap                                   | Les liens de l’aperçu naviguent vers leurs destinations ; aucun bac à sable externe ; tester sur appareils réels avant production |
| 17  | Comparaison et publication explicite du document vérifié                 | Brouillons, jeton signé, transaction | Fonctionnelle | Comparer les modifications ; confirmer ; brouillon modifié après review → 409                                     | Fausse publication uniquement ; comparaison liste les changements, pas un diff typographique ; pas de retrait/choix d’accueil     |
| 18  | Historique publié et restauration sans toucher au brouillon              | Instantanés, transactions            | Fonctionnelle | Prévisualiser une version ; confirmer restauration ; vérifier le brouillon intact                                 | Pas de purge ni d’annotation des versions ; pas de sauvegarde indépendante de la base                                             |
| 19  | Tableur persistant : saisie, recherche, filtre, tri, duplication, export | Document, API                        | Fonctionnelle | Modifier une cellule ; ajouter une ligne ; sauvegarder/recharger ; exporter CSV                                   | Cinq colonnes fixes, 500 lignes ; aucune formule, SQL ni import XLSX ; CSV neutralise les débuts de formule                       |
| 20  | Blueprint simple, liaisons visuelles et interactions sûres               | Graphe typé, tableur, moteur         | Partielle     | Relier les ports ; refuser un type invalide ; tester un résultat réel ; importer/exporter ; appliquer une liaison | Sources/champs/filtre de statut/affichage ; pas de conditions complexes, animations, cible par clic ni graphe partagé             |

Aucune fonctionnalité n’est volontairement représentée par un bouton de succès fictif. Les fonctions futures sont indiquées et ne disposent pas d’une commande prétendant les exécuter. Le graphe est réellement évalué ; aucune durée ni nombre de fonctionnalités n’est inventé.

## Sauvegarde, publication et restauration

La sauvegarde ne modifie que le brouillon et incrémente `revision`. Les erreurs de validation/conflit/stockage sont visibles et ne vident pas le document courant. Pour récupérer : Paramètres → Exporter le brouillon complet. Après un conflit, conserver cet export avant rechargement. L’import est validé et annulable ; il conserve le nom et l’adresse actuels et ne publie jamais.

La publication est séparée : sauvegarde → comparaison serveur → jeton signé de 10 minutes → case de confirmation → transaction. Le jeton lie l’identifiant, `revision`, `publishedRevision`, le hash SHA-256 exact du document et l’expiration. La transaction verrouille la page et vérifie de nouveau toutes les préconditions. Elle crée un instantané et remplace `published` sans modifier le brouillon.

La restauration contrôle la révision publique et la version demandée, crée un nouvel instantané public et ne touche pas au brouillon, même s’il n’est pas enregistré. Une publication ou restauration après changement concurrent est refusée. Si une réponse est illisible/perdue, l’interface n’annonce pas un succès ; vérifier l’état et les versions avant de recommencer. Les clés d’idempotence et la garantie exactement-une-fois en cas de coupure réseau sont à ajouter en production.

Le choix de la page d’accueil et les changements partagés ne sont pas implémentés ; les verrous de démo ne garantissent donc pas leurs transactions. Ils doivent être ajoutés avec leurs révisions propres lors de l’intégration.

## API proposée, à adapter à Flask

L’adaptateur complet est dans `src/lib/atelier/api.ts`. Contrat détaillé et préconditions dans `docs/INTEGRATION-FLASK.md`.

- GET `/api/atelier` : catalogue, jeton CSRF et session de démonstration.
- POST `/api/atelier` : création (`title`, `slug`, `sourceId?`, `blank?`).
- GET `/api/atelier/:id` : page, brouillon, publication et révisions.
- PUT `/api/atelier/:id` : `{expectedRevision, document}`.
- POST `/api/atelier/:id` : actions `review`, `publish`, `restore`, `delete`, avec confirmation et préconditions adaptées.
- GET `/api/atelier/:id?mode=versions` : historique publié.

La protection CSRF, la signature des sessions et les contrôles de révision sont réels dans la démo. L’utilisateur est intentionnellement un administrateur de démonstration anonyme. **Aucune authentification ou matrice de rôles de production n’est livrée.** Les lectures et l’accès aux routes doivent être raccordés aux règles Flask existantes avant usage réel.

## Tests et vérification

Unités : `npx tsx --test tests/model.test.ts`. Seize scénarios couvrent le format v1, les propriétés inconnues, styles injectés, URL, commandes non mutantes, protection, identifiants de copies, déplacement, héritage, liaisons publiques et absentes, comparaison, graphe et cibles d’interaction.

Navigateur et API : installer Chromium avec `npx playwright install --with-deps chromium`, démarrer une instance de démo, puis `npx playwright test`. `PLAYWRIGHT_BASE_URL` permet de cibler son URL. Les tests utilisent la base configurée dans `.env` et ne suppriment que leurs pages `/test-*`. Ne pas exécuter ces tests sur une base réelle.

Les scénarios vérifient CSRF, adresse en conflit, validation d’URL, conflit de révision, brouillon non publié automatiquement, jeton périmé par modification, confirmation obligatoire, publication exacte, filtrage des données publiques et restauration avec conservation du brouillon. Les parcours Chromium couvrent sélection, double-clic, annulation, formats, sauvegarde/rechargement/publication, tableur, résultat du graphe, petit écran et erreur de stockage avec export.

Validation technique : `npx next typegen`, `npm exec tsc -- --noEmit --pretty false`, `npm run build`, puis démarrage de production et `/api/health`.

Limites des tests : pas de matériel tactile réel, Safari, Firefox ou lecteur d’écran réel. Les rôles et connecteurs Flask, migrations du site réel, sauvegardes complètes et leur restauration ne peuvent pas être testés sans l’intégration. L’archive ne remplace pas une sauvegarde PostgreSQL ni une sauvegarde indépendante des médias.

## Lot 2 proposé — 20 fonctionnalités à réaliser séparément

1. Inventaire automatique des routes et correspondance des vrais modèles Flask.
2. Adaptateur de conversion non destructif des anciennes pages vers des brouillons.
3. Authentification et autorisations par rôle/page/source réelles.
4. Édition sûre de l’apparence de l’administration sans modification des formulaires.
5. Modèle d’espace membre avec isolation des informations par membre.
6. Composants partagés versionnés, liste des pages affectées et propagation confirmée.
7. Navigation complète éditable et menus mobiles à présentations multiples.
8. Dossiers, organisation des pages, redirections et détection des liens cassés.
9. Choix d’accueil transactionnel, rétablissement éditorial et retrait de publication.
10. Placement libre avec guides, collisions et déplacement tactile.
11. Alignement, distribution et transformation collectifs avec géométrie conservée.
12. Héritage responsive par propriété et analyse de débordement.
13. Téléversement média sécurisé et recadrage non destructif.
14. Styles globaux, favoris et variantes réutilisables personnels.
15. Thèmes temporaires ciblés et planification d’activation pour les membres.
16. Connecteurs autorisés articles/auteurs/catégories/événements/émissions/épisodes.
17. Listes dynamiques filtrées et mise à jour indépendante des contenus.
18. Conditions, chaînes d’actions, cibles visuelles et animations à mouvement réduit.
19. Évolution du tableur : colonnes typées et imports validés sans SQL exposé.
20. Journal d’audit, idempotence, sauvegardes complètes, retour arrière et tests multi-utilisateurs/appareils.

## Intégration et livraison

Conserver l’interface et son adaptateur HTTP ; remplacer le serveur de démonstration par Flask et valider les mêmes invariants côté Python. Ne jamais brancher la session publique de démo sur le site réel. L’Atelier final doit remplacer/faire évoluer celui qui existe sous `/admin/atelier`, pas devenir une deuxième interface permanente.

Le format des brouillons existants n’ayant pas été fourni, aucun import de données réelles n’a été inventé. Prévoir inventaire, migration sans écrasement, sauvegarde complète et retour arrière testés en préproduction. Le code, les tests et la note d’intégration sont dans l’archive téléchargeable depuis l’aide de l’Atelier. `.env`, dépendances installées, builds et données PostgreSQL en sont exclus.

## Audit et schéma portable

Audit npm au moment de la livraison : 13 avis modérés dans la chaîne de développement (Drizzle Kit/esbuild et ESLint/TypeScript-ESLint), aucun avis élevé ou critique. Aucune rétrogradation majeure automatique n’a été appliquée ; audit et mise à niveau contrôlée restent requis avant production. Prettier, utilisé pour formater les sources, est sous licence MIT.

Le fichier `schema-document-v1.json` fournit le schéma JSON structurel généré depuis Zod, et `exemple-page-v1.json` un document fictif complet. Les invariants transversaux (unicité, profondeur, cibles, connexions compatibles) et les règles d’autorisation doivent aussi être portés en Python ; le JSON Schema ne remplace pas ces validations métier.

## Résultat de la recette livrée

16 tests unitaires et 7 scénarios API/navigateur réussis, génération des types, TypeScript, build de production et contrôle de santé réussis. Les contrôles de présentation Chromium ont été effectués en 1440 × 1000, 1280 × 800, 768 × 1024 et 390 × 844, sans débordement horizontal global. Aucune erreur JavaScript détectée durant ces contrôles. Les limites des appareils et services non testés restent celles indiquées ci-dessus. Le rapport détaillé est dans `docs/RAPPORT-VALIDATION.md` de l’archive.

### Précision sur les adresses

Le nom et l’adresse sont enregistrés et les conflits d’adresse sont refusés. Dans ce serveur de démonstration, le rendu public utilise `/site/:id` : l’adresse souhaitée reste une métadonnée à raccorder au routeur Flask. Aucun routage public par slug ni aucune redirection n’est annoncé comme livré. La copie d’une page enregistre d’abord son brouillon courant afin de ne pas copier une version obsolète.
