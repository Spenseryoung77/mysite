import { test } from "node:test";
import assert from "node:assert/strict";
import { createDemoDocument, element } from "../src/lib/atelier/seed";
import {
  documentSchema,
  graphSchema,
  isSafeUrl,
  updateElement,
  findElement,
  removeElement,
  cloneElement,
  insertAfter,
  moveElement,
  resolveStyle,
  resolveText,
  diffDocuments,
  flatten,
} from "../src/lib/atelier/model";

test("le document de démonstration respecte le format v1", () => {
  const d = createDemoDocument();
  assert.equal(documentSchema.safeParse(d).success, true);
  assert.ok(flatten(d.elements).length > 25);
});
test("les types et propriétés inconnues sont refusés", () => {
  const d = createDemoDocument();
  assert.equal(
    documentSchema.safeParse({ ...d, script: "alert(1)" }).success,
    false,
  );
  assert.equal(documentSchema.safeParse({ ...d, version: 2 }).success, false);
});
test("la validation refuse les styles injectés et les identifiants dupliqués", () => {
  const d = createDemoDocument();
  d.elements[1].styles.desktop = { color: "red;position:fixed" };
  assert.equal(documentSchema.safeParse(d).success, false);
  const other = createDemoDocument();
  other.elements.push(other.elements[0]);
  assert.equal(documentSchema.safeParse(other).success, false);
});
test("les URL non sûres sont refusées", () => {
  for (const url of [
    "javascript:alert(1)",
    "data:text/html,bad",
    "//evil.example",
    "/\\evil.example",
  ])
    assert.equal(isSafeUrl(url), false);
  for (const url of [
    "https://example.org/a",
    "/site/accueil",
    "#mission",
    "mailto:exemple@example.org",
  ])
    assert.equal(isSafeUrl(url), true);
  assert.equal(isSafeUrl("mailto:a@b.fr", true), false);
});
test("une modification ne mute pas le document précédent", () => {
  const original = createDemoDocument();
  const next = updateElement(original, "hero-title", {
    text: "Une espérance nouvelle",
  });
  assert.notEqual(next, original);
  assert.equal(
    findElement(original, "hero-title")?.text,
    "Une parole peut\nilluminer votre journée.",
  );
  assert.equal(findElement(next, "hero-title")?.text, "Une espérance nouvelle");
});
test("les éléments verrouillés et partagés ne sont pas supprimés par commande", () => {
  const d = createDemoDocument();
  assert.equal(removeElement(d, "site-header"), d);
  const locked = updateElement(d, "hero-title", { locked: true });
  assert.equal(removeElement(locked, "hero-title"), locked);
});
test("la duplication renouvelle les identifiants des descendants", () => {
  const e = createDemoDocument().elements[1];
  const copy = cloneElement(e);
  const ids = new Set(flatten([e]).map((n) => n.id));
  assert.ok(flatten([copy]).every((n) => !ids.has(n.id)));
  assert.equal(copy.shared, false);
});
test("insertion et déplacement conservent les éléments imbriqués", () => {
  const d = createDemoDocument();
  const newElement = element("test-element", "text", "Essai", "Un essai");
  const inserted = insertAfter(d, "hero-title", newElement);
  assert.equal(
    findElement(inserted, "hero-section")?.children[2].id,
    "test-element",
  );
  const moved = moveElement(inserted, "test-element", "daily-verse");
  assert.equal(moved.elements[3].id, "test-element");
  assert.equal(
    flatten(moved.elements).filter((e) => e.id === "test-element").length,
    1,
  );
});
test("un groupe ne peut pas être déplacé dans son descendant", () => {
  const d = createDemoDocument();
  assert.equal(moveElement(d, "hero-section", "hero-title"), d);
});
test("les styles mobiles héritent des autres formats sans les modifier", () => {
  const e = element("test", "heading", "Titre");
  e.styles = {
    desktop: { fontSize: 60, color: "#ffffff" },
    tablet: { fontSize: 48 },
    mobile: { fontSize: 32 },
  };
  assert.deepEqual(resolveStyle(e, "mobile"), {
    fontSize: 32,
    color: "#ffffff",
  });
  assert.equal(resolveStyle(e, "desktop").fontSize, 60);
  delete e.styles.mobile;
  assert.equal(resolveStyle(e, "mobile").fontSize, 48);
});
test("les liaisons publiques n’exposent pas les lignes brouillon", () => {
  const d = createDemoDocument();
  const e = element("bind", "text", "Texte");
  e.binding = {
    source: "articles",
    rowId: "a4",
    field: "title",
    fallback: "Contenu à venir",
  };
  assert.equal(resolveText(e, d, true), "Contenu à venir");
  assert.equal(resolveText(e, d, false), "Une espérance qui nous rassemble");
});
test("les liaisons manquantes utilisent le remplacement", () => {
  const d = createDemoDocument();
  const e = element("bind", "text", "Texte");
  e.binding = {
    source: "articles",
    rowId: "missing",
    field: "title",
    fallback: "Indisponible",
  };
  assert.equal(resolveText(e, d), "Indisponible");
});
test("la comparaison détecte contenu, style, ordre et données", () => {
  const before = createDemoDocument();
  let after = updateElement(before, "hero-title", {
    text: "Nouveau",
    styles: { desktop: { fontSize: 40 } },
  });
  after = { ...after, elements: [...after.elements].reverse(), sheet: [] };
  const differences = diffDocuments(before, after);
  assert.ok(differences.some((d) => d.name === "Structure de la page"));
  assert.ok(
    differences.some(
      (d) => d.name === "Titre principal" && d.detail.includes("contenu"),
    ),
  );
  assert.ok(differences.some((d) => d.name === "Tableur"));
  assert.equal(diffDocuments(before, structuredClone(before)).length, 0);
});
test("le graphe refuse les cycles, les références et les types incompatibles", () => {
  const d = createDemoDocument();
  assert.equal(graphSchema.safeParse(d.graph).success, true);
  for (const edge of [
    { id: "bad", from: "display-title", to: "source-articles" },
    { id: "bad", from: "source-articles", to: "unknown" },
    { id: "bad", from: "field-title", to: "filter-published" },
  ])
    assert.equal(
      graphSchema.safeParse({ ...d.graph, edges: [...d.graph.edges, edge] })
        .success,
      false,
    );
});
test("la validation signale une cible d’interaction supprimée", () => {
  const d = createDemoDocument();
  const next = updateElement(d, "hero-button", {
    interaction: { trigger: "click", action: "toggle", target: "missing" },
  });
  assert.equal(documentSchema.safeParse(next).success, false);
});
test("les champs de tableur inconnus ou trop longs sont refusés", () => {
  const d = createDemoDocument();
  d.sheet[0].title = "x".repeat(501);
  assert.equal(documentSchema.safeParse(d).success, false);
});
