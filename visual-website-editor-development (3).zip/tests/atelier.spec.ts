import "dotenv/config";
import { readFile } from "node:fs/promises";
import { test, expect } from "@playwright/test";
import { db, pool } from "../src/db";
import { atelierPages } from "../src/db/schema";
import { like } from "drizzle-orm";
import {
  findElement,
  updateElement,
  type PageDocument,
} from "../src/lib/atelier/model";

test.afterAll(async () => {
  await db.delete(atelierPages).where(like(atelierPages.slug, "/test-%"));
  await pool.end();
});
test.beforeEach(async ({ page }) => {
  page.on("dialog", (dialog) => dialog.dismiss());
});
test("API : sessions, validation, révisions, publication exacte et restauration", async ({
  request,
}) => {
  const forbidden = await request.post("/api/atelier", {
    data: { title: "Interdit", slug: "/test-interdit" },
  });
  expect([401, 403]).toContain(forbidden.status());
  const boot = await (await request.get("/api/atelier")).json();
  const headers = { "x-atelier-csrf": boot.csrf };
  const invalidCsrf = await request.post("/api/atelier", {
    headers: { "x-atelier-csrf": "invalid" },
    data: { title: "Interdit", slug: "/test-interdit" },
  });
  expect(invalidCsrf.status()).toBe(403);
  const created = await request.post("/api/atelier", {
    headers,
    data: {
      title: "Test API isolé",
      slug: `/test-api-${Date.now()}`,
      sourceId: "accueil",
    },
  });
  expect(created.status()).toBe(201);
  let page = await created.json();
  const id = page.id;
  const duplicate = await request.post("/api/atelier", {
    headers,
    data: { title: "Adresse en conflit", slug: page.slug, blank: true },
  });
  expect(duplicate.status()).toBe(409);
  const sharedChange = updateElement(page.draft, "site-brand", {
    text: "Changement partagé non autorisé",
  });
  const protectedSave = await request.put(`/api/atelier/${id}`, {
    headers,
    data: { expectedRevision: page.revision, document: sharedChange },
  });
  expect(protectedSave.status()).toBe(403);
  const incompatible = await (
    await request.get("/api/atelier/administration")
  ).json();
  const incompatibleSave = await request.put("/api/atelier/administration", {
    headers,
    data: {
      expectedRevision: incompatible.revision,
      document: incompatible.draft,
    },
  });
  expect(incompatibleSave.status()).toBe(403);
  const unsafe = updateElement(page.draft, "hero-button", {
    href: "javascript:alert(1)",
  });
  const refused = await request.put(`/api/atelier/${id}`, {
    headers,
    data: { expectedRevision: page.revision, document: unsafe },
  });
  expect(refused.status()).toBe(400);
  let draft = updateElement(page.draft, "hero-title", {
    text: "Version vérifiée",
  });
  let response = await request.put(`/api/atelier/${id}`, {
    headers,
    data: { expectedRevision: page.revision, document: draft },
  });
  expect(response.status()).toBe(200);
  const staleRevision = page.revision;
  page = await response.json();
  const conflict = await request.put(`/api/atelier/${id}`, {
    headers,
    data: { expectedRevision: staleRevision, document: draft },
  });
  expect(conflict.status()).toBe(409);
  expect(
    (await (await request.get(`/api/atelier/${id}`)).json()).published,
  ).toBeNull();
  const oldReview = await (
    await request.post(`/api/atelier/${id}`, {
      headers,
      data: { action: "review" },
    })
  ).json();
  draft = updateElement(page.draft, "hero-title", {
    text: "Version vérifiée et corrigée",
  });
  page = await (
    await request.put(`/api/atelier/${id}`, {
      headers,
      data: { expectedRevision: page.revision, document: draft },
    })
  ).json();
  const stalePublish = await request.post(`/api/atelier/${id}`, {
    headers,
    data: { action: "publish", token: oldReview.token, confirmed: true },
  });
  expect(stalePublish.status()).toBe(409);
  const review = await (
    await request.post(`/api/atelier/${id}`, {
      headers,
      data: { action: "review" },
    })
  ).json();
  const noConfirm = await request.post(`/api/atelier/${id}`, {
    headers,
    data: { action: "publish", token: review.token, confirmed: false },
  });
  expect(noConfirm.status()).toBe(400);
  response = await request.post(`/api/atelier/${id}`, {
    headers,
    data: { action: "publish", token: review.token, confirmed: true },
  });
  expect(response.status()).toBe(200);
  page = await response.json();
  expect(findElement(page.published, "hero-title")?.text).toBe(
    "Version vérifiée et corrigée",
  );
  const publicPage = await request.get(`/site/${id}`);
  expect(publicPage.status()).toBe(200);
  const html = await publicPage.text();
  expect(html).not.toContain("Une espérance qui nous rassemble");
  const versions = await (
    await request.get(`/api/atelier/${id}?mode=versions`)
  ).json();
  expect(versions.length).toBe(1);
  draft = updateElement(page.draft, "hero-title", {
    text: "Brouillon conservé après restauration",
  });
  page = await (
    await request.put(`/api/atelier/${id}`, {
      headers,
      data: { expectedRevision: page.revision, document: draft },
    })
  ).json();
  const implicitRestore = await request.post(`/api/atelier/${id}`, {
    headers,
    data: {
      action: "restore",
      versionId: versions[0].id,
      expectedPublishedRevision: page.publishedRevision,
      confirmed: "oui",
    },
  });
  expect(implicitRestore.status()).toBe(400);
  const restore = await request.post(`/api/atelier/${id}`, {
    headers,
    data: {
      action: "restore",
      versionId: versions[0].id,
      expectedPublishedRevision: page.publishedRevision,
      confirmed: true,
    },
  });
  expect(restore.status()).toBe(200);
  const restored = await restore.json();
  expect(findElement(restored.draft, "hero-title")?.text).toBe(
    "Brouillon conservé après restauration",
  );
  expect(findElement(restored.published, "hero-title")?.text).toBe(
    "Version vérifiée et corrigée",
  );
  const staleRestore = await request.post(`/api/atelier/${id}`, {
    headers,
    data: {
      action: "restore",
      versionId: versions[0].id,
      expectedPublishedRevision: 0,
      confirmed: true,
    },
  });
  expect(staleRestore.status()).toBe(409);
});

test("interface : sélection, édition directe, annulation et formats réels", async ({
  page,
}) => {
  await page.goto("/admin/atelier");
  await expect(
    page.getByRole("button", { name: /Publier/ }).first(),
  ).toBeEnabled();
  const title = page.locator('.artboard-inner [data-element-id="hero-title"]');
  await expect(title).toHaveClass(/element-selected/);
  await title.dblclick();
  const editable = title.locator(".element-text");
  await expect(editable).toHaveAttribute("contenteditable", "true");
  await editable.fill("Une inspiration à partager");
  await page
    .locator(".inspector")
    .getByRole("button", { name: "Contenu", exact: true })
    .click();
  await expect(title).toContainText("Une inspiration à partager");
  await page
    .getByRole("button", { name: "Annuler (Ctrl+Z)", exact: true })
    .click();
  await expect(title).toContainText("illuminer votre journée.");
  await page.getByRole("button", { name: "Mobile", exact: true }).click();
  await expect(
    page.getByRole("spinbutton", { name: "Largeur de la planche" }),
  ).toHaveValue("390");
  await expect(page.locator(".artboard-inner .page-document")).toHaveAttribute(
    "data-device",
    "mobile",
  );
  await page.getByRole("button", { name: "Tablette", exact: true }).click();
  await expect(
    page.getByRole("spinbutton", { name: "Largeur de la planche" }),
  ).toHaveValue("768");
  await page.getByRole("button", { name: "Ordinateur", exact: true }).click();
  await page.getByRole("button", { name: "Aperçu", exact: true }).click();
  await expect(page.getByRole("dialog")).toBeVisible();
  await page.getByRole("button", { name: "Fermer", exact: true }).click();
});

test("interface : enregistrer, recharger, comparer et confirmer la publication fictive", async ({
  page,
}) => {
  const boot = await (await page.request.get("/api/atelier")).json();
  const name = `Test parcours ${Date.now()}`;
  const created = await (
    await page.request.post("/api/atelier", {
      headers: { "x-atelier-csrf": boot.csrf },
      data: {
        title: name,
        slug: `/test-ui-${Date.now()}`,
        sourceId: "accueil",
      },
    })
  ).json();
  const open = async () => {
    await page.locator(".all-pages-button").click();
    await page
      .getByRole("textbox", { name: "Rechercher une page", exact: true })
      .fill(name);
    await page
      .getByRole("dialog")
      .getByRole("button", { name: new RegExp(name) })
      .first()
      .click();
    await expect(page.locator(".header-breadcrumb")).toContainText(name);
  };
  await page.goto("/admin/atelier");
  await open();
  await page
    .locator(".inspector")
    .getByRole("button", { name: "Contenu", exact: true })
    .click();
  await page
    .locator(".inspector")
    .getByLabel("Texte", { exact: true })
    .fill("Une lumière pour demain");
  const saved = page.waitForResponse(
    (r) =>
      r.url().includes(`/api/atelier/${created.id}`) &&
      r.request().method() === "PUT",
  );
  await page.keyboard.press("Control+s");
  expect((await saved).status()).toBe(200);
  await page.reload();
  await open();
  await expect(
    page.locator('.artboard-inner [data-element-id="hero-title"]'),
  ).toContainText("Une lumière pour demain");
  await page.locator(".publish-button").click();
  const dialog = page.getByRole("dialog");
  await expect(dialog).toContainText("Un dernier regard");
  const confirm = dialog.getByRole("button", {
    name: "Confirmer la publication",
  });
  await expect(confirm).toBeDisabled();
  await dialog.getByRole("checkbox").check();
  await confirm.click();
  await expect(dialog).not.toBeVisible();
  await page.goto(`/site/${created.id}`);
  await expect(
    page.getByRole("heading", { name: "Une lumière pour demain" }),
  ).toBeVisible();
});

test("interface : tableur et blueprint produisent de vrais changements", async ({
  page,
}) => {
  const boot = await (await page.request.get("/api/atelier")).json();
  const name = `Test données ${Date.now()}`;
  const created = await (
    await page.request.post("/api/atelier", {
      headers: { "x-atelier-csrf": boot.csrf },
      data: {
        title: name,
        slug: `/test-data-${Date.now()}`,
        sourceId: "accueil",
      },
    })
  ).json();
  await page.goto("/admin/atelier");
  await page.locator(".all-pages-button").click();
  await page
    .getByRole("textbox", { name: "Rechercher une page", exact: true })
    .fill(name);
  await page
    .getByRole("dialog")
    .getByRole("button", { name: new RegExp(name) })
    .first()
    .click();
  await page
    .getByRole("button", { name: "Tableur de démonstration", exact: true })
    .click();
  await page
    .getByRole("textbox", {
      name: "Titre de la publication, ligne 1",
      exact: true,
    })
    .fill("Méditation modifiée dans la grille");
  await page
    .getByRole("button", { name: "Ajouter une ligne", exact: true })
    .click();
  await expect(
    page.locator(".spreadsheet tbody tr:not(.blank-sheet-row)"),
  ).toHaveCount(7);
  await page
    .locator(".spreadsheet-studio")
    .getByRole("button", { name: "Enregistrer", exact: true })
    .click();
  await expect
    .poll(async () => {
      const p = await (
        await page.request.get(`/api/atelier/${created.id}`)
      ).json();
      return p.draft.sheet[0].title;
    })
    .toBe("Méditation modifiée dans la grille");
  await page
    .getByRole("button", { name: "Blueprint visuel", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Tester le graphe", exact: true })
    .click();
  await expect(page.locator(".graph-results pre")).toContainText(
    "Méditation modifiée dans la grille",
  );
});

test("petit écran : l’inspecteur et le menu de l’aperçu restent accessibles", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/admin/atelier");
  await page
    .getByRole("button", {
      name: "Afficher ou masquer les propriétés",
      exact: true,
    })
    .click();
  await expect(page.locator(".inspector")).toBeVisible();
  await page.getByRole("button", { name: "Aperçu", exact: true }).click();
  await page
    .getByRole("button", { name: "Aperçu mobile", exact: true })
    .click();
  const preview = page.getByRole("dialog");
  await preview
    .getByRole("button", { name: "Ouvrir le menu", exact: true })
    .click();
  await expect(
    preview.getByRole("button", { name: "Fermer le menu", exact: true }),
  ).toHaveAttribute("aria-expanded", "true");
  await page.keyboard.press("Escape");
  await expect(preview).toBeVisible();
  await expect(
    preview.getByRole("button", { name: "Ouvrir le menu", exact: true }),
  ).toHaveAttribute("aria-expanded", "false");
});

test("erreur de stockage : aucun faux succès et export de récupération disponible", async ({
  page,
}) => {
  const boot = await (await page.request.get("/api/atelier")).json();
  const name = `Test récupération ${Date.now()}`;
  await page.request.post("/api/atelier", {
    headers: { "x-atelier-csrf": boot.csrf },
    data: {
      title: name,
      slug: `/test-recovery-${Date.now()}`,
      sourceId: "accueil",
    },
  });
  await page.goto("/admin/atelier");
  await page.locator(".all-pages-button").click();
  await page
    .getByRole("textbox", { name: "Rechercher une page", exact: true })
    .fill(name);
  await page
    .getByRole("dialog")
    .getByRole("button", { name: new RegExp(name) })
    .first()
    .click();
  await page
    .locator(".inspector")
    .getByRole("button", { name: "Contenu", exact: true })
    .click();
  await page
    .locator(".inspector")
    .getByLabel("Texte", { exact: true })
    .fill("Ce travail doit rester récupérable");
  await page.route("**/api/atelier/*", async (route) => {
    if (route.request().method() === "PUT")
      await route.fulfill({
        status: 503,
        contentType: "application/json",
        body: JSON.stringify({
          error:
            "Stockage temporairement indisponible. Exportez votre brouillon.",
        }),
      });
    else await route.continue();
  });
  await page.keyboard.press("Control+s");
  await expect(page.locator(".toast-error[role=alert]")).toContainText(
    "Stockage temporairement indisponible",
  );
  await expect(page.locator(".save-status")).toContainText("Échec");
  await page
    .getByRole("button", { name: "Paramètres de la page", exact: true })
    .click();
  const download = page.waitForEvent("download");
  await page
    .getByRole("button", { name: "Exporter le brouillon complet" })
    .click();
  const recovered = await download;
  expect(recovered.suggestedFilename()).toContain("brouillon.json");
  const recoveredPath = await recovered.path();
  expect(recoveredPath).toBeTruthy();
  const recoveredDocument = JSON.parse(await readFile(recoveredPath!, "utf8"));
  expect(findElement(recoveredDocument, "hero-title")?.text).toBe(
    "Ce travail doit rester récupérable",
  );
});

test("création : une copie inclut le brouillon courant non encore enregistré", async ({
  page,
}) => {
  const boot = await (await page.request.get("/api/atelier")).json();
  const name = `Test source copie ${Date.now()}`;
  const source = await (
    await page.request.post("/api/atelier", {
      headers: { "x-atelier-csrf": boot.csrf },
      data: {
        title: name,
        slug: `/test-source-copy-${Date.now()}`,
        sourceId: "accueil",
      },
    })
  ).json();
  await page.goto("/admin/atelier");
  await page.locator(".all-pages-button").click();
  await page
    .getByRole("textbox", { name: "Rechercher une page", exact: true })
    .fill(name);
  await page
    .getByRole("dialog")
    .getByRole("button", { name: new RegExp(name) })
    .first()
    .click();
  await page
    .locator(".inspector")
    .getByRole("button", { name: "Contenu", exact: true })
    .click();
  await page
    .locator(".inspector")
    .getByLabel("Texte", { exact: true })
    .fill("Une copie fidèle à mon travail actuel");
  await page.locator(".add-page-button").click();
  const dialog = page.getByRole("dialog");
  await dialog.getByRole("button", { name: /Copier cette page/ }).click();
  const copyName = `Test copie fidèle ${Date.now()}`;
  await dialog.getByLabel("Nom de la page", { exact: true }).fill(copyName);
  await dialog
    .getByRole("textbox", { name: /Adresse de la page/ })
    .fill(`/test-copy-current-${Date.now()}`);
  await dialog
    .getByRole("button", { name: "Créer le brouillon", exact: true })
    .click();
  await expect(dialog).not.toBeVisible();
  await expect(page.locator(".header-breadcrumb")).toContainText(copyName);
  await expect(
    page.locator('.artboard-inner [data-element-id="hero-title"]'),
  ).toContainText("Une copie fidèle à mon travail actuel");
  const savedSource = await (
    await page.request.get(`/api/atelier/${source.id}`)
  ).json();
  expect(findElement(savedSource.draft, "hero-title")?.text).toBe(
    "Une copie fidèle à mon travail actuel",
  );
});
