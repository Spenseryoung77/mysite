import { Atelier } from "@/components/atelier/atelier";
import { getPage, listPages } from "@/lib/atelier/repository";
export const dynamic = "force-dynamic";
export default async function HomePage() {
  const pages = await listPages();
  const page = await getPage("accueil");
  return <Atelier initialPage={page} initialPages={pages} />;
}
