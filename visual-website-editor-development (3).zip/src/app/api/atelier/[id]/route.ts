import {
  getPage,
  saveDraft,
  reviewPage,
  publishPage,
  listVersions,
  restoreVersion,
  deletePage,
} from "@/lib/atelier/repository";
import {
  requireWrite,
  readBody,
  apiFailure,
  ApiError,
} from "@/lib/atelier/security";
export const dynamic = "force-dynamic";
type Context = { params: Promise<{ id: string }> };
export async function GET(request: Request, context: Context) {
  try {
    const { id } = await context.params;
    const mode = new URL(request.url).searchParams.get("mode");
    return Response.json(
      mode === "versions" ? await listVersions(id) : await getPage(id),
    );
  } catch (e) {
    return apiFailure(e);
  }
}
export async function PUT(request: Request, context: Context) {
  try {
    await requireWrite(request);
    const { id } = await context.params;
    const body = await readBody(request);
    if (!Number.isInteger(body.expectedRevision))
      throw new ApiError("La révision attendue est obligatoire.");
    return Response.json(
      await saveDraft(id, body.expectedRevision, body.document),
    );
  } catch (e) {
    return apiFailure(e);
  }
}
export async function POST(request: Request, context: Context) {
  try {
    await requireWrite(request);
    const { id } = await context.params;
    const body = await readBody(request);
    switch (body.action) {
      case "review":
        return Response.json(await reviewPage(id));
      case "publish":
        return Response.json(await publishPage(id, body.token, body.confirmed));
      case "restore":
        return Response.json(
          await restoreVersion(
            id,
            body.versionId,
            body.expectedPublishedRevision,
            body.confirmed,
          ),
        );
      case "delete":
        return Response.json(await deletePage(id, body.confirmed));
      default:
        throw new ApiError("Action non prise en charge.");
    }
  } catch (e) {
    return apiFailure(e);
  }
}
