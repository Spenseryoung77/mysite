import { listPages, createPage } from "@/lib/atelier/repository";
import {
  demoSession,
  requireWrite,
  readBody,
  apiFailure,
} from "@/lib/atelier/security";
export const dynamic = "force-dynamic";
export async function GET() {
  try {
    return Response.json({
      pages: await listPages(),
      csrf: await demoSession(),
      environment: "demonstration",
      role: "demo-admin",
    });
  } catch (e) {
    return apiFailure(e);
  }
}
export async function POST(request: Request) {
  try {
    await requireWrite(request);
    const body = await readBody(request);
    return Response.json(await createPage(body), { status: 201 });
  } catch (e) {
    return apiFailure(e);
  }
}
