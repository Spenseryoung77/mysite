import { redirect } from "next/navigation";
export default function Site() {
  redirect("/site/accueil");
}
