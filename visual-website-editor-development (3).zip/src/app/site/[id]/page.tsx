import { getPage } from "@/lib/atelier/repository";
import { PublishedPage } from "@/components/atelier/published-page";
import { notFound } from "next/navigation";
export const dynamic = "force-dynamic";
export default async function DemoSite({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  let page;
  try {
    page = await getPage(id);
  } catch {
    notFound();
  }
  const publicDocument = page.published
    ? {
        ...page.published,
        sheet: page.published.sheet.filter((r) => r.status === "Publié"),
        graph: { nodes: [], edges: [] },
      }
    : null;
  return (
    <>
      <div className="public-demo-bar">
        <span>
          SITE DE DÉMONSTRATION ·{" "}
          {page.published
            ? `VERSION PUBLIÉE ${page.publishedRevision}`
            : "PAGE NON PUBLIÉE"}
        </span>
        <span>Aucun lien avec le site réel</span>
        <a href="/admin/atelier">Retour à l’Atelier ↗</a>
      </div>
      {publicDocument ? (
        <PublishedPage document={publicDocument} />
      ) : (
        <main className="public-not-published">
          <h1>Une nouvelle histoire se prépare.</h1>
          <p>Cette page de démonstration n’est pas publiée.</p>
          <a className="outline-button" href="/admin/atelier">
            Revenir à l’Atelier
          </a>
        </main>
      )}
    </>
  );
}
