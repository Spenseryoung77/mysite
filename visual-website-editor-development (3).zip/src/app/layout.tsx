import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
export const metadata: Metadata = {
  title: "L’Atelier — Paroles Inspirées",
  description:
    "Votre espace de création visuelle. Composez, prévisualisez et publiez vos inspirations dans un environnement de démonstration isolé.",
  robots: { index: false, follow: false },
};
export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
