"use client";
import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type CSSProperties,
} from "react";
import {
  Feather,
  ChevronRight,
  ChevronDown,
  Undo2,
  Redo2,
  Eye,
  ArrowUpRight,
  ArrowRight,
  Check,
  CheckCheck,
  Cloud,
  CloudOff,
  LoaderCircle,
  Upload,
  Download,
  Plus,
  Minus,
  Monitor,
  Tablet,
  Smartphone,
  MousePointer2,
  Hand,
  Maximize,
  Grid2X2,
  Magnet,
  PanelLeftClose,
  PanelLeftOpen,
  PanelsTopLeft,
  Network,
  Table2,
  Palette,
  Image,
  CircleHelp,
  Settings2,
  History,
  Globe,
  LockKeyhole,
  Search,
  FileText,
  Home,
  Copy,
  Trash2,
  X,
  Save,
  Layers,
  Group,
  Ungroup,
  Sparkles,
  ExternalLink,
  Move,
  AlertTriangle,
  CheckCircle2,
  FolderOpen,
  BookOpen,
  Keyboard,
  LayoutTemplate,
  WandSparkles,
  CircleDot,
  MoreHorizontal,
} from "lucide-react";
import { Sidebar } from "./sidebar";
import { Inspector } from "./inspector";
import { PageRenderer } from "./page-renderer";
import { Blueprint, Spreadsheet } from "./data-studio";
import { Modal, IconButton } from "./ui";
import { atelierApi, downloadFile, type Review } from "@/lib/atelier/api";
import {
  cloneElement,
  diffDocuments,
  documentSchema,
  findElement,
  flatten,
  insertAfter,
  moveElement,
  removeElement,
  updateElement,
  type PageDocument,
  type PageElement,
  type PageRecord,
  type PageSummary,
  type Device,
  type ElementStyle,
  type VersionRecord,
} from "@/lib/atelier/model";
import { createDemoDocument, element } from "@/lib/atelier/seed";

type ModalName =
  | "new"
  | "catalog"
  | "preview"
  | "review"
  | "history"
  | "help"
  | "theme"
  | "media"
  | "settings"
  | null;
export function Atelier({
  initialPage,
  initialPages,
}: {
  initialPage: PageRecord;
  initialPages: PageSummary[];
}) {
  const [record, setRecord] = useState(initialPage),
    [doc, setDoc] = useState(initialPage.draft),
    [pages, setPages] = useState(initialPages),
    [selected, setSelected] = useState<string[]>(["hero-title"]),
    [device, setDevice] = useState<Device>("desktop"),
    [width, setWidth] = useState(1200),
    [zoom, setZoom] = useState(1),
    [mode, setMode] = useState<"design" | "blueprint" | "sheet">("design"),
    [sidebarTab, setSidebarTab] = useState("Pages"),
    [sidebarOpen, setSidebarOpen] = useState(true),
    [inspectorOpen, setInspectorOpen] = useState(false),
    [advanced, setAdvanced] = useState(false),
    [grid, setGrid] = useState(true),
    [snap, setSnap] = useState(true),
    [hand, setHand] = useState(false),
    [saveState, setSaveState] = useState<
      "saved" | "unsaved" | "saving" | "error"
    >("saved"),
    [ready, setReady] = useState(false),
    [lastSaved, setLastSaved] = useState<Date | null>(null),
    [modal, setModal] = useState<ModalName>(null),
    [toast, setToast] = useState<{ text: string; error: boolean } | null>(null),
    [review, setReview] = useState<Review | null>(null),
    [confirmed, setConfirmed] = useState(false),
    [busy, setBusy] = useState(false),
    [versions, setVersions] = useState<VersionRecord[]>([]),
    [versionPreview, setVersionPreview] = useState<VersionRecord | null>(null),
    [catalogQuery, setCatalogQuery] = useState(""),
    [catalogCategory, setCatalogCategory] = useState("Toutes les catégories"),
    [catalogStatus, setCatalogStatus] = useState("Tous les statuts"),
    [newTitle, setNewTitle] = useState(""),
    [newSlug, setNewSlug] = useState(""),
    [newSource, setNewSource] = useState("blank"),
    [previewDevice, setPreviewDevice] = useState<Device>("desktop"),
    [historyTick, setHistoryTick] = useState(0),
    [context, setContext] = useState<{ x: number; y: number } | null>(null),
    [canvasSize, setCanvasSize] = useState({ width: 850, height: 1160 });
  const modalRef = useRef<ModalName>(null);
  modalRef.current = modal;
  const docRef = useRef(doc),
    recordRef = useRef(record),
    savedRef = useRef(JSON.stringify(initialPage.draft)),
    undoRef = useRef<PageDocument[]>([]),
    redoRef = useRef<PageDocument[]>([]),
    clipboard = useRef<PageElement[]>([]),
    savingRef = useRef<Promise<PageRecord | null> | null>(null),
    toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null),
    canvasRef = useRef<HTMLDivElement>(null),
    pageRef = useRef<HTMLDivElement>(null),
    importRef = useRef<HTMLInputElement>(null),
    readyRef = useRef(false),
    actionRefs = useRef<Record<string, () => void>>({});
  docRef.current = doc;
  recordRef.current = record;
  const dirty = JSON.stringify(doc) !== savedRef.current;
  const current =
    selected.length === 1 ? findElement(doc, selected[0]) : undefined;
  const notify = useCallback((text: string, error = false) => {
    setToast({ text, error });
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), error ? 10000 : 4500);
  }, []);
  useEffect(() => {
    if (window.innerWidth < 901) setSidebarOpen(false);
    if (window.innerWidth < 701) {
      setDevice("mobile");
      setWidth(390);
    }
    atelierApi
      .initialize()
      .then((p) => {
        setPages(p);
        setReady(true);
        readyRef.current = true;
      })
      .catch((e) => notify(e.message, true));
  }, [notify]);
  useEffect(() => {
    const host = canvasRef.current;
    if (!host) return;
    const observer = new ResizeObserver((entries) => {
      setCanvasSize((s) => ({ ...s, width: entries[0].contentRect.width }));
    });
    observer.observe(host);
    return () => observer.disconnect();
  }, [mode, sidebarOpen]);
  useEffect(() => {
    const page = pageRef.current;
    if (!page) return;
    const observer = new ResizeObserver(() =>
      setCanvasSize((s) => ({ ...s, height: page.scrollHeight })),
    );
    observer.observe(page);
    return () => observer.disconnect();
  }, [doc, mode, device, width]);
  const commit = useCallback((next: PageDocument) => {
    if (JSON.stringify(next) === JSON.stringify(docRef.current)) return;
    undoRef.current = [
      ...undoRef.current.slice(-79),
      structuredClone(docRef.current),
    ];
    redoRef.current = [];
    docRef.current = next;
    setDoc(next);
    setSaveState("unsaved");
    setHistoryTick((v) => v + 1);
  }, []);
  const undo = useCallback(() => {
    const prev = undoRef.current.pop();
    if (!prev) return;
    redoRef.current.push(structuredClone(docRef.current));
    docRef.current = prev;
    setDoc(prev);
    setSaveState("unsaved");
    setHistoryTick((v) => v + 1);
  }, []);
  const redo = useCallback(() => {
    const next = redoRef.current.pop();
    if (!next) return;
    undoRef.current.push(structuredClone(docRef.current));
    docRef.current = next;
    setDoc(next);
    setSaveState("unsaved");
    setHistoryTick((v) => v + 1);
  }, []);
  const persist = useCallback(async (): Promise<PageRecord | null> => {
    if (savingRef.current) return savingRef.current;
    if (!readyRef.current) {
      notify(
        "La connexion au stockage est en cours. Patientez un instant.",
        true,
      );
      return null;
    }
    const snapshot = structuredClone(docRef.current),
      currentRecord = recordRef.current;
    if (JSON.stringify(snapshot) === savedRef.current) return currentRecord;
    setSaveState("saving");
    const promise = (async () => {
      try {
        const next = await atelierApi.save(
          currentRecord.id,
          currentRecord.revision,
          snapshot,
        );
        savedRef.current = JSON.stringify(snapshot);
        recordRef.current = next;
        setRecord(next);
        setPages((p) =>
          p.map((page) =>
            page.id === next.id
              ? ({
                  ...next,
                  draft: undefined,
                  published: undefined,
                } as PageSummary)
              : page,
          ),
        );
        setLastSaved(new Date());
        setSaveState(
          JSON.stringify(docRef.current) === savedRef.current
            ? "saved"
            : "unsaved",
        );
        return next;
      } catch (e) {
        setSaveState("error");
        notify(
          e instanceof Error
            ? e.message
            : "Échec de l’enregistrement. Exportez votre brouillon.",
          true,
        );
        return null;
      } finally {
        savingRef.current = null;
      }
    })();
    savingRef.current = promise;
    return promise;
  }, [notify]);
  const ensureSaved = async () => {
    for (let i = 0; i < 4; i++) {
      const r = await persist();
      if (!r) return null;
      if (JSON.stringify(docRef.current) === savedRef.current) return r;
    }
    notify(
      "Le document change encore. Terminez votre modification puis recommencez.",
      true,
    );
    return null;
  };
  useEffect(() => {
    if (!dirty || !ready || saveState === "error" || !record.compatible) return;
    const timer = setTimeout(() => void persist(), 4500);
    return () => clearTimeout(timer);
  }, [dirty, doc, ready, saveState, record.compatible, persist]);
  useEffect(() => {
    const before = (e: BeforeUnloadEvent) => {
      if (JSON.stringify(docRef.current) !== savedRef.current) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", before);
    return () => window.removeEventListener("beforeunload", before);
  }, []);
  function select(id: string, multiple = false) {
    setSelected((v) =>
      multiple
        ? v.includes(id)
          ? v.filter((s) => s !== id)
          : [...v, id]
        : [id],
    );
  }
  function protectedElement(id: string) {
    const walk = (els: PageElement[], shared = false): boolean | undefined => {
      for (const el of els) {
        if (el.id === id) return shared || el.shared || el.locked;
        const r = walk(el.children, shared || !!el.shared);
        if (r !== undefined) return r;
      }
      return undefined;
    };
    return walk(docRef.current.elements) || false;
  }
  function patch(id: string, change: Partial<PageElement>) {
    if (protectedElement(id) && !("locked" in change)) {
      notify(
        "Cet élément est verrouillé ou partagé. Déverrouillez-le ou détachez une copie locale.",
        true,
      );
      return;
    }
    commit(updateElement(docRef.current, id, change));
  }
  function style(id: string, change: ElementStyle, reset = false) {
    const el = findElement(docRef.current, id);
    if (!el) return;
    if (protectedElement(id)) {
      notify("Cet élément est protégé.", true);
      return;
    }
    const next = { ...el.styles };
    if (reset) delete next[device];
    else next[device] = { ...next[device], ...change };
    commit(updateElement(docRef.current, id, { styles: next }));
  }
  function duplicate() {
    let next = docRef.current;
    let last = "";
    for (const id of selected) {
      const el = findElement(next, id);
      if (!el) continue;
      const copy = cloneElement(el);
      next = insertAfter(next, id, copy);
      last = copy.id;
    }
    commit(next);
    if (last) setSelected([last]);
  }
  function remove() {
    if (selected.some(protectedElement)) {
      notify(
        "Un élément sélectionné est protégé. Détachez-le ou déverrouillez-le avant de le supprimer.",
        true,
      );
      return;
    }
    let next = docRef.current;
    for (const id of selected) next = removeElement(next, id);
    commit(next);
    setSelected([]);
  }
  function copy() {
    clipboard.current = selected
      .map((id) => findElement(docRef.current, id))
      .filter((e): e is PageElement => !!e)
      .map((e) => structuredClone(e));
    notify(`${clipboard.current.length} élément(s) copié(s) dans l’Atelier.`);
  }
  function paste() {
    if (!clipboard.current.length) {
      notify("Copiez d’abord un élément dans l’Atelier.");
      return;
    }
    let next = docRef.current;
    const ids: string[] = [];
    for (const e of clipboard.current) {
      const cloned = cloneElement(e);
      ids.push(cloned.id);
      next = insertAfter(next, selected.at(-1) || "", cloned);
    }
    commit(next);
    setSelected(ids);
  }
  function add(kind: PageElement["kind"]) {
    const id = crypto.randomUUID();
    const labels = {
      heading: "Un nouveau titre",
      text: "Votre texte commence ici. Partagez ce qui vous inspire.",
      button: "En savoir plus",
      image: "Image",
      section: "Nouvelle section",
      container: "Nouveau conteneur",
      header: "En-tête",
      footer: "Pied de page",
      card: "Nouvelle carte",
    };
    let el = element(
      id,
      kind,
      labels[kind],
      ["heading", "text", "button"].includes(kind) ? labels[kind] : "",
    );
    if (kind === "image") {
      el.src = "/images/mountains.jpg";
      el.alt = "Montagnes au lever du soleil";
      el.styles.desktop = { width: 480, height: 260 };
    }
    if (kind === "heading")
      el.styles.desktop = { fontSize: 38, fontWeight: 400, color: "#302d32" };
    if (kind === "button") {
      el.href = "#";
      el.role = "primary-button";
    }
    if (kind === "section" || kind === "container") {
      el.children = [
        element(
          crypto.randomUUID(),
          "text",
          "Texte de la section",
          "Une nouvelle idée prend forme. Personnalisez cette section.",
        ),
      ];
      el.styles.desktop = { padding: 40, backgroundColor: "#f4f0fa" };
    }
    let next = docRef.current;
    const target =
      selected.length === 1 ? findElement(next, selected[0]) : undefined;
    if (
      target &&
      ["section", "container", "card"].includes(target.kind) &&
      !protectedElement(target.id)
    )
      next = updateElement(next, target.id, {
        children: [...target.children, el],
      });
    else
      next = {
        ...next,
        elements: [
          ...next.elements.slice(0, -1),
          el,
          ...next.elements.slice(-1),
        ],
      };
    commit(next);
    setSelected([id]);
    setMode("design");
    notify("Élément ajouté au brouillon.");
    setTimeout(
      () =>
        document
          .querySelector(`[data-element-id="${id}"]`)
          ?.scrollIntoView({ block: "center", behavior: "smooth" }),
      60,
    );
  }
  function template(name: string) {
    const base = createDemoDocument();
    let els: PageElement[];
    if (name === "Page éditoriale")
      els = base.elements.filter((e) => !e.shared);
    else
      els = [
        base.elements[
          name === "Bannière inspirante"
            ? 1
            : name === "Grille de publications"
              ? 3
              : 2
        ],
      ];
    els = els.map(cloneElement);
    commit({
      ...docRef.current,
      elements: [
        ...docRef.current.elements.slice(0, -1),
        ...els,
        ...docRef.current.elements.slice(-1),
      ],
    });
    setSelected([els[0].id]);
    notify("Modèle inséré comme une copie indépendante.");
  }
  function detach() {
    const id = selected[0];
    const findShared = (els: PageElement[]): PageElement | undefined => {
      for (const e of els) {
        if (
          e.shared &&
          (e.id === id || flatten(e.children).some((c) => c.id === id))
        )
          return e;
        const found = findShared(e.children);
        if (found) return found;
      }
    };
    const root = findShared(docRef.current.elements);
    if (
      root &&
      window.confirm(
        "Détacher ce composant ? Vos modifications ne concerneront que cette page. Les autres pages ne changeront pas.",
      )
    ) {
      commit(
        updateElement(docRef.current, root.id, {
          shared: false,
          name: root.name + " — local",
        }),
      );
      notify("Copie locale détachée. Aucune autre page n’a changé.");
    }
  }
  function group() {
    if (selected.length < 2) {
      notify("Sélectionnez plusieurs éléments avec Maj + clic.", true);
      return;
    }
    if (selected.some(protectedElement)) {
      notify("Les éléments protégés ne peuvent pas être groupés.", true);
      return;
    }
    let found = false;
    const walk = (els: PageElement[]): PageElement[] => {
      const chosen = els.filter((e) => selected.includes(e.id));
      if (chosen.length === selected.length) {
        found = true;
        const g = element(
          crypto.randomUUID(),
          "container",
          "Groupe",
          "",
          chosen,
        );
        g.role = "group";
        const index = els.findIndex((e) => selected.includes(e.id));
        const out = els.filter((e) => !selected.includes(e.id));
        out.splice(index, 0, g);
        setSelected([g.id]);
        return out;
      }
      return els.map((e) => ({ ...e, children: walk(e.children) }));
    };
    const elements = walk(docRef.current.elements);
    if (found) commit({ ...docRef.current, elements });
    else
      notify(
        "Le groupement de ce lot est limité aux éléments d’un même conteneur.",
        true,
      );
  }
  function ungroup() {
    if (!current || current.role !== "group") return;
    const walk = (els: PageElement[]): PageElement[] =>
      els.flatMap((e) =>
        e.id === current.id
          ? e.children
          : [{ ...e, children: walk(e.children) }],
      );
    commit({ ...docRef.current, elements: walk(docRef.current.elements) });
    setSelected([]);
  }
  function onMove(id: string, target: string) {
    if (protectedElement(id) || protectedElement(target)) {
      notify("Déplacement impossible sur un élément protégé.", true);
      return;
    }
    commit(moveElement(docRef.current, id, target));
    notify("Élément déplacé après la cible.");
  }
  async function openPage(id: string) {
    if (id === recordRef.current.id) {
      setModal(null);
      setMode("design");
      return;
    }
    const summary = pages.find((p) => p.id === id);
    if (summary && !summary.compatible) {
      notify(
        "Page non compatible : l’espace membre et l’administration nécessitent une adaptation Flask. Aucune fausse donnée privée n’est affichée.",
        true,
      );
      return;
    }
    setBusy(true);
    try {
      if (JSON.stringify(docRef.current) !== savedRef.current) {
        const saved = await ensureSaved();
        if (!saved) return;
      }
      const next = await atelierApi.get(id);
      recordRef.current = next;
      docRef.current = next.draft;
      savedRef.current = JSON.stringify(next.draft);
      setRecord(next);
      setDoc(next.draft);
      setSelected(
        flatten(next.draft.elements).some((e) => e.id === "hero-title")
          ? ["hero-title"]
          : [],
      );
      undoRef.current = [];
      redoRef.current = [];
      setHistoryTick((v) => v + 1);
      setSaveState("saved");
      setMode("design");
      setModal(null);
      canvasRef.current?.scrollTo(0, 0);
    } catch (e) {
      notify((e as Error).message, true);
    } finally {
      setBusy(false);
    }
  }
  async function openReview() {
    setBusy(true);
    try {
      const saved = await ensureSaved();
      if (!saved) return;
      const r = await atelierApi.review(recordRef.current.id);
      setReview(r);
      setConfirmed(false);
      setModal("review");
    } catch (e) {
      notify((e as Error).message, true);
    } finally {
      setBusy(false);
    }
  }
  async function publish() {
    if (!review || !confirmed) return;
    setBusy(true);
    try {
      const next = await atelierApi.publish(recordRef.current.id, review.token);
      recordRef.current = next;
      setRecord(next);
      setPages((p) =>
        p.map((r) =>
          r.id === next.id
            ? {
                ...r,
                status: next.status,
                publishedRevision: next.publishedRevision,
              }
            : r,
        ),
      );
      setModal(null);
      notify(
        `Version ${next.publishedRevision} publiée sur le site de démonstration. Le site réel n’a pas été modifié.`,
      );
    } catch (e) {
      notify((e as Error).message, true);
      setModal(null);
    } finally {
      setBusy(false);
    }
  }
  async function history() {
    setBusy(true);
    try {
      setVersions(await atelierApi.versions(recordRef.current.id));
      setVersionPreview(null);
      setModal("history");
    } catch (e) {
      notify((e as Error).message, true);
    } finally {
      setBusy(false);
    }
  }
  async function restore(v: VersionRecord) {
    if (
      !window.confirm(
        `Restaurer la version ${v.revision} sur le faux site public ? Votre brouillon en cours sera conservé.`,
      )
    )
      return;
    setBusy(true);
    try {
      const next = await atelierApi.restore(
        recordRef.current.id,
        v.id,
        recordRef.current.publishedRevision,
      );
      setRecord(next);
      recordRef.current = next;
      setVersions(await atelierApi.versions(next.id));
      notify(
        "Version restaurée sur le site de démonstration. Votre brouillon est intact.",
      );
      setVersionPreview(null);
    } catch (e) {
      notify((e as Error).message, true);
    } finally {
      setBusy(false);
    }
  }
  async function create() {
    setBusy(true);
    try {
      if (
        JSON.stringify(docRef.current) !== savedRef.current &&
        !(await ensureSaved())
      )
        return;
      const slug = newSlug.startsWith("/") ? newSlug : `/${newSlug}`;
      const next = await atelierApi.create(
        newTitle,
        slug,
        newSource === "copy"
          ? record.id
          : newSource === "template"
            ? "modele-article"
            : undefined,
        newSource === "blank",
      );
      setPages((p) => [...p, next]);
      recordRef.current = next;
      docRef.current = next.draft;
      savedRef.current = JSON.stringify(next.draft);
      setRecord(next);
      setDoc(next.draft);
      setSelected([]);
      setSaveState("saved");
      undoRef.current = [];
      redoRef.current = [];
      setMode("design");
      setModal(null);
      notify("Votre nouvelle page est prête. Elle n’est pas publiée.");
    } catch (e) {
      notify((e as Error).message, true);
    } finally {
      setBusy(false);
    }
  }
  const exportDraft = () => {
    downloadFile(
      `${record.id}-brouillon.json`,
      JSON.stringify(docRef.current, null, 2),
    );
    notify("Brouillon exporté avec ses styles, données et liaisons.");
  };
  actionRefs.current = {
    save: () => void persist(),
    undo,
    redo,
    duplicate,
    remove,
    copy,
    paste,
    group,
    ungroup,
    search: () => {
      setModal("catalog");
      setCatalogQuery("");
    },
  };
  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const typing =
        target.isContentEditable ||
        ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName);
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === "s") {
        e.preventDefault();
        actionRefs.current.save();
        return;
      }
      if (typing || modalRef.current) return;
      if (mod) {
        const k = e.key.toLowerCase();
        const action =
          k === "z"
            ? e.shiftKey
              ? "redo"
              : "undo"
            : k === "y"
              ? "redo"
              : k === "d"
                ? "duplicate"
                : k === "c"
                  ? "copy"
                  : k === "v"
                    ? "paste"
                    : k === "g"
                      ? e.shiftKey
                        ? "ungroup"
                        : "group"
                      : k === "k"
                        ? "search"
                        : null;
        if (action) {
          e.preventDefault();
          actionRefs.current[action]?.();
        }
      } else if (["Delete", "Backspace"].includes(e.key)) {
        e.preventDefault();
        actionRefs.current.remove();
      } else if (e.key === "Escape") {
        setContext(null);
        setSelected([]);
      } else if (e.key === "h") setHand(true);
      else if (e.key === "v") setHand(false);
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, []);
  const setViewport = (d: Device) => {
    setDevice(d);
    setWidth(d === "desktop" ? 1200 : d === "tablet" ? 768 : 390);
    setZoom(1);
  };
  const scale = Math.min(1, Math.max(0.15, canvasSize.width / width)) * zoom;
  const selectedName =
    selected.length > 1
      ? `${selected.length} éléments sélectionnés`
      : current?.name || "Aucun élément sélectionné";
  const catalogPages = pages.filter(
    (p) =>
      p.title.toLowerCase().includes(catalogQuery.toLowerCase()) &&
      (catalogCategory === "Toutes les catégories" ||
        p.category === catalogCategory) &&
      (catalogStatus === "Tous les statuts" || p.status === catalogStatus),
  );
  const openNew = () => {
    setNewTitle("");
    setNewSlug("");
    setNewSource("blank");
    setModal("new");
  };
  const closeModal = useCallback(() => setModal(null), []);
  const changes = review ? diffDocuments(review.published, review.draft) : [];
  return (
    <div className="atelier-app">
      <header className="app-header" inert={modal !== null}>
        <a
          className="app-brand"
          href="/admin/atelier"
          aria-label="Accueil de l’Atelier"
        >
          <span className="brand-icon">
            <Feather size={23} strokeWidth={1.7} />
          </span>
          <span>
            <strong>
              L’Atelier<span className="brand-point">.</span>
            </strong>
            <small>PAROLES INSPIRÉES</small>
          </span>
        </a>
        <div className="header-breadcrumb">
          <span>Mon site</span>
          <ChevronRight size={13} />
          <button onClick={() => setModal("catalog")}>
            {record.title}
            <ChevronDown size={13} />
          </button>
          <span className="draft-badge">
            <span /> Brouillon
          </span>
        </div>
        <div className="header-actions">
          <div className="undo-group">
            <IconButton
              label="Annuler (Ctrl+Z)"
              disabled={!undoRef.current.length}
              onClick={undo}
            >
              <Undo2 size={17} />
            </IconButton>
            <IconButton
              label="Rétablir (Ctrl+Maj+Z)"
              disabled={!redoRef.current.length}
              onClick={redo}
            >
              <Redo2 size={17} />
            </IconButton>
          </div>
          <button
            className={`save-status save-${saveState}`}
            onClick={() => void persist()}
            title="Enregistrer le brouillon (Ctrl+S)"
          >
            {saveState === "saving" ? (
              <LoaderCircle size={15} className="spin" />
            ) : saveState === "error" ? (
              <CloudOff size={16} />
            ) : saveState === "unsaved" ? (
              <Cloud size={16} />
            ) : (
              <CheckCheck size={16} />
            )}
            <span>
              {saveState === "saving"
                ? "Enregistrement…"
                : saveState === "error"
                  ? "Échec · Réessayer"
                  : dirty
                    ? "Enregistrer"
                    : lastSaved
                      ? "Enregistré à " +
                        lastSaved.toLocaleTimeString("fr-FR", {
                          hour: "2-digit",
                          minute: "2-digit",
                        })
                      : "Tout est enregistré"}
            </span>
          </button>
          <button
            className="outline-button preview-button"
            onClick={() => {
              setPreviewDevice(device);
              setModal("preview");
            }}
          >
            <Eye size={15} />
            <span>Aperçu</span>
          </button>
          <button
            className="primary-button publish-button"
            disabled={busy || !ready}
            onClick={() => void openReview()}
          >
            {busy ? (
              <LoaderCircle size={15} className="spin" />
            ) : (
              <Upload size={15} />
            )}{" "}
            Publier <ChevronDown size={13} />
          </button>
          <button
            className="user-avatar"
            aria-label="Administrateur de démonstration"
            onClick={() => setModal("help")}
          >
            AD
          </button>
        </div>
      </header>
      <div className="app-body" inert={modal !== null}>
        <nav className="tool-rail" aria-label="Outils de l’Atelier">
          <div className="rail-main">
            <button
              className={`rail-button ${mode === "design" ? "active" : ""}`}
              onClick={() => setMode("design")}
              aria-label="Éditeur visuel"
              title="Éditeur visuel"
            >
              <PanelsTopLeft size={21} />
              <span>Éditeur</span>
            </button>
            <button
              className={`rail-button ${mode === "blueprint" ? "active" : ""}`}
              onClick={() => setMode("blueprint")}
              aria-label="Blueprint visuel"
              title="Blueprint visuel"
            >
              <Network size={21} />
              <span>Blueprint</span>
            </button>
            <button
              className={`rail-button ${mode === "sheet" ? "active" : ""}`}
              onClick={() => setMode("sheet")}
              aria-label="Tableur de démonstration"
              title="Tableur de démonstration"
            >
              <Table2 size={21} />
              <span>Tableur</span>
            </button>
            <span className="rail-divider" />
            <button
              className="rail-button"
              onClick={() => setModal("theme")}
              aria-label="Identité visuelle"
              title="Identité visuelle"
            >
              <Palette size={21} />
              <span>Styles</span>
            </button>
            <button
              className="rail-button"
              onClick={() => setModal("media")}
              aria-label="Bibliothèque de médias"
              title="Bibliothèque de médias"
            >
              <Image size={21} />
              <span>Médias</span>
            </button>
          </div>
          <div className="rail-bottom">
            <button
              className="rail-button"
              onClick={() => void history()}
              aria-label="Historique des versions"
              title="Historique des versions"
            >
              <History size={21} />
              <span>Versions</span>
            </button>
            <button
              className="rail-button"
              onClick={() => setModal("help")}
              aria-label="Aide et documentation"
              title="Aide et documentation"
            >
              <CircleHelp size={21} />
              <span>Aide</span>
            </button>
            <button
              className="rail-settings"
              aria-label="Paramètres de la page"
              title="Paramètres de la page"
              onClick={() => setModal("settings")}
            >
              <Settings2 size={20} />
            </button>
          </div>
        </nav>
        {sidebarOpen && (
          <Sidebar
            pages={pages}
            activeId={record.id}
            document={doc}
            selected={selected}
            onPage={(id) => void openPage(id)}
            onSelect={select}
            onNew={openNew}
            onAdd={add}
            onPatch={patch}
            onCatalog={() => setModal("catalog")}
            onTemplate={template}
            tab={sidebarTab}
            setTab={setSidebarTab}
          />
        )}
        <div className="workspace">
          <div className="workspace-toolbar">
            <div className="workspace-toolbar-left">
              <IconButton
                label={
                  sidebarOpen
                    ? "Replier le panneau gauche"
                    : "Ouvrir le panneau gauche"
                }
                onClick={() => setSidebarOpen(!sidebarOpen)}
              >
                {sidebarOpen ? (
                  <PanelLeftClose size={16} />
                ) : (
                  <PanelLeftOpen size={16} />
                )}
              </IconButton>
              <span className="toolbar-separator" />
              <div className="editing-mode">
                <button
                  className={mode === "design" ? "active" : ""}
                  onClick={() => setMode("design")}
                >
                  <MousePointer2 size={13} /> Conception
                </button>
                <button
                  className={mode === "blueprint" ? "active" : ""}
                  onClick={() => setMode("blueprint")}
                >
                  <Network size={13} /> Blueprint
                </button>
              </div>
            </div>
            {mode === "design" ? (
              <>
                <div
                  className="device-switcher"
                  role="group"
                  aria-label="Format de la planche"
                >
                  {(["desktop", "tablet", "mobile"] as const).map((d, i) => (
                    <IconButton
                      key={d}
                      label={["Ordinateur", "Tablette", "Mobile"][i]}
                      active={device === d}
                      onClick={() => setViewport(d)}
                    >
                      {i === 0 ? (
                        <Monitor size={17} />
                      ) : i === 1 ? (
                        <Tablet size={17} />
                      ) : (
                        <Smartphone size={17} />
                      )}
                    </IconButton>
                  ))}
                </div>
                <div className="workspace-toolbar-right">
                  <label className="canvas-width-input">
                    <input
                      type="number"
                      aria-label="Largeur de la planche"
                      value={width}
                      min={320}
                      max={1920}
                      onChange={(e) =>
                        setWidth(
                          Math.min(1920, Math.max(320, Number(e.target.value))),
                        )
                      }
                    />
                    <span>px</span>
                    <ChevronDown size={11} />
                  </label>
                  <IconButton
                    label="Afficher ou masquer les propriétés"
                    className="mobile-inspector-toggle"
                    active={inspectorOpen}
                    onClick={() => {
                      setInspectorOpen(!inspectorOpen);
                      setSidebarOpen(false);
                    }}
                  >
                    <Settings2 size={16} />
                  </IconButton>
                  <span className="toolbar-separator" />
                  <button
                    className={`advanced-switch ${advanced ? "on" : ""}`}
                    onClick={() => setAdvanced(!advanced)}
                    role="switch"
                    aria-checked={advanced}
                  >
                    <span>Mode avancé</span>
                    <i />
                  </button>
                </div>
              </>
            ) : (
              <div className="workspace-toolbar-right">
                <span className="small-muted">
                  Lié au brouillon de {record.title}
                </span>
              </div>
            )}
          </div>
          <div
            className={`workspace-content ${inspectorOpen ? "mobile-inspector-open" : ""}`}
          >
            {mode === "design" ? (
              <>
                <main className={`canvas-host ${grid ? "with-grid" : ""}`}>
                  <div
                    className={`canvas-scroller ${hand ? "hand-tool" : ""}`}
                    ref={canvasRef}
                    onPointerDown={(e) => {
                      if (!hand) return;
                      const target = e.currentTarget,
                        startX = e.clientX,
                        startY = e.clientY,
                        startLeft = target.scrollLeft,
                        startTop = target.scrollTop;
                      target.setPointerCapture(e.pointerId);
                      const move = (ev: PointerEvent) => {
                        target.scrollLeft = startLeft - (ev.clientX - startX);
                        target.scrollTop = startTop - (ev.clientY - startY);
                      };
                      const up = () => {
                        target.removeEventListener("pointermove", move);
                        target.removeEventListener("pointerup", up);
                      };
                      target.addEventListener("pointermove", move);
                      target.addEventListener("pointerup", up, { once: true });
                    }}
                    onClick={(e) => {
                      if (e.target === e.currentTarget) setSelected([]);
                    }}
                  >
                    <div
                      className="artboard-wrap"
                      style={{ width: width * scale }}
                    >
                      <div className="artboard-caption">
                        <span>
                          <Home size={11} />
                          {record.id === "accueil"
                            ? "PAGE D’ACCUEIL"
                            : record.title.toUpperCase()}
                        </span>
                        <span>
                          {width} × {canvasSize.height}{" "}
                          <span className="artboard-status-dot" />
                        </span>
                      </div>
                      <div
                        className="artboard-outer"
                        style={{
                          width: width * scale,
                          height: canvasSize.height * scale,
                        }}
                      >
                        <div
                          ref={pageRef}
                          className="artboard-inner"
                          style={{
                            width,
                            transform: `scale(${scale})`,
                            pointerEvents: hand ? "none" : undefined,
                          }}
                        >
                          <PageRenderer
                            document={doc}
                            device={device}
                            editable
                            selected={selected}
                            onSelect={select}
                            onText={(id, text) => patch(id, { text })}
                            onMove={onMove}
                            onResize={(id, w, h) =>
                              style(id, {
                                width: snap ? Math.round(w / 8) * 8 : w,
                                height: snap ? Math.round(h / 8) * 8 : h,
                              })
                            }
                            onContext={(e, id) => {
                              setSelected([id]);
                              setContext({
                                x: Math.min(e.clientX, window.innerWidth - 220),
                                y: Math.min(
                                  e.clientY,
                                  window.innerHeight - 300,
                                ),
                              });
                            }}
                          />
                        </div>
                      </div>
                      <div className="add-section-area">
                        <button
                          onClick={() => {
                            setSidebarTab("Bibliothèque");
                            setSidebarOpen(true);
                          }}
                        >
                          <Plus size={16} /> Ajouter une section
                        </button>
                        <span>Une nouvelle idée commence ici.</span>
                      </div>
                    </div>
                  </div>
                  <div className="canvas-floating-toolbar">
                    <div className="canvas-tool-group">
                      <IconButton
                        label="Sélection (V)"
                        active={!hand}
                        onClick={() => setHand(false)}
                      >
                        <MousePointer2 size={17} />
                      </IconButton>
                      <IconButton
                        label="Déplacer la planche (H)"
                        active={hand}
                        onClick={() => setHand(true)}
                      >
                        <Hand size={17} />
                      </IconButton>
                    </div>
                    <span className="toolbar-separator" />
                    <IconButton
                      label="Réduire le zoom"
                      onClick={() => setZoom((z) => Math.max(0.3, z - 0.1))}
                    >
                      <Minus size={15} />
                    </IconButton>
                    <button
                      className="zoom-value"
                      onClick={() => setZoom(1)}
                      title="Ajuster la page à l’espace disponible"
                    >
                      {Math.round(scale * 100)} %<ChevronDown size={11} />
                    </button>
                    <IconButton
                      label="Agrandir le zoom"
                      onClick={() => setZoom((z) => Math.min(2, z + 0.1))}
                    >
                      <Plus size={15} />
                    </IconButton>
                    <IconButton
                      label="Ajuster la planche"
                      onClick={() => setZoom(1)}
                    >
                      <Maximize size={15} />
                    </IconButton>
                    <span className="toolbar-separator" />
                    <IconButton
                      label={grid ? "Masquer la grille" : "Afficher la grille"}
                      active={grid}
                      onClick={() => setGrid(!grid)}
                    >
                      <Grid2X2 size={16} />
                    </IconButton>
                    <IconButton
                      label={
                        snap
                          ? "Désactiver l’aimantation à 8 px"
                          : "Activer l’aimantation à 8 px"
                      }
                      active={snap}
                      onClick={() => setSnap(!snap)}
                    >
                      <Magnet size={16} />
                    </IconButton>
                  </div>
                  {selected.length > 1 && (
                    <div className="multi-selection-bar">
                      <Layers size={14} />
                      {selected.length} éléments
                      <button onClick={group}>
                        <Group size={14} /> Grouper
                      </button>
                      <button onClick={duplicate}>
                        <Copy size={14} />
                      </button>
                      <button onClick={remove}>
                        <Trash2 size={14} />
                      </button>
                    </div>
                  )}
                </main>
                <Inspector
                  document={doc}
                  element={current}
                  device={device}
                  onPatch={(p) => current && patch(current.id, p)}
                  onStyle={(s, reset) => current && style(current.id, s, reset)}
                  onDocument={commit}
                  onDuplicate={duplicate}
                  onDelete={remove}
                  onDetach={detach}
                  advanced={advanced}
                  onHistory={() => void history()}
                />
              </>
            ) : mode === "blueprint" ? (
              <Blueprint
                document={doc}
                onChange={commit}
                onSave={() => void persist()}
                notify={notify}
              />
            ) : (
              <Spreadsheet
                document={doc}
                onChange={commit}
                onSave={() => void persist()}
                notify={notify}
              />
            )}
          </div>
          <footer className="workspace-statusbar">
            <div>
              <FileText size={11} />
              <span>{record.title}</span>
              <ChevronRight size={10} />
              <span>
                {mode === "design"
                  ? selectedName
                  : mode === "sheet"
                    ? "Tableur de démonstration"
                    : "Blueprint"}
              </span>
            </div>
            <div>
              <span className="status-private">
                <LockKeyhole size={10} /> Brouillon privé
              </span>
              <span className="toolbar-separator" />
              <span className="demo-indicator">
                <span />
                Aucun impact sur le site réel
              </span>
            </div>
          </footer>
        </div>
      </div>
      {context && (
        <>
          <div className="context-dismiss" onClick={() => setContext(null)} />
          <div
            className="context-menu"
            style={{ left: context.x, top: context.y }}
            role="menu"
          >
            {[
              { label: "Copier", icon: Copy, key: "⌘ C", action: copy },
              { label: "Coller", icon: Copy, key: "⌘ V", action: paste },
              { label: "Dupliquer", icon: Copy, key: "⌘ D", action: duplicate },
              {
                label: "Grouper la sélection",
                icon: Group,
                key: "⌘ G",
                action: group,
              },
              ...(current?.role === "group"
                ? [
                    {
                      label: "Dégrouper",
                      icon: Ungroup,
                      key: "",
                      action: ungroup,
                    },
                  ]
                : []),
              { label: "Supprimer", icon: Trash2, key: "⌫", action: remove },
            ].map((item) => (
              <button
                role="menuitem"
                key={item.label}
                onClick={() => {
                  item.action();
                  setContext(null);
                }}
              >
                <item.icon size={14} />
                {item.label}
                <kbd>{item.key}</kbd>
              </button>
            ))}
          </div>
        </>
      )}
      {toast && (
        <div
          className={`toast ${toast.error ? "toast-error" : ""}`}
          role={toast.error ? "alert" : "status"}
        >
          {toast.error ? (
            <AlertTriangle size={19} />
          ) : (
            <CheckCircle2 size={19} />
          )}
          <span>{toast.text}</span>
          <button aria-label="Fermer le message" onClick={() => setToast(null)}>
            <X size={15} />
          </button>
        </div>
      )}
      {modal === "new" && (
        <Modal
          title="Une nouvelle page, une nouvelle histoire."
          subtitle="Créez librement. Rien ne sera publié automatiquement."
          onClose={closeModal}
        >
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void create();
            }}
          >
            <div className="new-page-options">
              {[
                {
                  id: "blank",
                  icon: FileText,
                  title: "Page vierge",
                  desc: "Une toile à votre image",
                },
                {
                  id: "copy",
                  icon: Copy,
                  title: "Copier cette page",
                  desc: "Gardez une longueur d’avance",
                },
                {
                  id: "template",
                  icon: LayoutTemplate,
                  title: "Partir d’un modèle",
                  desc: "L’inspiration comme point de départ",
                },
              ].map((o) => (
                <button
                  type="button"
                  key={o.id}
                  onClick={() => setNewSource(o.id)}
                  className={newSource === o.id ? "selected" : ""}
                >
                  <o.icon size={22} />
                  <strong>{o.title}</strong>
                  <span>{o.desc}</span>
                  {newSource === o.id && <Check size={13} />}
                </button>
              ))}
            </div>
            <div className="modal-form-fields">
              <label className="field-label">
                Nom de la page
                <input
                  autoFocus
                  required
                  maxLength={150}
                  placeholder="Ex. Une nouvelle espérance"
                  value={newTitle}
                  onChange={(e) => {
                    setNewTitle(e.target.value);
                    setNewSlug(
                      "/" +
                        e.target.value
                          .toLowerCase()
                          .normalize("NFD")
                          .replace(/[\u0300-\u036f]/g, "")
                          .replace(/[^a-z0-9]+/g, "-")
                          .replace(/-$/, ""),
                    );
                  }}
                />
              </label>
              <label className="field-label">
                Adresse de la page
                <input
                  required
                  pattern="/[a-z0-9/\-]*"
                  placeholder="/ma-nouvelle-page"
                  value={newSlug}
                  onChange={(e) => setNewSlug(e.target.value)}
                />
                <small>
                  L’unicité de l’adresse est vérifiée par le serveur.
                </small>
              </label>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="outline-button"
                onClick={closeModal}
              >
                Annuler
              </button>
              <button
                type="submit"
                className="primary-button"
                disabled={busy || !newTitle.trim() || !newSlug}
              >
                {busy ? (
                  <LoaderCircle size={14} className="spin" />
                ) : (
                  <Plus size={14} />
                )}{" "}
                Créer le brouillon
              </button>
            </div>
          </form>
        </Modal>
      )}
      {modal === "catalog" && (
        <Modal
          title="Toutes vos pages, un seul atelier."
          subtitle="Inventaire fictif représentatif. Le site réel n’est pas connecté."
          onClose={closeModal}
          wide
        >
          <div className="catalog-tools">
            <div className="search-box">
              <Search size={15} />
              <input
                autoFocus
                aria-label="Rechercher une page"
                placeholder="Rechercher une page…"
                value={catalogQuery}
                onChange={(e) => setCatalogQuery(e.target.value)}
              />
            </div>
            <select
              aria-label="Catégorie de page"
              value={catalogCategory}
              onChange={(e) => setCatalogCategory(e.target.value)}
            >
              {[
                "Toutes les catégories",
                "Pages publiques",
                "Modèles",
                "Espaces privés",
              ].map((v) => (
                <option key={v}>{v}</option>
              ))}
            </select>
            <select
              aria-label="Statut de page"
              value={catalogStatus}
              onChange={(e) => setCatalogStatus(e.target.value)}
            >
              {[
                "Tous les statuts",
                "Publié",
                "Brouillon",
                "Non compatible",
              ].map((v) => (
                <option key={v}>{v}</option>
              ))}
            </select>
            <button className="primary-button" onClick={openNew}>
              <Plus size={14} /> Nouvelle page
            </button>
          </div>
          <div className="catalog-table-scroll">
            <table className="catalog-table">
              <thead>
                <tr>
                  <th>Page & adresse</th>
                  <th>Type</th>
                  <th>Statut</th>
                  <th>Édition visuelle</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {catalogPages.map((p) => (
                  <tr key={p.id}>
                    <td>
                      <button onClick={() => void openPage(p.id)}>
                        <span className="catalog-page-icon">
                          {p.id === "accueil" ? (
                            <Home size={17} />
                          ) : (
                            <FileText size={17} />
                          )}
                        </span>
                        <span>
                          <strong>{p.title}</strong>
                          <small>{p.slug}</small>
                        </span>
                      </button>
                    </td>
                    <td>
                      {p.kind}
                      <small>{p.category}</small>
                    </td>
                    <td>
                      <span
                        className={`status-pill ${p.status === "Publié" ? "published" : p.status === "Brouillon" ? "draft" : "incompatible"}`}
                      >
                        {p.status}
                      </span>
                    </td>
                    <td>
                      {p.compatible ? (
                        <span className="compatible-text">
                          <Check size={12} /> Compatible
                        </span>
                      ) : (
                        <span className="small-muted">Adaptation requise</span>
                      )}
                    </td>
                    <td>
                      {!p.publishedRevision ? (
                        <IconButton
                          label={`Supprimer ${p.title}`}
                          onClick={async () => {
                            if (
                              !window.confirm(
                                `Supprimer définitivement le brouillon « ${p.title} » ?`,
                              )
                            )
                              return;
                            try {
                              await atelierApi.delete(p.id);
                              setPages((v) => v.filter((x) => x.id !== p.id));
                              if (recordRef.current.id === p.id) {
                                savedRef.current = JSON.stringify(
                                  docRef.current,
                                );
                                await openPage("accueil");
                              }
                              notify("Brouillon supprimé.");
                            } catch (e) {
                              notify((e as Error).message, true);
                            }
                          }}
                        >
                          <Trash2 size={14} />
                        </IconButton>
                      ) : (
                        <IconButton
                          label={`Ouvrir ${p.title}`}
                          onClick={() => void openPage(p.id)}
                        >
                          <ArrowUpRight size={15} />
                        </IconButton>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!catalogPages.length && (
              <p className="empty-small">
                Aucune page ne correspond à votre recherche.
              </p>
            )}
          </div>
          <div className="catalog-note">
            <LockKeyhole size={14} /> Rôle actuel : administrateur de
            démonstration. Aucun compte ni contenu réel.
          </div>
        </Modal>
      )}
      {modal === "preview" && (
        <Modal
          title="Un aperçu de votre inspiration."
          subtitle="Brouillon non publié · les interactions sont actives dans cet aperçu."
          onClose={closeModal}
          wide
        >
          <div className="preview-toolbar">
            <div className="device-switcher">
              {(["desktop", "tablet", "mobile"] as const).map((d, i) => (
                <IconButton
                  key={d}
                  label={`Aperçu ${["ordinateur", "tablette", "mobile"][i]}`}
                  active={previewDevice === d}
                  onClick={() => setPreviewDevice(d)}
                >
                  {i === 0 ? (
                    <Monitor size={17} />
                  ) : i === 1 ? (
                    <Tablet size={17} />
                  ) : (
                    <Smartphone size={17} />
                  )}
                </IconButton>
              ))}
            </div>
            <span>
              {previewDevice === "desktop"
                ? "Ordinateur"
                : previewDevice === "tablet"
                  ? "Tablette · 768 px"
                  : "Mobile · 390 px"}
            </span>
            <a
              href={`/site/${record.id}`}
              className="text-button"
              target="_blank"
              rel="noreferrer"
            >
              Voir la version publiée <ExternalLink size={13} />
            </a>
          </div>
          <div className="preview-scroll">
            <div className={`preview-document preview-${previewDevice}`}>
              <PageRenderer document={doc} device={previewDevice} />
            </div>
          </div>
        </Modal>
      )}
      {modal === "review" && review && (
        <Modal
          title="Un dernier regard avant de publier."
          subtitle="Vous publiez uniquement sur le site fictif de démonstration."
          onClose={closeModal}
          wide
        >
          <div className="review-summary">
            <div className="review-page-icon">
              <FileText size={21} />
            </div>
            <div>
              <strong>{review.draft.title}</strong>
              <span>
                {review.draft.slug} · Brouillon révision {review.revision}
              </span>
            </div>
            <span className="review-count">{changes.length} changement(s)</span>
          </div>
          <div className="review-previews">
            <div>
              <h3>
                <Globe size={12} /> Version publiée
              </h3>
              <div className="review-mini-page">
                {review.published ? (
                  <div>
                    <PageRenderer document={review.published} />
                  </div>
                ) : (
                  <p>Cette page n’a pas encore été publiée.</p>
                )}
              </div>
            </div>
            <div>
              <h3>
                <Sparkles size={12} /> Votre brouillon
              </h3>
              <div className="review-mini-page">
                <div>
                  <PageRenderer document={review.draft} />
                </div>
              </div>
            </div>
          </div>
          <div className="review-changes">
            {changes.length ? (
              changes.map((c, i) => (
                <div key={i}>
                  <span className="change-dot" />
                  <strong>{c.name}</strong>
                  <span>{c.detail}</span>
                </div>
              ))
            ) : (
              <div>
                <CheckCircle2 size={15} />
                <span>Le brouillon est identique à la version publiée.</span>
              </div>
            )}
          </div>
          <div className="review-scope">
            <LockKeyhole size={16} />
            <p>
              <strong>Portée : cette page uniquement.</strong> Aucun composant
              partagé ne sera propagé. Le site réel n’est pas connecté.
            </p>
          </div>
          <label className="publish-confirm">
            <input
              type="checkbox"
              checked={confirmed}
              onChange={(e) => setConfirmed(e.target.checked)}
            />
            <span>
              J’ai vérifié cette version et je confirme sa publication fictive.
            </span>
          </label>
          <div className="modal-footer">
            <button className="outline-button" onClick={closeModal}>
              Continuer à créer
            </button>
            <button
              className="primary-button"
              disabled={!confirmed || busy || !changes.length}
              onClick={() => void publish()}
            >
              {busy ? (
                <LoaderCircle size={15} className="spin" />
              ) : (
                <Upload size={15} />
              )}{" "}
              Confirmer la publication
            </button>
          </div>
        </Modal>
      )}
      {modal === "history" && (
        <Modal
          title="Chaque version a son histoire."
          subtitle="La restauration modifie le faux site public, jamais votre brouillon en cours."
          onClose={closeModal}
          wide
        >
          <div className="version-workspace">
            <div className="version-list">
              {versions.map((v) => (
                <div
                  className={`version-card ${versionPreview?.id === v.id ? "selected" : ""}`}
                  key={v.id}
                >
                  <div className="version-marker">
                    <History size={17} />
                  </div>
                  <div>
                    <strong>{v.label}</strong>
                    <span>{new Date(v.createdAt).toLocaleString("fr-FR")}</span>
                    <small>Version publiée {v.revision}</small>
                    <div className="version-actions">
                      <button
                        className="text-button"
                        onClick={() => setVersionPreview(v)}
                      >
                        <Eye size={12} /> Aperçu
                      </button>
                      <button
                        className="text-button"
                        disabled={busy}
                        onClick={() => void restore(v)}
                      >
                        Restaurer
                      </button>
                    </div>
                  </div>
                </div>
              ))}
              {!versions.length && (
                <p className="empty-small">
                  Aucune version publiée. Votre première publication créera
                  l’historique.
                </p>
              )}
            </div>
            <div className="version-preview">
              {versionPreview ? (
                <>
                  <div className="version-preview-label">
                    Aperçu de la version {versionPreview.revision}
                  </div>
                  <div className="version-mini-page">
                    <PageRenderer document={versionPreview.document} />
                  </div>
                </>
              ) : (
                <div className="history-placeholder">
                  <History size={36} />
                  <h3>Rien ne se perd.</h3>
                  <p>
                    Choisissez une version pour la prévisualiser avant de la
                    restaurer.
                  </p>
                </div>
              )}
            </div>
          </div>
        </Modal>
      )}
      {modal === "theme" && (
        <Modal
          title="Une identité qui vous ressemble."
          subtitle="Ces styles sont appliqués au brouillon de cette page, jamais à tout le site."
          onClose={closeModal}
        >
          <div className="theme-list">
            {[
              {
                name: "Terre & lumière",
                primary: "#74634b",
                background: "#ffffff",
                font: "Georgia",
                desc: "Éditorial, chaleureux et intemporel",
              },
              {
                name: "Jardin de paix",
                primary: "#466953",
                background: "#f4f7f1",
                font: "Georgia",
                desc: "Naturel, apaisant et généreux",
              },
              {
                name: "Nouvel élan",
                primary: "#7b52b5",
                background: "#faf8ff",
                font: "Inter",
                desc: "Lumineux, contemporain et affirmé",
              },
            ].map((t) => (
              <button
                key={t.name}
                className={doc.theme.primary === t.primary ? "selected" : ""}
                onClick={() => {
                  commit({
                    ...docRef.current,
                    theme: {
                      primary: t.primary,
                      background: t.background,
                      font: t.font,
                    },
                  });
                  notify(`Thème « ${t.name} » appliqué à cette page.`);
                }}
              >
                <div
                  className="theme-sample"
                  style={{
                    background: t.background,
                    color: t.primary,
                    fontFamily:
                      t.font === "Inter" ? '"Inter Variable", Arial' : t.font,
                  }}
                >
                  <span>Aa</span>
                  <i style={{ background: t.primary }} />
                  <i style={{ background: t.primary, opacity: 0.45 }} />
                  <i style={{ background: t.primary, opacity: 0.15 }} />
                </div>
                <div>
                  <strong>{t.name}</strong>
                  <small>{t.desc}</small>
                </div>
                {doc.theme.primary === t.primary && <CheckCircle2 size={19} />}
              </button>
            ))}
          </div>
          <div className="modal-form-fields">
            <label className="field-label">
              Couleur d’accent personnalisée
              <input
                type="color"
                value={doc.theme.primary}
                onChange={(e) =>
                  commit({
                    ...docRef.current,
                    theme: { ...docRef.current.theme, primary: e.target.value },
                  })
                }
              />
            </label>
            <p className="small-field-hint">
              Les thèmes globaux, favoris et temporaires pour l’espace membre
              sont prévus dans un prochain lot.
            </p>
          </div>
          <div className="modal-footer">
            <button className="primary-button" onClick={closeModal}>
              Revenir à la planche <ArrowRight size={14} />
            </button>
          </div>
        </Modal>
      )}
      {modal === "media" && (
        <Modal
          title="Des images qui racontent."
          subtitle="Photographies locales de démonstration · les originaux ne sont jamais écrasés."
          onClose={closeModal}
        >
          <div className="media-grid">
            {[
              {
                src: "mountains",
                name: "Une nouvelle lumière",
                alt: "Lever de soleil sur les montagnes",
              },
              {
                src: "bible",
                name: "À la source des mots",
                alt: "Une Bible ouverte à la lumière naturelle",
              },
              {
                src: "peace",
                name: "Un instant de paix",
                alt: "Une femme paisible dans la lumière du soleil",
              },
            ].map((m) => (
              <button
                key={m.src}
                onClick={() => {
                  if (current && ["image", "section"].includes(current.kind)) {
                    patch(current.id, {
                      src: `/images/${m.src}.jpg`,
                      alt: m.alt,
                    });
                    setModal(null);
                  } else {
                    const el = {
                      ...element(crypto.randomUUID(), "image", m.name),
                      src: `/images/${m.src}.jpg`,
                      alt: m.alt,
                      styles: { desktop: { width: 500, height: 300 } },
                    };
                    commit({
                      ...docRef.current,
                      elements: [
                        ...docRef.current.elements.slice(0, -1),
                        el,
                        ...docRef.current.elements.slice(-1),
                      ],
                    });
                    setSelected([el.id]);
                    setModal(null);
                  }
                  notify("Image ajoutée au brouillon.");
                }}
              >
                <img src={`/images/${m.src}.jpg`} alt={m.alt} />
                <strong>{m.name}</strong>
                <span>
                  Utiliser cette image <Plus size={12} />
                </span>
              </button>
            ))}
          </div>
          <div className="catalog-note">
            <Image size={14} /> Sources : Quang Nguyen Vinh, Nothing Ahead et
            Ray Lei / Pexels. Téléversement de fichiers : à réaliser lors de
            l’intégration.
          </div>
        </Modal>
      )}
      {modal === "settings" && (
        <Modal
          title="Les détails de votre page."
          subtitle="Les changements d’adresse ne sont pas appliqués au site réel."
          onClose={closeModal}
        >
          <div className="modal-form-fields">
            <label className="field-label">
              Nom de la page
              <input
                value={doc.title}
                onChange={(e) =>
                  commit({ ...docRef.current, title: e.target.value })
                }
              />
            </label>
            <label className="field-label">
              Adresse
              <input
                value={doc.slug}
                onChange={(e) =>
                  commit({ ...docRef.current, slug: e.target.value })
                }
              />
              <small>
                Une adresse modifiée peut casser des liens. Aucune redirection
                n’est créée automatiquement.
              </small>
            </label>
            <button
              className="outline-button"
              onClick={() => {
                exportDraft();
              }}
            >
              <Download size={14} /> Exporter le brouillon complet
            </button>
            <button
              className="outline-button"
              onClick={() => importRef.current?.click()}
            >
              <Upload size={14} /> Importer un document versionné
            </button>
            <input
              type="file"
              hidden
              accept="application/json,.json"
              ref={importRef}
              onChange={async (e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                try {
                  if (f.size > 1500000)
                    throw new Error("Fichier trop volumineux.");
                  const result = documentSchema.safeParse(
                    JSON.parse(await f.text()),
                  );
                  if (!result.success)
                    throw new Error(result.error.issues[0].message);
                  if (
                    !window.confirm(
                      "Importer dans ce brouillon ? Cette action est annulable et ne publie rien.",
                    )
                  )
                    return;
                  commit({
                    ...result.data,
                    title: docRef.current.title,
                    slug: docRef.current.slug,
                  });
                  notify(
                    "Document validé et importé. Le nom et l’adresse de la page sont conservés.",
                  );
                } catch (err) {
                  notify((err as Error).message, true);
                }
                e.target.value = "";
              }}
            />
            <div className="settings-meta">
              <span>
                Format du document <strong>Atelier v1</strong>
              </span>
              <span>
                Révision serveur <strong>{record.revision}</strong>
              </span>
              <span>
                Publication fictive <strong>v{record.publishedRevision}</strong>
              </span>
            </div>
          </div>
          <div className="modal-footer">
            <button className="outline-button" onClick={closeModal}>
              Fermer
            </button>
            <button
              className="primary-button"
              onClick={async () => {
                if (await persist()) setModal(null);
              }}
            >
              <Save size={14} /> Enregistrer le brouillon
            </button>
          </div>
        </Modal>
      )}
      {modal === "help" && (
        <Modal
          title="Bienvenue dans votre espace de création."
          subtitle="Premier lot fonctionnel · prototype autonome pour Paroles Inspirées."
          onClose={closeModal}
          wide
        >
          <div className="help-intro">
            <div className="help-feather">
              <Feather size={31} />
            </div>
            <p>
              Explorez, composez, recommencez.
              <br />
              <strong>Votre site public reste à l’abri.</strong>
            </p>
            <span className="demo-chip">Administrateur de démo</span>
          </div>
          <div className="help-columns">
            <div>
              <h3>Les premiers pas</h3>
              <ol>
                <li>Choisissez une page dans le panneau gauche.</li>
                <li>Cliquez sur un élément, puis modifiez ses propriétés.</li>
                <li>
                  Double-cliquez sur un texte pour l’éditer sur la planche.
                </li>
                <li>
                  Enregistrez, prévisualisez puis comparez avant de publier.
                </li>
              </ol>
              <h3>Un atelier au clavier</h3>
              <div className="shortcut-row">
                <span>Enregistrer le brouillon</span>
                <kbd>Ctrl / ⌘ S</kbd>
              </div>
              <div className="shortcut-row">
                <span>Annuler / rétablir</span>
                <kbd>⌘ Z / ⇧ ⌘ Z</kbd>
              </div>
              <div className="shortcut-row">
                <span>Rechercher une page</span>
                <kbd>Ctrl / ⌘ K</kbd>
              </div>
              <div className="shortcut-row">
                <span>Dupliquer un élément</span>
                <kbd>Ctrl / ⌘ D</kbd>
              </div>
            </div>
            <div>
              <h3>Ce qui fonctionne</h3>
              <p>
                Sélection, édition de texte, styles responsive, calques,
                déplacement, redimensionnement, modèles, médias locaux, données
                et graphes simples, brouillons serveur, comparaison, publication
                fictive et historique.
              </p>
              <h3>Les limites, en toute transparence</h3>
              <p>
                Placement libre, alignement collectif, composants propagés,
                import Excel, connecteurs réels, thèmes membres et édition de
                l’administration ne sont pas finalisés. La session est celle
                d’un administrateur de démonstration, pas une authentification
                de production.
              </p>
              <div className="help-warning">
                <AlertTriangle size={17} />
                <span>
                  Aucun compte, contenu, service ou accès de production n’est
                  connecté.
                </span>
              </div>
            </div>
          </div>
          <div className="modal-footer help-downloads">
            <a
              className="outline-button"
              href="/documentation-atelier.md"
              download
            >
              <BookOpen size={14} /> Documentation & lot de 20
            </a>
            <a className="primary-button" href="/atelier-source.zip" download>
              <Download size={14} /> Télécharger le prototype
            </a>
          </div>
        </Modal>
      )}
    </div>
  );
}
