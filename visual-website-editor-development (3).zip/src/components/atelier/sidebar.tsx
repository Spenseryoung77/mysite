"use client";
import { useState } from "react";
import {
  Search,
  Plus,
  ChevronDown,
  ChevronRight,
  FileText,
  Home,
  MoreHorizontal,
  Layers,
  Type,
  Image,
  Square,
  MousePointer2,
  LayoutTemplate,
  PanelTop,
  PanelBottom,
  Eye,
  EyeOff,
  LockKeyhole,
  UnlockKeyhole,
  ArrowUpRight,
  Sparkles,
  BookOpen,
  Grid2X2,
  GripVertical,
  Copy,
  LayoutGrid,
  FolderOpen,
} from "lucide-react";
import type {
  PageDocument,
  PageElement,
  PageSummary,
} from "@/lib/atelier/model";
import { IconButton } from "./ui";
const kindIcon = (kind: string, size = 13) => {
  if (kind === "heading" || kind === "text") return <Type size={size} />;
  if (kind === "image") return <Image size={size} />;
  if (kind === "button") return <MousePointer2 size={size} />;
  if (kind === "header") return <PanelTop size={size} />;
  if (kind === "footer") return <PanelBottom size={size} />;
  if (kind === "card") return <LayoutGrid size={size} />;
  return <Square size={size} />;
};
export function Sidebar({
  pages,
  activeId,
  document: doc,
  selected,
  onPage,
  onSelect,
  onNew,
  onAdd,
  onPatch,
  onCatalog,
  onTemplate,
  tab,
  setTab,
}: {
  pages: PageSummary[];
  activeId: string;
  document: PageDocument;
  selected: string[];
  onPage: (id: string) => void;
  onSelect: (id: string, multi: boolean) => void;
  onNew: () => void;
  onAdd: (kind: PageElement["kind"]) => void;
  onPatch: (id: string, patch: Partial<PageElement>) => void;
  onCatalog: () => void;
  onTemplate: (name: string) => void;
  tab: string;
  setTab: (s: string) => void;
}) {
  const [search, setSearch] = useState(""),
    [collapsed, setCollapsed] = useState<string[]>([
      "site-header",
      "daily-verse",
      "latest-section",
      "site-footer",
    ]),
    [layersOpen, setLayersOpen] = useState(true);
  const filtered = pages.filter(
    (p) =>
      p.category === "Pages publiques" &&
      p.title.toLowerCase().includes(search.toLowerCase()),
  );
  function layer(el: PageElement, depth = 0) {
    const open = !collapsed.includes(el.id);
    return (
      <div key={el.id}>
        <div
          className={`layer-row ${selected.includes(el.id) ? "selected" : ""} ${el.hidden ? "layer-hidden" : ""}`}
          style={{ paddingLeft: 12 + depth * 13 }}
        >
          <button
            className="layer-toggle"
            aria-label={`${open ? "Replier" : "Déplier"} ${el.name}`}
            onClick={() =>
              setCollapsed((v) =>
                v.includes(el.id)
                  ? v.filter((i) => i !== el.id)
                  : [...v, el.id],
              )
            }
          >
            {el.children.length ? (
              open ? (
                <ChevronDown size={11} />
              ) : (
                <ChevronRight size={11} />
              )
            ) : (
              <span style={{ width: 11 }} />
            )}
          </button>
          <button
            className="layer-name"
            onClick={(e) => onSelect(el.id, e.shiftKey)}
          >
            {kindIcon(el.kind)}
            <span>{el.name}</span>
          </button>
          {el.shared ? (
            <span
              title="Composant partagé : détachez une copie pour le modifier"
              className="shared-layer"
            >
              <Copy size={11} />
            </span>
          ) : (
            <div className="layer-actions">
              <button
                aria-label={`${el.hidden ? "Afficher" : "Masquer"} ${el.name}`}
                onClick={() => onPatch(el.id, { hidden: !el.hidden })}
              >
                {el.hidden ? <EyeOff size={11} /> : <Eye size={11} />}
              </button>
              <button
                aria-label={`${el.locked ? "Déverrouiller" : "Verrouiller"} ${el.name}`}
                onClick={() => onPatch(el.id, { locked: !el.locked })}
              >
                {el.locked ? (
                  <LockKeyhole size={11} />
                ) : (
                  <UnlockKeyhole size={11} />
                )}
              </button>
            </div>
          )}
        </div>
        {open && el.children.map((c) => layer(c, depth + 1))}
      </div>
    );
  }
  return (
    <aside className="left-sidebar">
      <div
        className="sidebar-tabs"
        role="tablist"
        aria-label="Panneau de création"
      >
        {["Pages", "Éléments", "Bibliothèque"].map((t) => (
          <button
            key={t}
            role="tab"
            aria-selected={tab === t}
            className={tab === t ? "active" : ""}
            onClick={() => setTab(t)}
          >
            {t}
          </button>
        ))}
      </div>
      <div className="sidebar-search">
        <Search size={14} />
        <input
          aria-label="Rechercher dans le panneau"
          placeholder={
            tab === "Pages" ? "Rechercher une page…" : "Rechercher un élément…"
          }
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <kbd>⌘ K</kbd>
      </div>
      {tab === "Pages" ? (
        <>
          <div className="sidebar-section-heading">
            <span>
              PAGES DU SITE <span className="count-badge">{pages.length}</span>
            </span>
            <IconButton label="Créer une page" onClick={onNew}>
              <Plus size={15} />
            </IconButton>
          </div>
          <div className="page-list">
            {filtered.slice(0, 6).map((p) => (
              <button
                key={p.id}
                className={`page-list-item ${activeId === p.id ? "active" : ""}`}
                onClick={() => onPage(p.id)}
              >
                {p.id === "accueil" ? (
                  <Home size={15} />
                ) : (
                  <FileText size={15} />
                )}
                <span>{p.title}</span>
                {activeId === p.id ? (
                  <span className="page-item-current">
                    <span />
                    <MoreHorizontal size={16} />
                  </span>
                ) : (
                  <span
                    className={`page-status-dot ${p.publishedRevision ? "published" : ""}`}
                    title={p.status}
                  />
                )}
              </button>
            ))}
            {filtered.length === 0 && (
              <p className="empty-small">Aucune page trouvée.</p>
            )}
            <button className="all-pages-button" onClick={onCatalog}>
              <FolderOpen size={13} /> Toutes les pages{" "}
              <span>{pages.length}</span>
              <ArrowUpRight size={12} />
            </button>
            <button className="add-page-button" onClick={onNew}>
              <Plus size={14} /> Ajouter une page
            </button>
          </div>
          <div className="layers-heading">
            <button onClick={() => setLayersOpen(!layersOpen)}>
              <Layers size={14} />
              <span>Calques</span>
              {layersOpen ? (
                <ChevronDown size={13} />
              ) : (
                <ChevronRight size={13} />
              )}
            </button>
            <span className="tiny-key">⌘ ⇧ L</span>
          </div>
          {layersOpen && (
            <div className="layers-tree">
              {doc.elements.map((el) => layer(el))}
            </div>
          )}
        </>
      ) : tab === "Éléments" ? (
        <div className="element-palette">
          <div className="palette-caption">LES ESSENTIELS</div>
          <div className="element-tiles">
            {(
              [
                { kind: "heading", label: "Titre", icon: <Type size={23} /> },
                { kind: "text", label: "Texte", icon: <FileText size={23} /> },
                { kind: "image", label: "Image", icon: <Image size={23} /> },
                {
                  kind: "button",
                  label: "Bouton",
                  icon: <MousePointer2 size={23} />,
                },
                {
                  kind: "section",
                  label: "Section",
                  icon: <Square size={23} />,
                },
                {
                  kind: "container",
                  label: "Conteneur",
                  icon: <Grid2X2 size={23} />,
                },
              ] as const
            )
              .filter((e) =>
                e.label.toLowerCase().includes(search.toLowerCase()),
              )
              .map((e) => (
                <button key={e.kind} onClick={() => onAdd(e.kind)}>
                  {e.icon}
                  <span>{e.label}</span>
                  <Plus size={12} />
                </button>
              ))}
          </div>
          <div className="sidebar-tip">
            <MousePointer2 size={17} />
            <p>Cliquez pour ajouter, puis déplacez l’élément sur la planche.</p>
          </div>
          <div className="palette-caption">RACCOURCIS UTILES</div>
          <div className="shortcut-row">
            <span>Dupliquer</span>
            <kbd>⌘ D</kbd>
          </div>
          <div className="shortcut-row">
            <span>Sélection multiple</span>
            <kbd>⇧ clic</kbd>
          </div>
          <div className="shortcut-row">
            <span>Annuler</span>
            <kbd>⌘ Z</kbd>
          </div>
        </div>
      ) : (
        <div className="template-list">
          <div className="palette-caption">UNE LONGUEUR D’INSPIRATION</div>
          {[
            "Bannière inspirante",
            "Grille de publications",
            "Parole du jour",
            "Page éditoriale",
          ]
            .filter((t) => t.toLowerCase().includes(search.toLowerCase()))
            .map((name, i) => (
              <button
                className="template-card"
                key={name}
                onClick={() => onTemplate(name)}
              >
                <div className={`template-preview template-${i}`}>
                  {i === 0 ? (
                    <>
                      <small>UNE NOUVELLE PERSPECTIVE</small>
                      <strong>
                        Faites grandir
                        <br />
                        l’inspiration.
                      </strong>
                      <span />
                    </>
                  ) : i === 1 ? (
                    <>
                      <div />
                      <div />
                      <div />
                    </>
                  ) : i === 2 ? (
                    <>
                      <BookOpen size={22} />
                      <i>Les mots qui nous guident.</i>
                    </>
                  ) : (
                    <>
                      <div />
                      <div />
                      <div />
                      <div />
                    </>
                  )}
                </div>
                <span>
                  {name}
                  <Plus size={15} />
                </span>
              </button>
            ))}
          <div className="sidebar-tip">
            <Sparkles size={17} />
            <p>Chaque modèle est inséré comme une copie indépendante.</p>
          </div>
        </div>
      )}
      <div className="sidebar-bottom">
        <span className="demo-dot" /> Espace de démonstration{" "}
        <span title="Aucune connexion au site réel">
          <LockKeyhole size={12} />
        </span>
      </div>
    </aside>
  );
}
