"use client";
import { useEffect, useState } from "react";
import {
  SlidersHorizontal,
  MoreHorizontal,
  ChevronDown,
  Type,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Bold,
  Italic,
  Link2,
  RotateCcw,
  Monitor,
  Tablet,
  Smartphone,
  ArrowRight,
  ArrowDown,
  Copy,
  LockKeyhole,
  MousePointer2,
  Unlink,
  Eye,
  Plus,
  Trash2,
  Palette,
  Layers,
  Move,
  Image,
  Check,
} from "lucide-react";
import {
  flatten,
  resolveStyle,
  type PageElement,
  type PageDocument,
  type ElementStyle,
  type Device,
} from "@/lib/atelier/model";
import { IconButton, SectionTitle, NumericField } from "./ui";
export function Inspector({
  document: doc,
  element: el,
  device,
  onPatch,
  onStyle,
  onDocument,
  onDuplicate,
  onDelete,
  onDetach,
  advanced,
  onHistory,
}: {
  document: PageDocument;
  element: PageElement | undefined;
  device: Device;
  onPatch: (patch: Partial<PageElement>) => void;
  onStyle: (patch: ElementStyle, reset?: boolean) => void;
  onDocument: (doc: PageDocument) => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onDetach: () => void;
  advanced: boolean;
  onHistory: () => void;
}) {
  const [tab, setTab] = useState("Style"),
    [dimensions, setDimensions] = useState({ width: 850, height: 148 });
  useEffect(() => {
    if (!el) return;
    const target = Array.from(
      window.document.querySelectorAll<HTMLElement>(
        ".artboard-inner [data-element-id]",
      ),
    ).find((n) => n.dataset.elementId === el.id);
    if (!target) return;
    const measure = () =>
      setDimensions({ width: target.offsetWidth, height: target.offsetHeight });
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(target);
    return () => observer.disconnect();
  }, [el?.id, device]);
  if (!el)
    return (
      <aside className="inspector">
        <div className="inspector-title">
          <SlidersHorizontal size={15} />
          <strong>Propriétés de la page</strong>
        </div>
        <div className="inspector-empty">
          <MousePointer2 size={30} />
          <h3>À vous de créer.</h3>
          <p>Sélectionnez un élément sur la planche pour le personnaliser.</p>
        </div>
        <div className="property-section">
          <SectionTitle>Identité de la page</SectionTitle>
          <label className="field-label">
            Nom de la page
            <input
              value={doc.title}
              onChange={(e) => onDocument({ ...doc, title: e.target.value })}
            />
          </label>
          <label className="field-label">
            Adresse
            <input
              value={doc.slug}
              onChange={(e) => onDocument({ ...doc, slug: e.target.value })}
            />
          </label>
        </div>
        <button
          className="outline-button inspector-history"
          onClick={onHistory}
        >
          Consulter les versions
        </button>
      </aside>
    );
  const s = resolveStyle(el, device),
    own = el.styles[device] || {};
  const ancestors = (
    nodes: PageElement[],
    id: string,
    path: PageElement[] = [],
  ): PageElement[] => {
    for (const e of nodes) {
      if (e.id === id) return path;
      const found = ancestors(e.children, id, [...path, e]);
      if (found.length) return found;
    }
    return [];
  };
  const shared =
    !!el.shared || ancestors(doc.elements, el.id).some((e) => e.shared);
  const locked = el.locked || shared;
  return (
    <aside className="inspector">
      <div className="inspector-title">
        <SlidersHorizontal size={15} />
        <strong>Propriétés</strong>
        <IconButton label="Historique des versions" onClick={onHistory}>
          <MoreHorizontal size={18} />
        </IconButton>
      </div>
      <div className="selected-element-heading">
        <div className="selected-type-icon">
          {el.kind === "image" ? (
            <Image size={20} />
          ) : el.kind === "heading" || el.kind === "text" ? (
            <Type size={20} />
          ) : (
            <Layers size={20} />
          )}
        </div>
        <div>
          <input
            aria-label="Nom du calque"
            value={el.name}
            readOnly={!!locked}
            onChange={(e) => onPatch({ name: e.target.value })}
          />
          <span>
            {el.kind === "heading"
              ? "Titre"
              : el.kind === "section"
                ? "Section"
                : el.kind === "text"
                  ? "Texte"
                  : el.kind === "image"
                    ? "Image"
                    : "Élément"}{" "}
            <span className="element-scope">
              · {shared ? "Partagé" : "Cette page uniquement"}
            </span>
          </span>
        </div>
      </div>
      <div className="inspector-tabs">
        {["Style", "Contenu", "Actions"].map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={tab === t ? "active" : ""}
          >
            {t}
          </button>
        ))}
      </div>
      {shared ? (
        <div className="shared-warning">
          <Copy size={22} />
          <strong>Un élément partagé</strong>
          <p>
            Ce composant appartient au modèle commun. La propagation à d’autres
            pages n’est pas activée dans ce lot.
          </p>
          <button className="outline-button" onClick={onDetach}>
            <Unlink size={13} /> Détacher une copie locale
          </button>
        </div>
      ) : (
        <div className="inspector-scroll">
          {el.locked && (
            <div className="locked-warning">
              <LockKeyhole size={13} /> Calque verrouillé.
              <button onClick={() => onPatch({ locked: false })}>
                Déverrouiller
              </button>
            </div>
          )}
          <fieldset disabled={!!locked} className="inspector-fieldset">
            {tab === "Style" ? (
              <>
                <div className="device-property-bar">
                  {device === "desktop" ? (
                    <Monitor size={12} />
                  ) : device === "tablet" ? (
                    <Tablet size={12} />
                  ) : (
                    <Smartphone size={12} />
                  )}
                  <span>
                    {device === "desktop"
                      ? "Style ordinateur"
                      : device === "tablet"
                        ? "Style tablette"
                        : "Style mobile"}
                  </span>
                  <button
                    title="Supprimer les réglages de cet appareil et revenir à l’héritage"
                    aria-label="Réinitialiser les styles de cet appareil"
                    onClick={() => onStyle({}, true)}
                  >
                    <RotateCcw size={12} />
                  </button>
                </div>
                {device !== "desktop" && (
                  <p className="inheritance-info">
                    {Object.keys(own).length
                      ? "Valeurs spécifiques à cet appareil."
                      : "Hérite du format " +
                        (device === "mobile"
                          ? "tablette / ordinateur."
                          : "ordinateur.")}
                  </p>
                )}
                <div className="property-section">
                  <SectionTitle>Disposition</SectionTitle>
                  {el.children.length > 0 && (
                    <div className="layout-mode">
                      <button
                        className={
                          !s.direction || s.direction === "column"
                            ? "active"
                            : ""
                        }
                        onClick={() => onStyle({ direction: "column" })}
                      >
                        <ArrowDown size={14} /> Verticale
                      </button>
                      <button
                        className={s.direction === "row" ? "active" : ""}
                        onClick={() => onStyle({ direction: "row" })}
                      >
                        <ArrowRight size={14} /> Horizontale
                      </button>
                    </div>
                  )}
                  <div className="property-row">
                    <NumericField
                      label="L"
                      value={s.width || dimensions.width}
                      onChange={(width) => onStyle({ width })}
                    />
                    <span className="dimension-link">
                      <Unlink size={13} />
                    </span>
                    <NumericField
                      label="H"
                      value={s.height || dimensions.height}
                      onChange={(height) => onStyle({ height })}
                    />
                  </div>
                  <div className="property-row">
                    <NumericField
                      label="X"
                      value={s.x || 0}
                      min={-1000}
                      onChange={(x) => onStyle({ x })}
                    />
                    <span className="dimension-link" />
                    <NumericField
                      label="Y"
                      value={s.y || 0}
                      min={-1000}
                      onChange={(y) => onStyle({ y })}
                    />
                  </div>
                  {advanced && (
                    <div className="property-row">
                      <NumericField
                        label="Écart"
                        value={s.gap || 0}
                        max={160}
                        onChange={(gap) => onStyle({ gap })}
                      />
                    </div>
                  )}
                </div>
                {["heading", "text", "button"].includes(el.kind) && (
                  <div className="property-section">
                    <SectionTitle>Typographie</SectionTitle>
                    <label className="font-select">
                      <Type size={13} />
                      <select
                        aria-label="Police de la page"
                        value={doc.theme.font}
                        onChange={(e) =>
                          onDocument({
                            ...doc,
                            theme: { ...doc.theme, font: e.target.value },
                          })
                        }
                      >
                        <option value="Georgia">Georgia</option>
                        <option value="Inter">Inter / sans-serif</option>
                        <option value="Arial">Arial</option>
                      </select>
                      <ChevronDown size={12} />
                    </label>
                    <p className="small-field-hint">
                      Police appliquée à cette page
                    </p>
                    <div className="property-row">
                      <select
                        aria-label="Graisse du texte"
                        className="weight-select"
                        value={s.fontWeight || 400}
                        onChange={(e) =>
                          onStyle({ fontWeight: Number(e.target.value) })
                        }
                      >
                        <option value={400}>Regular</option>
                        <option value={500}>Medium</option>
                        <option value={600}>Semi-bold</option>
                        <option value={700}>Bold</option>
                      </select>
                      <NumericField
                        label="T"
                        value={s.fontSize || 16}
                        min={8}
                        max={180}
                        onChange={(fontSize) => onStyle({ fontSize })}
                      />
                    </div>
                    <div className="text-format-row">
                      <div className="button-group">
                        <IconButton
                          label="Texte gras"
                          active={s.fontWeight === 700}
                          onClick={() =>
                            onStyle({
                              fontWeight: s.fontWeight === 700 ? 400 : 700,
                            })
                          }
                        >
                          <Bold size={14} />
                        </IconButton>
                      </div>
                      <div className="button-group">
                        {(["left", "center", "right"] as const).map(
                          (align, i) => (
                            <IconButton
                              key={align}
                              label={
                                [
                                  "Aligner à gauche",
                                  "Centrer",
                                  "Aligner à droite",
                                ][i]
                              }
                              active={(s.textAlign || "left") === align}
                              onClick={() => onStyle({ textAlign: align })}
                            >
                              {i === 0 ? (
                                <AlignLeft size={15} />
                              ) : i === 1 ? (
                                <AlignCenter size={15} />
                              ) : (
                                <AlignRight size={15} />
                              )}
                            </IconButton>
                          ),
                        )}
                      </div>
                    </div>
                    <div className="color-field">
                      <input
                        type="color"
                        aria-label="Couleur du texte"
                        value={s.color || "#262326"}
                        onChange={(e) => onStyle({ color: e.target.value })}
                      />
                      <span>{(s.color || "#262326").toUpperCase()}</span>
                      <small>100 %</small>
                      <ChevronDown size={12} />
                    </div>
                  </div>
                )}
                <div className="property-section">
                  <SectionTitle>Apparence</SectionTitle>
                  <label className="property-caption">Arrière-plan</label>
                  <div className="color-field">
                    <input
                      type="color"
                      aria-label="Couleur de fond"
                      value={
                        s.backgroundColor && s.backgroundColor !== "transparent"
                          ? s.backgroundColor
                          : "#ffffff"
                      }
                      onChange={(e) =>
                        onStyle({ backgroundColor: e.target.value })
                      }
                    />
                    <span>
                      {s.backgroundColor && s.backgroundColor !== "transparent"
                        ? s.backgroundColor.toUpperCase()
                        : "Aucun remplissage"}
                    </span>
                    <button
                      aria-label="Retirer le fond"
                      onClick={() =>
                        onStyle({ backgroundColor: "transparent" })
                      }
                    >
                      <Plus size={13} style={{ transform: "rotate(45deg)" }} />
                    </button>
                  </div>
                  <div className="property-row">
                    <NumericField
                      label="Arrondi"
                      value={s.borderRadius || 0}
                      max={200}
                      onChange={(borderRadius) => onStyle({ borderRadius })}
                    />
                    <NumericField
                      label="Opacité"
                      value={(s.opacity ?? 1) * 100}
                      max={100}
                      unit="%"
                      onChange={(opacity) =>
                        onStyle({ opacity: opacity / 100 })
                      }
                    />
                  </div>
                </div>
                <div className="property-section">
                  <SectionTitle>Espacement</SectionTitle>
                  <div className="spacing-diagram">
                    <span className="spacing-label">MARGE INTÉRIEURE</span>
                    <input
                      type="number"
                      aria-label="Marge intérieure"
                      value={s.padding || 0}
                      min={0}
                      max={300}
                      onChange={(e) =>
                        onStyle({
                          padding: Math.min(
                            300,
                            Math.max(0, Number(e.target.value)),
                          ),
                        })
                      }
                    />
                    <div className="spacing-center">
                      <span />
                      {s.padding || 0}
                      <span />
                    </div>
                    <small>px</small>
                  </div>
                </div>
                {advanced && (
                  <div className="property-section">
                    <SectionTitle>Visibilité</SectionTitle>
                    <label className="checkbox-label">
                      <input
                        type="checkbox"
                        checked={!s.hidden}
                        onChange={(e) => onStyle({ hidden: !e.target.checked })}
                      />{" "}
                      Visible sur cet appareil
                    </label>
                    <code className="element-id">{el.id}</code>
                  </div>
                )}
              </>
            ) : tab === "Contenu" ? (
              <div className="property-section">
                <SectionTitle>Contenu de l’élément</SectionTitle>
                {["heading", "text", "button", "footer"].includes(el.kind) && (
                  <label className="field-label">
                    Texte
                    <textarea
                      aria-label="Texte"
                      rows={5}
                      value={el.text || ""}
                      onChange={(e) => onPatch({ text: e.target.value })}
                    />
                  </label>
                )}
                {["image", "section"].includes(el.kind) && (
                  <>
                    <label className="field-label">
                      Adresse de l’image
                      <input
                        value={el.src || ""}
                        onChange={(e) => onPatch({ src: e.target.value })}
                      />
                    </label>
                    <label className="field-label">
                      Texte alternatif
                      <textarea
                        value={el.alt || ""}
                        onChange={(e) => onPatch({ alt: e.target.value })}
                      />
                    </label>
                    <div className="image-choices">
                      {["mountains", "bible", "peace"].map((n) => (
                        <button
                          key={n}
                          onClick={() => onPatch({ src: `/images/${n}.jpg` })}
                        >
                          <img src={`/images/${n}.jpg`} alt={n} />
                          {el.src === `/images/${n}.jpg` && <Check size={13} />}
                        </button>
                      ))}
                    </div>
                  </>
                )}
                {el.kind === "button" && (
                  <label className="field-label">
                    Destination du lien
                    <input
                      value={el.href || ""}
                      placeholder="https:// ou /page"
                      onChange={(e) => onPatch({ href: e.target.value })}
                    />
                  </label>
                )}
                {["heading", "text", "button"].includes(el.kind) && (
                  <>
                    <SectionTitle>Liaison aux données</SectionTitle>
                    <p className="small-field-hint">
                      Source : articles fictifs du tableur
                    </p>
                    <select
                      className="full-select"
                      aria-label="Lier à un article"
                      value={el.binding?.rowId || ""}
                      onChange={(e) =>
                        onPatch({
                          binding: e.target.value
                            ? {
                                source: "articles",
                                rowId: e.target.value,
                                field: "title",
                                fallback: el.text || "Contenu indisponible",
                              }
                            : undefined,
                        })
                      }
                    >
                      <option value="">Texte libre — aucune liaison</option>
                      {doc.sheet.map((r) => (
                        <option key={r.id} value={r.id}>
                          {r.title} ({r.status})
                        </option>
                      ))}
                    </select>
                    {el.binding && (
                      <>
                        <label className="field-label">
                          Champ
                          <select
                            value={el.binding.field}
                            onChange={(e) =>
                              onPatch({
                                binding: {
                                  ...el.binding!,
                                  field: e.target.value,
                                },
                              })
                            }
                          >
                            {["title", "category", "author", "date"].map(
                              (f, i) => (
                                <option key={f} value={f}>
                                  {["Titre", "Rubrique", "Auteur", "Date"][i]}
                                </option>
                              ),
                            )}
                          </select>
                        </label>
                        <label className="field-label">
                          Valeur de remplacement
                          <input
                            value={el.binding.fallback}
                            onChange={(e) =>
                              onPatch({
                                binding: {
                                  ...el.binding!,
                                  fallback: e.target.value,
                                },
                              })
                            }
                          />
                        </label>
                      </>
                    )}
                  </>
                )}
              </div>
            ) : (
              <div className="property-section">
                <SectionTitle>Interaction sans code</SectionTitle>
                <p className="field-description">
                  Les actions sont inactives pendant l’édition. Testez-les dans
                  l’aperçu.
                </p>
                <label className="field-label">
                  Déclencheur
                  <select
                    value={el.interaction?.trigger || "click"}
                    onChange={(e) =>
                      onPatch({
                        interaction: {
                          trigger: e.target.value as "click" | "hover",
                          action: el.interaction?.action || "link",
                          target: el.interaction?.target || "",
                        },
                      })
                    }
                  >
                    <option value="click">Au clic</option>
                    <option value="hover">Au survol</option>
                  </select>
                </label>
                <label className="field-label">
                  Action
                  <select
                    value={el.interaction?.action || ""}
                    onChange={(e) =>
                      onPatch({
                        interaction: e.target.value
                          ? {
                              trigger: el.interaction?.trigger || "click",
                              action: e.target.value as "link" | "toggle",
                              target: "",
                            }
                          : undefined,
                      })
                    }
                  >
                    <option value="">Aucune interaction</option>
                    <option value="link">Ouvrir un lien</option>
                    <option value="toggle">
                      Afficher / masquer un élément
                    </option>
                  </select>
                </label>
                {el.interaction?.action === "link" && (
                  <label className="field-label">
                    Destination
                    <input
                      value={el.interaction.target}
                      onChange={(e) =>
                        onPatch({
                          interaction: {
                            ...el.interaction!,
                            target: e.target.value,
                          },
                        })
                      }
                      placeholder="https:// ou /page"
                    />
                  </label>
                )}
                {el.interaction?.action === "toggle" && (
                  <label className="field-label">
                    Élément cible
                    <select
                      value={el.interaction.target}
                      onChange={(e) =>
                        onPatch({
                          interaction: {
                            ...el.interaction!,
                            target: e.target.value,
                          },
                        })
                      }
                    >
                      <option value="">Choisir un élément</option>
                      {flatten(doc.elements)
                        .filter((e) => e.id !== el.id)
                        .map((e) => (
                          <option key={e.id} value={e.id}>
                            {e.name}
                          </option>
                        ))}
                    </select>
                  </label>
                )}
                <div className="sidebar-tip">
                  <MousePointer2 size={16} />
                  <p>
                    Aucun code libre n’est exécuté. Les actions disponibles sont
                    limitées et validées.
                  </p>
                </div>
              </div>
            )}
          </fieldset>
          <div className="inspector-element-actions">
            <button onClick={onDuplicate}>
              <Copy size={13} /> Dupliquer
            </button>
            <button className="danger-text" onClick={onDelete}>
              <Trash2 size={13} /> Supprimer
            </button>
          </div>
        </div>
      )}
      <div className="inspector-footer">
        <span className="green-dot" /> Vos modifications restent privées
      </div>
    </aside>
  );
}
