"use client";
import { useLayoutEffect, useRef, useState, type KeyboardEvent } from "react";
import {
  Plus,
  Search,
  Download,
  Upload,
  Trash2,
  ChevronDown,
  ArrowUpDown,
  Table2,
  Database,
  Type,
  Filter,
  Monitor,
  Play,
  CheckCircle2,
  Link2,
  X,
  MousePointer2,
  Network,
  Copy,
  FileSpreadsheet,
  RotateCcw,
  Columns3,
  Save,
  MoreHorizontal,
} from "lucide-react";
import {
  graphSchema,
  updateElement,
  type PageDocument,
  type SheetRow,
  type GraphNode,
} from "@/lib/atelier/model";
import { downloadFile } from "@/lib/atelier/api";
import { IconButton, NumericField } from "./ui";

type Props = {
  document: PageDocument;
  onChange: (doc: PageDocument) => void;
  onSave: () => void;
  notify: (msg: string, error?: boolean) => void;
};
const columns = [
  { key: "title", label: "Titre de la publication", letter: "A" },
  { key: "category", label: "Rubrique", letter: "B" },
  { key: "author", label: "Auteur", letter: "C" },
  { key: "status", label: "Statut", letter: "D" },
  { key: "date", label: "Date", letter: "E" },
] as const;
export function Spreadsheet({
  document: doc,
  onChange,
  onSave,
  notify,
}: Props) {
  const [query, setQuery] = useState(""),
    [status, setStatus] = useState("Tous les statuts"),
    [selected, setSelected] = useState<string[]>([]),
    [active, setActive] = useState({ row: 0, column: 0 }),
    [sort, setSort] = useState(false);
  const rows = doc.sheet
    .filter(
      (r) =>
        (status === "Tous les statuts" || r.status === status) &&
        Object.values(r).join(" ").toLowerCase().includes(query.toLowerCase()),
    )
    .sort((a, b) => (sort ? a.title.localeCompare(b.title, "fr") : 0));
  const activeRow = rows[active.row];
  const activeKey = columns[active.column].key;
  const patch = (id: string, key: keyof SheetRow, value: string) =>
    onChange({
      ...doc,
      sheet: doc.sheet.map((r) => (r.id === id ? { ...r, [key]: value } : r)),
    });
  const add = () => {
    if (doc.sheet.length >= 500) {
      notify("Limite du prototype : 500 lignes.", true);
      return;
    }
    const row: SheetRow = {
      id: crypto.randomUUID(),
      title: "Nouvelle publication",
      category: "Méditations",
      author: "Auteur de démonstration",
      status: "Brouillon",
      date: new Date().toISOString().slice(0, 10),
    };
    onChange({ ...doc, sheet: [...doc.sheet, row] });
    notify("Une ligne a été ajoutée au brouillon.");
  };
  const remove = () => {
    if (!selected.length) return;
    if (
      window.confirm(
        `Supprimer ${selected.length} ligne(s) de démonstration ? Les liaisons utiliseront leur valeur de remplacement.`,
      )
    ) {
      onChange({
        ...doc,
        sheet: doc.sheet.filter((r) => !selected.includes(r.id)),
      });
      setSelected([]);
    }
  };
  const keyNav = (e: KeyboardEvent<HTMLInputElement>, r: number, c: number) => {
    if (
      e.key === "Enter" ||
      (e.altKey &&
        ["ArrowDown", "ArrowUp", "ArrowLeft", "ArrowRight"].includes(e.key))
    ) {
      e.preventDefault();
      const nr = Math.max(
          0,
          Math.min(
            rows.length - 1,
            r +
              (e.key === "ArrowUp"
                ? -1
                : e.key === "Enter" || e.key === "ArrowDown"
                  ? 1
                  : 0),
          ),
        ),
        nc = Math.max(
          0,
          Math.min(
            4,
            c + (e.key === "ArrowRight" ? 1 : e.key === "ArrowLeft" ? -1 : 0),
          ),
        );
      setActive({ row: nr, column: nc });
      document
        .querySelector<HTMLInputElement>(`[data-cell="${nr}-${nc}"]`)
        ?.focus();
    }
  };
  const exportCsv = () => {
    const esc = (v: string) =>
      `"${(/^[=+@-]/.test(v) ? "'" : "") + v.replaceAll('"', '""')}"`;
    downloadFile(
      "publications-demonstration.csv",
      "\ufeff" +
        [
          columns.map((c) => esc(c.label)).join(";"),
          ...doc.sheet.map((r) => columns.map((c) => esc(r[c.key])).join(";")),
        ].join("\r\n"),
      "text/csv;charset=utf-8",
    );
    notify("Le tableur a été exporté en CSV.");
  };
  return (
    <div className="data-studio spreadsheet-studio">
      <div className="studio-heading">
        <div className="studio-heading-icon green">
          <Table2 size={23} />
        </div>
        <div>
          <h1>Votre contenu, bien organisé.</h1>
          <p>Les données de démonstration de « {doc.title} »</p>
        </div>
        <span className="demo-chip">Données fictives</span>
      </div>
      <div className="sheet-toolbar">
        <div className="sheet-tab">
          <FileSpreadsheet size={15} /> Publications{" "}
          <span>{doc.sheet.length}</span>
        </div>
        <div className="studio-tools">
          <button className="outline-button" onClick={exportCsv}>
            <Download size={14} /> Exporter CSV
          </button>
          <button className="primary-button" onClick={onSave}>
            <Save size={14} /> Enregistrer
          </button>
        </div>
      </div>
      <div className="sheet-filterbar">
        <div className="search-box">
          <Search size={15} />
          <input
            aria-label="Rechercher une donnée"
            placeholder="Rechercher dans le tableur…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <select
          aria-label="Filtrer les données par statut"
          value={status}
          onChange={(e) => setStatus(e.target.value)}
        >
          {["Tous les statuts", "Publié", "Brouillon", "Masqué"].map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
        <button className="text-button" onClick={() => setSort(!sort)}>
          <ArrowUpDown size={14} /> {sort ? "A → Z" : "Trier par titre"}
        </button>
        <div className="toolbar-spacer" />
        {selected.length > 0 && (
          <button className="text-button danger-text" onClick={remove}>
            <Trash2 size={14} /> Supprimer ({selected.length})
          </button>
        )}
        <button className="outline-button" onClick={add}>
          <Plus size={14} /> Ajouter une ligne
        </button>
      </div>
      <div className="formula-bar">
        <span>
          {columns[active.column].letter}
          {active.row + 1}
        </span>
        <i>valeur</i>
        <input
          aria-label="Valeur de la cellule sélectionnée"
          value={activeRow?.[activeKey] || ""}
          onChange={(e) => {
            if (activeRow && activeKey !== "status")
              patch(activeRow.id, activeKey, e.target.value);
          }}
          readOnly={!activeRow || activeKey === "status"}
        />
        <small>Texte simple · sans formules</small>
      </div>
      <div className="spreadsheet-scroll">
        <table className="spreadsheet">
          <thead>
            <tr>
              <th className="row-number">
                <input
                  aria-label="Sélectionner toutes les lignes"
                  type="checkbox"
                  checked={rows.length > 0 && selected.length === rows.length}
                  onChange={(e) =>
                    setSelected(e.target.checked ? rows.map((r) => r.id) : [])
                  }
                />
              </th>
              {columns.map((c) => (
                <th key={c.key}>
                  <span>{c.letter}</span>
                  {c.key === "title" ? (
                    <Type size={13} />
                  ) : c.key === "status" ? (
                    <CheckCircle2 size={13} />
                  ) : (
                    <Columns3 size={13} />
                  )}{" "}
                  {c.label}
                </th>
              ))}
              <th className="sheet-delete-column" />
            </tr>
          </thead>
          <tbody>
            {rows.map((r, ri) => (
              <tr
                key={r.id}
                className={selected.includes(r.id) ? "selected-row" : ""}
              >
                <td className="row-number">
                  <span>{ri + 1}</span>
                  <input
                    type="checkbox"
                    aria-label={`Sélectionner ${r.title}`}
                    checked={selected.includes(r.id)}
                    onChange={(e) =>
                      setSelected((v) =>
                        e.target.checked
                          ? [...v, r.id]
                          : v.filter((i) => i !== r.id),
                      )
                    }
                  />
                </td>
                {columns.map((c, ci) => (
                  <td
                    key={c.key}
                    className={
                      active.row === ri && active.column === ci
                        ? "active-cell"
                        : ""
                    }
                    onFocus={() => setActive({ row: ri, column: ci })}
                  >
                    {c.key === "status" ? (
                      <select
                        aria-label={`Statut de ${r.title}`}
                        className={`sheet-status status-${r.status.toLowerCase()}`}
                        value={r.status}
                        onChange={(e) => patch(r.id, c.key, e.target.value)}
                      >
                        {["Publié", "Brouillon", "Masqué"].map((s) => (
                          <option key={s}>{s}</option>
                        ))}
                      </select>
                    ) : (
                      <input
                        data-cell={`${ri}-${ci}`}
                        aria-label={`${c.label}, ligne ${ri + 1}`}
                        type={c.key === "date" ? "date" : "text"}
                        value={r[c.key]}
                        onKeyDown={(e) => keyNav(e, ri, ci)}
                        onChange={(e) => patch(r.id, c.key, e.target.value)}
                      />
                    )}
                  </td>
                ))}
                <td>
                  <IconButton
                    label={`Dupliquer la ligne ${ri + 1}`}
                    onClick={() =>
                      onChange({
                        ...doc,
                        sheet: [
                          ...doc.sheet,
                          {
                            ...r,
                            id: crypto.randomUUID(),
                            title: `${r.title} — copie`,
                          },
                        ],
                      })
                    }
                  >
                    <Copy size={13} />
                  </IconButton>
                </td>
              </tr>
            ))}
            {Array.from({ length: Math.max(0, 12 - rows.length) }).map(
              (_, i) => (
                <tr className="blank-sheet-row" key={`empty-${i}`}>
                  <td className="row-number">{rows.length + i + 1}</td>
                  {columns.map((c) => (
                    <td key={c.key} />
                  ))}
                  <td />
                </tr>
              ),
            )}
          </tbody>
        </table>
        <button className="sheet-add-inline" onClick={add}>
          <Plus size={14} /> Ajouter une publication fictive
        </button>
      </div>
      <div className="sheet-statusbar">
        <span>
          <span className="green-dot" /> Stockage dans le brouillon serveur
        </span>
        <span>
          {rows.length} lignes affichées · 5 colonnes · {selected.length}{" "}
          sélectionnée(s)
        </span>
      </div>
      <div className="data-disclaimer">
        <Database size={15} />
        <p>
          <strong>Un bac à sable, pas votre base de données.</strong> Ces
          données sont propres à cette page. Les connecteurs Flask, les formules
          et l’import Excel ne sont pas encore réalisés.
        </p>
      </div>
    </div>
  );
}
const nodeMeta = {
  source: { label: "Source", icon: Database, color: "green" },
  field: { label: "Champ", icon: Type, color: "purple" },
  filter: { label: "Filtre", icon: Filter, color: "orange" },
  display: { label: "Affichage", icon: Monitor, color: "blue" },
};
export function Blueprint({ document: doc, onChange, onSave, notify }: Props) {
  const [selected, setSelected] = useState<string | null>("field-title"),
    [connecting, setConnecting] = useState<string | null>(null),
    [output, setOutput] = useState<string[] | null>(null),
    [zoom, setZoom] = useState(0.9),
    [dragging, setDragging] = useState<{
      id: string;
      x: number;
      y: number;
    } | null>(null);
  const input = useRef<HTMLInputElement>(null);
  const transformRef = useRef<HTMLDivElement>(null);
  const [ports, setPorts] = useState<
    Record<
      string,
      { input?: { x: number; y: number }; output?: { x: number; y: number } }
    >
  >({});
  useLayoutEffect(() => {
    const root = transformRef.current;
    if (!root) return;
    const measure = () => {
      const base = root.getBoundingClientRect();
      const next: Record<
        string,
        { input?: { x: number; y: number }; output?: { x: number; y: number } }
      > = {};
      root
        .querySelectorAll<HTMLElement>("[data-graph-node]")
        .forEach((card) => {
          const id = card.dataset.graphNode!;
          const point = (selector: string) => {
            const pin = card.querySelector<HTMLElement>(selector);
            if (!pin) return undefined;
            const rect = pin.getBoundingClientRect();
            return {
              x: (rect.left + rect.width / 2 - base.left) / zoom,
              y: (rect.top + rect.height / 2 - base.top) / zoom,
            };
          };
          next[id] = {
            input: point(".port-in > span"),
            output: point(".port-out > span"),
          };
        });
      setPorts((previous) =>
        JSON.stringify(previous) === JSON.stringify(next) ? previous : next,
      );
    };
    measure();
    const observer = new ResizeObserver(measure);
    root
      .querySelectorAll<HTMLElement>("[data-graph-node]")
      .forEach((card) => observer.observe(card));
    return () => observer.disconnect();
  }, [doc.graph.nodes, zoom, dragging]);
  const node = doc.graph.nodes.find((n) => n.id === selected);
  const displayNodes = doc.graph.nodes.map((n) =>
    dragging?.id === n.id ? { ...n, x: dragging.x, y: dragging.y } : n,
  );
  const patch = (patch: Partial<GraphNode>) => {
    if (node)
      onChange({
        ...doc,
        graph: {
          ...doc.graph,
          nodes: doc.graph.nodes.map((n) =>
            n.id === node.id ? { ...n, ...patch } : n,
          ),
        },
      });
  };
  function connect(id: string, isOutput: boolean) {
    if (isOutput) {
      setConnecting(id);
      notify("Cliquez sur l’entrée d’un nœud compatible.");
      return;
    }
    if (!connecting) return;
    const edges = [
      ...doc.graph.edges.filter((e) => e.to !== id),
      { id: crypto.randomUUID(), from: connecting, to: id },
    ];
    const result = graphSchema.safeParse({ ...doc.graph, edges });
    if (!result.success) {
      notify(result.error.issues[0].message, true);
      setConnecting(null);
      return;
    }
    onChange({ ...doc, graph: { ...doc.graph, edges } });
    setConnecting(null);
    notify("Les nœuds sont reliés.");
  }
  function execute() {
    try {
      const cache = new Map<string, unknown[]>();
      function evaluate(id: string): unknown[] {
        if (cache.has(id)) return cache.get(id)!;
        const n = doc.graph.nodes.find((n) => n.id === id);
        if (!n) return [];
        const inputEdge = doc.graph.edges.find((e) => e.to === id);
        const data = inputEdge ? evaluate(inputEdge.from) : [];
        let result: unknown[] = [];
        if (n.type === "source") result = doc.sheet;
        if (n.type === "filter")
          result = (data as SheetRow[]).filter((r) => r.status === n.value);
        if (n.type === "field")
          result = (data as SheetRow[])
            .filter((r) => !n.value || r.id === n.value)
            .map((r) => r[n.field as keyof SheetRow] || "");
        if (n.type === "display") result = data;
        cache.set(id, result);
        return result;
      }
      const result = doc.graph.nodes
        .filter((n) => n.type === "display")
        .flatMap((n) => evaluate(n.id));
      setOutput(
        result.map((v) =>
          typeof v === "object" ? JSON.stringify(v) : String(v),
        ),
      );
      notify(
        `Graphe testé : ${result.length} résultat(s). Aucune publication.`,
      );
    } catch {
      notify("Le graphe ne peut pas être évalué. Vérifiez les liaisons.", true);
    }
  }
  function applyBinding() {
    if (!node || node.type !== "display") return;
    const edge = doc.graph.edges.find((e) => e.to === node.id);
    const field = doc.graph.nodes.find(
      (n) => n.id === edge?.from && n.type === "field",
    );
    if (!field) {
      notify("Reliez un nœud Champ à cet affichage.", true);
      return;
    }
    const target = doc.elements
      .flatMap(function walk(e): typeof doc.elements {
        return [e, ...e.children.flatMap(walk)];
      })
      .find((e) => e.id === node.field);
    if (!target || !["heading", "text", "button"].includes(target.kind)) {
      notify(
        "Choisissez l’identifiant d’un titre, texte ou bouton existant.",
        true,
      );
      return;
    }
    if (!["title", "category", "author", "date"].includes(field.field)) {
      notify("Ce champ n’est pas autorisé.", true);
      return;
    }
    onChange(
      updateElement(doc, target.id, {
        binding: {
          source: "articles",
          rowId:
            field.value ||
            doc.sheet.find((r) => r.status === "Publié")?.id ||
            "",
          field: field.field,
          fallback: target.text || "Contenu indisponible",
        },
      }),
    );
    notify("La liaison a été appliquée dans le brouillon.");
  }
  const addNode = (type: GraphNode["type"]) => {
    const n: GraphNode = {
      id: crypto.randomUUID(),
      type,
      title: nodeMeta[type].label,
      x: 70 + (doc.graph.nodes.length % 3) * 300,
      y: 70 + Math.floor(doc.graph.nodes.length / 3) * 210,
      field:
        type === "source"
          ? "articles"
          : type === "field"
            ? "title"
            : type === "filter"
              ? "status"
              : "",
      value: type === "filter" ? "Publié" : "",
    };
    onChange({
      ...doc,
      graph: { ...doc.graph, nodes: [...doc.graph.nodes, n] },
    });
    setSelected(n.id);
  };
  return (
    <div className="data-studio blueprint-studio">
      <div className="studio-heading">
        <div className="studio-heading-icon purple">
          <Network size={23} />
        </div>
        <div>
          <h1>Donnez du sens à vos connexions.</h1>
          <p>Blueprint de la page « {doc.title} »</p>
        </div>
        <span className="demo-chip">Sans code</span>
        <div className="studio-tools">
          <button
            className="outline-button"
            onClick={() => input.current?.click()}
          >
            <Upload size={14} /> Importer
          </button>
          <input
            ref={input}
            type="file"
            accept="application/json,.json"
            hidden
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              try {
                if (f.size > 200000)
                  throw new Error("Fichier trop volumineux.");
                const result = graphSchema.safeParse(
                  JSON.parse(await f.text()),
                );
                if (!result.success)
                  throw new Error(result.error.issues[0].message);
                onChange({ ...doc, graph: result.data });
                notify("Graphe importé dans le brouillon, sans publication.");
              } catch (err) {
                notify(
                  err instanceof Error ? err.message : "Import invalide.",
                  true,
                );
              }
              e.target.value = "";
            }}
          />
          <button
            className="outline-button"
            onClick={() =>
              downloadFile(
                "blueprint-paroles-inspirees.json",
                JSON.stringify(doc.graph, null, 2),
              )
            }
          >
            <Download size={14} /> Exporter
          </button>
          <button className="primary-button" onClick={execute}>
            <Play size={14} /> Tester le graphe
          </button>
        </div>
      </div>
      <div className="blueprint-workspace">
        <div className="blueprint-main">
          <div className="graph-toolbar">
            <span>AJOUTER UN NŒUD</span>
            {(Object.keys(nodeMeta) as GraphNode["type"][]).map((t) => {
              const Icon = nodeMeta[t].icon;
              return (
                <button key={t} onClick={() => addNode(t)}>
                  <Icon size={13} />
                  {nodeMeta[t].label}
                  <Plus size={11} />
                </button>
              );
            })}
            <div className="toolbar-spacer" />
            <select
              aria-label="Zoom du graphe"
              value={zoom}
              onChange={(e) => setZoom(Number(e.target.value))}
            >
              <option value={0.65}>65 %</option>
              <option value={0.75}>75 %</option>
              <option value={0.9}>90 %</option>
              <option value={1}>100 %</option>
            </select>
          </div>
          <div className="graph-canvas" onClick={() => setConnecting(null)}>
            <div
              ref={transformRef}
              className="graph-transform"
              style={{ transform: `scale(${zoom})` }}
            >
              <svg className="graph-cables" width="1500" height="1200">
                {doc.graph.edges.map((e) => {
                  const a = displayNodes.find((n) => n.id === e.from),
                    b = displayNodes.find((n) => n.id === e.to);
                  if (!a || !b) return null;
                  const x1 = ports[a.id]?.output?.x ?? a.x + 236,
                    y1 = ports[a.id]?.output?.y ?? a.y + 126,
                    x2 = ports[b.id]?.input?.x ?? b.x,
                    y2 = ports[b.id]?.input?.y ?? b.y + 126;
                  return (
                    <g key={e.id}>
                      <path
                        d={`M${x1},${y1} C${x1 + 90},${y1} ${x2 - 90},${y2} ${x2},${y2}`}
                        fill="none"
                        stroke="#a38ad8"
                        strokeWidth={2.5}
                      />
                      <path
                        className="cable-hit"
                        onClick={(ev) => {
                          ev.stopPropagation();
                          if (window.confirm("Retirer cette connexion ?"))
                            onChange({
                              ...doc,
                              graph: {
                                ...doc.graph,
                                edges: doc.graph.edges.filter(
                                  (c) => c.id !== e.id,
                                ),
                              },
                            });
                        }}
                        d={`M${x1},${y1} C${x1 + 90},${y1} ${x2 - 90},${y2} ${x2},${y2}`}
                        fill="none"
                        stroke="transparent"
                        strokeWidth={15}
                      />
                    </g>
                  );
                })}
              </svg>
              {displayNodes.map((n) => {
                const meta = nodeMeta[n.type],
                  Icon = meta.icon;
                return (
                  <div
                    key={n.id}
                    data-graph-node={n.id}
                    className={`graph-node node-${meta.color} ${selected === n.id ? "selected" : ""}`}
                    style={{ left: n.x, top: n.y }}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelected(n.id);
                    }}
                  >
                    <div
                      className="graph-node-heading"
                      onPointerDown={(e) => {
                        if ((e.target as HTMLElement).closest("button")) return;
                        e.preventDefault();
                        const sx = e.clientX,
                          sy = e.clientY;
                        let last = { x: n.x, y: n.y };
                        const move = (ev: PointerEvent) => {
                          last = {
                            x: Math.max(
                              0,
                              Math.round((n.x + (ev.clientX - sx) / zoom) / 8) *
                                8,
                            ),
                            y: Math.max(
                              0,
                              Math.round((n.y + (ev.clientY - sy) / zoom) / 8) *
                                8,
                            ),
                          };
                          setDragging({ id: n.id, ...last });
                        };
                        const up = () => {
                          window.removeEventListener("pointermove", move);
                          window.removeEventListener("pointerup", up);
                          setDragging(null);
                          onChange({
                            ...doc,
                            graph: {
                              ...doc.graph,
                              nodes: doc.graph.nodes.map((v) =>
                                v.id === n.id ? { ...v, ...last } : v,
                              ),
                            },
                          });
                        };
                        window.addEventListener("pointermove", move);
                        window.addEventListener("pointerup", up, {
                          once: true,
                        });
                      }}
                    >
                      <Icon size={16} />
                      <span>{meta.label}</span>
                      <MoreHorizontal size={16} />
                    </div>
                    <div className="graph-node-content">
                      <strong>{n.title}</strong>
                      <p>
                        {n.type === "source"
                          ? `${doc.sheet.length} publications fictives`
                          : n.type === "field"
                            ? `Champ : ${n.field}`
                            : n.type === "filter"
                              ? `Statut = ${n.value}`
                              : n.field || "Choisir un élément"}
                      </p>
                      <div className="graph-ports">
                        {n.type !== "source" ? (
                          <button
                            className={`graph-port port-in ${connecting ? "awaiting" : ""}`}
                            aria-label={`Connecter l’entrée de ${n.title}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              connect(n.id, false);
                            }}
                          >
                            <span />
                            Entrée
                          </button>
                        ) : (
                          <small>ARTICLES</small>
                        )}
                        {n.type !== "display" ? (
                          <button
                            className={`graph-port port-out ${connecting === n.id ? "connecting" : ""}`}
                            aria-label={`Connecter la sortie de ${n.title}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              connect(n.id, true);
                            }}
                          >
                            Sortie
                            <span />
                          </button>
                        ) : (
                          <small>PAGE</small>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="graph-help">
              <MousePointer2 size={14} />
              {connecting
                ? "Sélectionnez un point d’entrée · Échap ou clic dans le vide pour annuler"
                : "Déplacez les nœuds · Cliquez sur les points pour les connecter"}
            </div>
          </div>
          {output && (
            <div className="graph-results">
              <div>
                <CheckCircle2 size={15} />
                <strong>Résultat du test</strong>
                <span>{output.length} valeur(s)</span>
                <IconButton
                  label="Fermer les résultats"
                  onClick={() => setOutput(null)}
                >
                  <X size={14} />
                </IconButton>
              </div>
              <pre>
                {output.length
                  ? output.join("\n")
                  : "Aucun résultat. Reliez les nœuds à un affichage."}
              </pre>
            </div>
          )}
          <div className="graph-statusbar">
            <span className="green-dot" />
            {doc.graph.nodes.length} nœuds · {doc.graph.edges.length} connexions
            <span>Graphe enregistré avec le brouillon</span>
          </div>
        </div>
        <aside className="graph-inspector">
          <div className="inspector-title">
            <SlidersIcon />
            <strong>Configuration du nœud</strong>
          </div>
          {node ? (
            <div className="property-section">
              <div
                className={`node-type-badge node-${nodeMeta[node.type].color}`}
              >
                {nodeMeta[node.type].label}
              </div>
              <label className="field-label">
                Nom
                <input
                  value={node.title}
                  onChange={(e) => patch({ title: e.target.value })}
                />
              </label>
              {node.type === "source" ? (
                <div className="sidebar-tip">
                  <Database size={17} />
                  <p>
                    Source isolée : publications du tableur de cette page. Aucun
                    accès à une base externe.
                  </p>
                </div>
              ) : node.type === "field" ? (
                <>
                  <label className="field-label">
                    Champ
                    <select
                      value={node.field}
                      onChange={(e) => patch({ field: e.target.value })}
                    >
                      {columns.map((c) => (
                        <option key={c.key} value={c.key}>
                          {c.label}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label className="field-label">
                    Publication
                    <select
                      value={node.value}
                      onChange={(e) => patch({ value: e.target.value })}
                    >
                      <option value="">Toutes les publications</option>
                      {doc.sheet.map((r) => (
                        <option key={r.id} value={r.id}>
                          {r.title}
                        </option>
                      ))}
                    </select>
                  </label>
                </>
              ) : node.type === "filter" ? (
                <label className="field-label">
                  Statut autorisé
                  <select
                    value={node.value}
                    onChange={(e) => patch({ value: e.target.value })}
                  >
                    {["Publié", "Brouillon", "Masqué"].map((s) => (
                      <option key={s}>{s}</option>
                    ))}
                  </select>
                </label>
              ) : (
                <>
                  <label className="field-label">
                    Identifiant de l’élément
                    <input
                      value={node.field}
                      onChange={(e) => patch({ field: e.target.value })}
                      placeholder="article-title-0"
                    />
                  </label>
                  <button className="outline-button" onClick={applyBinding}>
                    <Link2 size={14} /> Appliquer la liaison
                  </button>
                  <p className="small-field-hint">
                    Applique le champ connecté à un élément de la page. Aucun
                    changement public.
                  </p>
                </>
              )}
              <div className="property-row">
                <NumericField
                  label="X"
                  value={node.x}
                  max={4000}
                  onChange={(x) => patch({ x })}
                />
                <NumericField
                  label="Y"
                  value={node.y}
                  max={4000}
                  onChange={(y) => patch({ y })}
                />
              </div>
              <button
                className="text-button danger-text"
                onClick={() => {
                  onChange({
                    ...doc,
                    graph: {
                      nodes: doc.graph.nodes.filter((n) => n.id !== node.id),
                      edges: doc.graph.edges.filter(
                        (e) => e.from !== node.id && e.to !== node.id,
                      ),
                    },
                  });
                  setSelected(null);
                }}
              >
                <Trash2 size={14} /> Supprimer le nœud
              </button>
            </div>
          ) : (
            <p className="empty-small">Sélectionnez un nœud.</p>
          )}
          <div className="graph-limit-note">
            Fonctionnel : sources, champs, filtre de statut, affichage et
            liaisons simples.
            <br />
            <br />À venir : conditions complexes et graphes partagés.
          </div>
        </aside>
      </div>
    </div>
  );
}
function SlidersIcon() {
  return <Network size={15} />;
}
