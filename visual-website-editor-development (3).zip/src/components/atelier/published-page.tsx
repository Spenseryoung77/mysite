"use client";
import { useEffect, useState } from "react";
import { PageRenderer } from "./page-renderer";
import type { PageDocument, Device } from "@/lib/atelier/model";
export function PublishedPage({ document }: { document: PageDocument }) {
  const [device, setDevice] = useState<Device>("desktop");
  useEffect(() => {
    const resize = () =>
      setDevice(
        window.innerWidth < 600
          ? "mobile"
          : window.innerWidth < 1000
            ? "tablet"
            : "desktop",
      );
    resize();
    window.addEventListener("resize", resize);
    return () => window.removeEventListener("resize", resize);
  }, []);
  return <PageRenderer document={document} device={device} publishedOnly />;
}
