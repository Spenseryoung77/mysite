"use client";
import {
  useEffect,
  useId,
  useRef,
  useState,
  type CSSProperties,
  type DragEvent,
  type MouseEvent,
} from "react";
import {
  ArrowRight,
  BookOpen,
  Feather,
  Heart,
  Menu,
  X,
  Quote,
  LockKeyhole,
  Move,
} from "lucide-react";
import {
  resolveStyle,
  resolveText,
  type PageDocument,
  type PageElement,
  type Device,
} from "@/lib/atelier/model";

type Props = {
  document: PageDocument;
  device?: Device;
  editable?: boolean;
  selected?: string[];
  onSelect?: (id: string, multiple: boolean) => void;
  onText?: (id: string, text: string) => void;
  onMove?: (id: string, target: string) => void;
  onResize?: (id: string, width: number, height: number) => void;
  onContext?: (event: MouseEvent, id: string) => void;
  publishedOnly?: boolean;
};
const typeLabels: Record<string, string> = {
  heading: "Titre",
  text: "Texte",
  section: "Section",
  button: "Bouton",
  container: "Conteneur",
  image: "Image",
  card: "Carte",
  header: "En-tête",
  footer: "Pied de page",
};
export function PageRenderer({
  document: doc,
  device = "desktop",
  editable = false,
  selected = [],
  onSelect,
  onText,
  onMove,
  onResize,
  onContext,
  publishedOnly = false,
}: Props) {
  const navigationId = useId(),
    menuButton = useRef<HTMLButtonElement>(null);
  const [editing, setEditing] = useState<string | null>(null),
    [menuOpen, setMenuOpen] = useState(false),
    [hidden, setHidden] = useState<string[]>([]),
    [drop, setDrop] = useState<string | null>(null);
  useEffect(() => {
    if (!editing) return;
    const span = Array.from(
      window.document.querySelectorAll<HTMLElement>(
        ".artboard-inner [data-element-id]",
      ),
    )
      .find((e) => e.dataset.elementId === editing)
      ?.querySelector<HTMLElement>(".element-text");
    span?.focus();
  }, [editing]);
  function render(el: PageElement, sharedParent = false): React.ReactNode {
    const s = resolveStyle(el, device);
    if (el.hidden || s.hidden || hidden.includes(el.id)) return null;
    const isShared = sharedParent || !!el.shared,
      isSelected = editable && selected.includes(el.id),
      protectedEl = !!el.locked || isShared;
    const style: CSSProperties = {
      fontSize: s.fontSize,
      fontWeight: s.fontWeight,
      color: s.color,
      backgroundColor: s.backgroundColor,
      padding: s.padding,
      gap: s.gap,
      borderRadius: s.borderRadius,
      opacity: s.opacity,
      width: s.width,
      height: s.height,
      textAlign: s.textAlign,
      flexDirection: s.direction,
      translate: s.x || s.y ? `${s.x || 0}px ${s.y || 0}px` : undefined,
    };
    const select = (e: MouseEvent) => {
      if (!editable) return;
      e.stopPropagation();
      if (editing === el.id) return;
      e.preventDefault();
      onSelect?.(el.id, e.shiftKey);
    };
    const startDrag = (e: DragEvent) => {
      if (!editable || protectedEl || editing === el.id) {
        e.preventDefault();
        return;
      }
      e.stopPropagation();
      e.dataTransfer.setData("application/atelier-element", el.id);
      e.dataTransfer.effectAllowed = "move";
    };
    const action = () => {
      if (!editable && el.interaction?.action === "toggle") {
        const target = el.interaction.target;
        setHidden((h) =>
          h.includes(target) ? h.filter((id) => id !== target) : [...h, target],
        );
      }
      if (
        !editable &&
        el.interaction?.action === "link" &&
        el.interaction.target
      )
        window.location.assign(el.interaction.target);
    };
    const events = editable
      ? {
          onClick: select,
          onDoubleClick: (e: MouseEvent) => {
            if (
              ["heading", "text", "button"].includes(el.kind) &&
              !protectedEl
            ) {
              e.preventDefault();
              e.stopPropagation();
              setEditing(el.id);
            }
          },
          onContextMenu: (e: MouseEvent) => {
            e.preventDefault();
            e.stopPropagation();
            onContext?.(e, el.id);
          },
          draggable: editing !== el.id && !protectedEl,
          onDragStart: startDrag,
          onDragOver: (e: DragEvent) => {
            if (e.dataTransfer.types.includes("application/atelier-element")) {
              e.preventDefault();
              e.stopPropagation();
              setDrop(el.id);
            }
          },
          onDragLeave: () => setDrop(null),
          onDrop: (e: DragEvent) => {
            e.preventDefault();
            e.stopPropagation();
            setDrop(null);
            const id = e.dataTransfer.getData("application/atelier-element");
            if (id) onMove?.(id, el.id);
          },
        }
      : {
          onClick: el.interaction?.trigger !== "hover" ? action : undefined,
          onMouseEnter:
            el.interaction?.trigger === "hover" ? action : undefined,
        };
    const className = `page-element pe-${el.kind} ${el.role ? `role-${el.role}` : ""} ${editable ? "is-editable" : ""} ${isSelected ? "element-selected" : ""} ${drop === el.id ? "element-drop" : ""} ${editing === el.id ? "element-editing" : ""}`;
    const marker = isSelected ? (
      <>
        <span className="selection-tag" contentEditable={false}>
          {protectedEl ? <LockKeyhole size={10} /> : <Move size={10} />}{" "}
          {typeLabels[el.kind]} <span>· {el.name}</span>
        </span>
        {!protectedEl &&
          ["tl", "tr", "bl", "br"].map((c) => (
            <span
              key={c}
              className={`resize-handle ${c}`}
              contentEditable={false}
              onPointerDown={(e) => {
                e.preventDefault();
                e.stopPropagation();
                const target = e.currentTarget.parentElement!;
                const rect = target.getBoundingClientRect();
                const scale = rect.width / (target.offsetWidth || rect.width);
                const startX = e.clientX,
                  startY = e.clientY,
                  startW = target.offsetWidth,
                  startH = target.offsetHeight;
                const move = (ev: PointerEvent) => {
                  target.style.width = `${Math.max(20, startW + ((ev.clientX - startX) * (c.includes("l") ? -1 : 1)) / scale)}px`;
                  target.style.height = `${Math.max(20, startH + ((ev.clientY - startY) * (c.includes("t") ? -1 : 1)) / scale)}px`;
                };
                const end = () => {
                  window.removeEventListener("pointermove", move);
                  window.removeEventListener("pointerup", end);
                  onResize?.(el.id, target.offsetWidth, target.offsetHeight);
                };
                window.addEventListener("pointermove", move);
                window.addEventListener("pointerup", end, { once: true });
              }}
            />
          ))}
      </>
    ) : null;
    const childNodes = el.children.map((c) => render(c, isShared));
    let content: React.ReactNode = childNodes.length
      ? childNodes
      : resolveText(el, doc, publishedOnly);
    if (el.role === "brand")
      content = (
        <>
          <Feather className="site-feather" size={29} />
          <span>{el.text}</span>
        </>
      );
    if (el.role === "verse-label")
      content = (
        <>
          <BookOpen size={15} />
          {el.text}
        </>
      );
    if (el.role === "primary-button")
      content = (
        <>
          {el.text}
          <ArrowRight size={15} />
        </>
      );
    if (el.role === "support")
      content = (
        <>
          <Heart size={13} />
          {el.text}
        </>
      );
    if (el.role === "site-header")
      content = (
        <>
          {childNodes}
          <button
            ref={menuButton}
            aria-controls={navigationId}
            className="site-menu-button"
            aria-label={menuOpen ? "Fermer le menu" : "Ouvrir le menu"}
            aria-expanded={menuOpen}
            onClick={(e) => {
              e.stopPropagation();
              setMenuOpen(!menuOpen);
            }}
            onKeyDown={(e) => {
              if (e.key === "Escape") setMenuOpen(false);
            }}
          >
            {menuOpen ? <X size={23} /> : <Menu size={23} />}
          </button>
        </>
      );
    const textEditable = editing === el.id;
    const textProps = textEditable
      ? {
          contentEditable: true,
          suppressContentEditableWarning: true,
          onBlur: (e: React.FocusEvent<HTMLElement>) => {
            setEditing(null);
            onText?.(el.id, e.currentTarget.innerText);
          },
          onKeyDown: (e: React.KeyboardEvent) => {
            e.stopPropagation();
            if (e.key === "Escape") {
              setEditing(null);
              (e.target as HTMLElement).blur();
            }
          },
        }
      : {};
    const common = {
      key: el.id,
      className,
      style,
      "data-element-id": el.id,
      "data-name": el.name,
      tabIndex: editable ? 0 : undefined,
      onKeyDown: editable
        ? (e: React.KeyboardEvent) => {
            if (e.target === e.currentTarget && e.key === "Enter")
              onSelect?.(el.id, e.shiftKey);
          }
        : undefined,
      ...events,
    };
    if (el.kind === "image")
      return (
        <figure {...common}>
          <img
            src={el.src || "/images/mountains.jpg"}
            alt={el.alt || ""}
            draggable={false}
          />
          {marker}
        </figure>
      );
    if (el.kind === "heading") {
      const Tag = el.role === "hero-title" ? "h1" : "h2";
      return (
        <Tag {...common}>
          <span className="element-text" {...textProps}>
            {content}
          </span>
          {marker}
        </Tag>
      );
    }
    if (el.kind === "text")
      return (
        <p {...common}>
          <span className="element-text" {...textProps}>
            {content}
          </span>
          {marker}
        </p>
      );
    if (el.kind === "button")
      return (
        <a
          {...common}
          href={editable ? undefined : el.href}
          onClick={
            editable
              ? events.onClick
              : (e) => {
                  if (el.interaction) {
                    e.preventDefault();
                    action();
                  }
                }
          }
        >
          <span className="element-text" {...textProps}>
            {content}
          </span>
          {marker}
        </a>
      );
    if (el.role === "navigation")
      return (
        <nav {...common} id={navigationId} aria-label="Navigation principale">
          {content}
          {marker}
        </nav>
      );
    return (
      <div {...common}>
        {el.role === "hero" && (
          <>
            <img
              className="hero-background"
              src={el.src || "/images/mountains.jpg"}
              alt={el.alt || ""}
              draggable={false}
            />
            <div className="hero-shade" />
          </>
        )}
        {el.role === "verse" && (
          <Quote size={28} className="verse-decoration" />
        )}
        {content}
        {marker}
      </div>
    );
  }
  return (
    <div
      className={`page-document ${editable ? "document-editable" : ""} ${menuOpen ? "site-menu-open" : ""}`}
      data-device={device}
      style={
        {
          "--site-primary": doc.theme.primary,
          "--site-bg": doc.theme.background,
          "--site-font":
            doc.theme.font === "Inter"
              ? '"Inter Variable", Arial'
              : doc.theme.font,
        } as CSSProperties
      }
      onKeyDown={(e) => {
        if (e.key === "Escape" && menuOpen) {
          e.preventDefault();
          e.stopPropagation();
          setMenuOpen(false);
          menuButton.current?.focus();
        }
      }}
    >
      {doc.elements.length ? (
        doc.elements.map((el) => render(el))
      ) : (
        <div className="empty-document">
          <Feather size={34} />
          <h2>Une page, mille possibilités.</h2>
          <p>Ajoutez votre premier élément depuis le panneau de gauche.</p>
        </div>
      )}
    </div>
  );
}
