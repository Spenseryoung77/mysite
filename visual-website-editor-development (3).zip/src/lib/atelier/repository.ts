import { db } from "@/db";
import { atelierPages, atelierVersions } from "@/db/schema";
import { eq, desc, and } from "drizzle-orm";
import { createHash } from "node:crypto";
import { isDeepStrictEqual } from "node:util";
import { createDemoDocument, demoPages } from "./seed";
import {
  documentSchema,
  flatten,
  type PageDocument,
  type PageRecord,
  type PageSummary,
} from "./model";
import { ApiError, seal, unseal } from "./security";

type Row = typeof atelierPages.$inferSelect;
const hash = (doc: PageDocument) =>
  createHash("sha256").update(JSON.stringify(doc)).digest("hex");
function serialize(row: Row): PageRecord {
  return { ...row, updatedAt: row.updatedAt.toISOString() };
}
let initialized: Promise<void> | null = null;
export async function ensureSeed() {
  if (!initialized)
    initialized = (async () => {
      await db.transaction(async (tx) => {
        for (const p of demoPages) {
          const document = createDemoDocument(p.title, p.slug);
          const [inserted] = await tx
            .insert(atelierPages)
            .values({
              ...p,
              draft: document,
              published: p.compatible ? document : null,
              status: p.compatible ? "Publié" : "Non compatible",
              publishedRevision: p.compatible ? 1 : 0,
            })
            .onConflictDoNothing()
            .returning();
          if (inserted && p.compatible)
            await tx.insert(atelierVersions).values({
              id: crypto.randomUUID(),
              pageId: p.id,
              revision: 1,
              document,
              label: "Version initiale — démonstration",
            });
        }
      });
    })().catch((e) => {
      initialized = null;
      throw e;
    });
  await initialized;
}
export async function listPages(): Promise<PageSummary[]> {
  await ensureSeed();
  const rows = await db
    .select({
      id: atelierPages.id,
      title: atelierPages.title,
      slug: atelierPages.slug,
      kind: atelierPages.kind,
      category: atelierPages.category,
      status: atelierPages.status,
      compatible: atelierPages.compatible,
      revision: atelierPages.revision,
      publishedRevision: atelierPages.publishedRevision,
      updatedAt: atelierPages.updatedAt,
    })
    .from(atelierPages)
    .orderBy(atelierPages.updatedAt);
  return rows.map((r) => ({ ...r, updatedAt: r.updatedAt.toISOString() }));
}
export async function getPage(id: string) {
  await ensureSeed();
  const [row] = await db
    .select()
    .from(atelierPages)
    .where(eq(atelierPages.id, id));
  if (!row) throw new ApiError("Page introuvable.", 404);
  return serialize(row);
}
export async function createPage(input: {
  title: string;
  slug: string;
  sourceId?: string;
  blank?: boolean;
}) {
  const title = String(input.title || "")
    .trim()
    .slice(0, 150);
  if (!title) throw new ApiError("Donnez un nom à votre page.");
  let doc = input.sourceId
    ? (await getPage(input.sourceId)).draft
    : createDemoDocument(title, input.slug);
  doc = structuredClone(doc);
  doc.title = title;
  doc.slug = input.slug;
  if (input.blank) doc.elements = [];
  const valid = documentSchema.safeParse(doc);
  if (!valid.success) throw new ApiError(valid.error.issues[0].message);
  const id = crypto.randomUUID();
  const [row] = await db
    .insert(atelierPages)
    .values({ id, title, slug: doc.slug, draft: doc })
    .returning();
  return serialize(row);
}
export async function saveDraft(
  id: string,
  expectedRevision: number,
  input: unknown,
) {
  const parsed = documentSchema.safeParse(input);
  if (!parsed.success)
    throw new ApiError(parsed.error.issues[0]?.message || "Document invalide.");
  const doc = parsed.data;
  return db.transaction(async (tx) => {
    const [current] = await tx
      .select()
      .from(atelierPages)
      .where(eq(atelierPages.id, id))
      .for("update");
    if (!current) throw new ApiError("Page introuvable.", 404);
    if (!current.compatible)
      throw new ApiError(
        "Cette page doit être adaptée séparément avant toute édition.",
        403,
      );
    if (current.revision !== expectedRevision)
      throw new ApiError(
        "Conflit de révision : une autre session a enregistré cette page. Exportez votre travail, puis rechargez la version serveur.",
        409,
      );
    const oldShared = flatten(current.draft.elements).filter((e) => e.shared);
    for (const el of oldShared) {
      const next = flatten(doc.elements).find((e) => e.id === el.id);
      if (next && next.shared && !isDeepStrictEqual(next, el))
        throw new ApiError(
          "Détachez une copie locale de ce composant partagé avant de le modifier.",
          403,
        );
    }
    const [row] = await tx
      .update(atelierPages)
      .set({
        draft: doc,
        title: doc.title,
        slug: doc.slug,
        revision: current.revision + 1,
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(atelierPages.id, id),
          eq(atelierPages.revision, expectedRevision),
        ),
      )
      .returning();
    return serialize(row);
  });
}
export async function reviewPage(id: string) {
  const page = await getPage(id);
  if (!page.compatible)
    throw new ApiError("Cette page n’est pas compatible.", 403);
  return {
    revision: page.revision,
    publishedRevision: page.publishedRevision,
    token: seal({
      pageId: id,
      revision: page.revision,
      publishedRevision: page.publishedRevision,
      hash: hash(page.draft),
      exp: Date.now() + 10 * 60000,
    }),
    draft: page.draft,
    published: page.published,
  };
}
export async function publishPage(
  id: string,
  token: string,
  confirmed: boolean,
) {
  if (confirmed !== true)
    throw new ApiError("Une confirmation explicite est obligatoire.");
  const proof = unseal(token);
  if (!proof || proof.pageId !== id)
    throw new ApiError(
      "La vérification a expiré. Comparez à nouveau les versions.",
      409,
    );
  return db.transaction(async (tx) => {
    const [row] = await tx
      .select()
      .from(atelierPages)
      .where(eq(atelierPages.id, id))
      .for("update");
    if (!row) throw new ApiError("Page introuvable.", 404);
    if (
      row.revision !== proof.revision ||
      row.publishedRevision !== proof.publishedRevision ||
      hash(row.draft) !== proof.hash
    )
      throw new ApiError(
        "Le brouillon ou la publication a changé. Une nouvelle vérification est nécessaire.",
        409,
      );
    if (!row.compatible) throw new ApiError("Publication non autorisée.", 403);
    const revision = row.publishedRevision + 1;
    await tx.insert(atelierVersions).values({
      id: crypto.randomUUID(),
      pageId: id,
      revision,
      document: row.draft,
      label: `Publication v${revision}`,
    });
    const [updated] = await tx
      .update(atelierPages)
      .set({
        published: row.draft,
        publishedRevision: revision,
        status: "Publié",
        updatedAt: new Date(),
      })
      .where(eq(atelierPages.id, id))
      .returning();
    return serialize(updated);
  });
}
export async function listVersions(id: string) {
  await getPage(id);
  const rows = await db
    .select()
    .from(atelierVersions)
    .where(eq(atelierVersions.pageId, id))
    .orderBy(desc(atelierVersions.createdAt));
  return rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() }));
}
export async function restoreVersion(
  id: string,
  versionId: string,
  expectedPublishedRevision: number,
  confirmed: boolean,
) {
  if (confirmed !== true) throw new ApiError("Confirmez la restauration.");
  return db.transaction(async (tx) => {
    const [row] = await tx
      .select()
      .from(atelierPages)
      .where(eq(atelierPages.id, id))
      .for("update");
    const [version] = await tx
      .select()
      .from(atelierVersions)
      .where(
        and(eq(atelierVersions.id, versionId), eq(atelierVersions.pageId, id)),
      );
    if (!row || !version) throw new ApiError("Version introuvable.", 404);
    if (row.publishedRevision !== expectedPublishedRevision)
      throw new ApiError(
        "La publication a changé. Rechargez l’historique.",
        409,
      );
    const revision = row.publishedRevision + 1;
    await tx.insert(atelierVersions).values({
      id: crypto.randomUUID(),
      pageId: id,
      revision,
      document: version.document,
      label: `Restauration de v${version.revision}`,
    });
    const [updated] = await tx
      .update(atelierPages)
      .set({
        published: version.document,
        publishedRevision: revision,
        status: "Publié",
        updatedAt: new Date(),
      })
      .where(eq(atelierPages.id, id))
      .returning();
    return serialize(updated);
  });
}
export async function deletePage(id: string, confirmed: boolean) {
  const page = await getPage(id);
  if (confirmed !== true) throw new ApiError("Confirmez la suppression.");
  if (page.published)
    throw new ApiError(
      "Une page publiée est protégée. Seules les nouvelles pages non publiées peuvent être supprimées dans ce lot.",
      403,
    );
  await db.delete(atelierPages).where(eq(atelierPages.id, id));
  return { ok: true };
}
