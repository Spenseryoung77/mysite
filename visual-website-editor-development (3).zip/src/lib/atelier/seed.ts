import type { PageDocument, PageElement, SheetRow } from "./model";

export const demoRows: SheetRow[] = [
  {
    id: "a1",
    title: "Trouver la paix dans le silence",
    category: "Méditations",
    author: "Marie Laurent",
    status: "Publié",
    date: "2026-06-14",
  },
  {
    id: "a2",
    title: "La foi, un chemin de confiance",
    category: "Foi & Bible",
    author: "Thomas Bernard",
    status: "Publié",
    date: "2026-06-12",
  },
  {
    id: "a3",
    title: "Ces petits miracles du quotidien",
    category: "Témoignages",
    author: "Anne Dubois",
    status: "Publié",
    date: "2026-06-10",
  },
  {
    id: "a4",
    title: "Une espérance qui nous rassemble",
    category: "Actualités",
    author: "Paul Martin",
    status: "Brouillon",
    date: "2026-06-09",
  },
  {
    id: "a5",
    title: "Apprendre à ralentir",
    category: "Méditations",
    author: "Marie Laurent",
    status: "Publié",
    date: "2026-06-07",
  },
  {
    id: "a6",
    title: "Marcher ensemble",
    category: "Témoignages",
    author: "Anne Dubois",
    status: "Masqué",
    date: "2026-06-05",
  },
];
export function element(
  id: string,
  kind: PageElement["kind"],
  name: string,
  text = "",
  children: PageElement[] = [],
): PageElement {
  return { id, kind, name, text, styles: { desktop: {} }, children };
}
export function createDemoDocument(
  title = "Accueil",
  slug = "/",
): PageDocument {
  const header = element("site-header", "header", "En-tête du site", "", [
    {
      ...element("site-brand", "heading", "Nom du site", "Paroles Inspirées"),
      role: "brand",
      styles: {
        desktop: { fontSize: 25 },
        tablet: { fontSize: 21 },
        mobile: { fontSize: 23 },
      },
    },
    {
      ...element("site-navigation", "container", "Navigation", "", [
        {
          ...element("nav-home", "button", "Lien Accueil", "Accueil"),
          href: "/site/accueil",
        },
        {
          ...element("nav-news", "button", "Lien Actualités", "Actualités"),
          href: "/site/actualites",
        },
        {
          ...element("nav-faith", "button", "Lien Foi & Bible", "Foi & Bible"),
          href: "/site/foi-bible",
        },
        {
          ...element(
            "nav-meditations",
            "button",
            "Lien Méditations",
            "Méditations",
          ),
          href: "/site/meditations",
        },
        {
          ...element("nav-more", "button", "Lien Témoignages", "Témoignages"),
          href: "/site/temoignages",
        },
      ]),
      role: "navigation",
    },
    {
      ...element("nav-support", "button", "Nous soutenir", "Nous soutenir"),
      href: "/site/soutenir",
      role: "support",
    },
  ]);
  header.shared = true;
  header.role = "site-header";
  const hero = element("hero-section", "section", "Section principale", "", [
    {
      ...element(
        "hero-eyebrow",
        "text",
        "Surtitre",
        "UN INSTANT POUR L’ESSENTIEL",
      ),
      role: "eyebrow",
      styles: { desktop: { fontSize: 10, fontWeight: 600, color: "#ffffff" } },
    },
    {
      ...element(
        "hero-title",
        "heading",
        "Titre principal",
        "Une parole peut\nilluminer votre journée.",
      ),
      role: "hero-title",
      styles: {
        desktop: {
          fontSize: 62,
          fontWeight: 400,
          color: "#ffffff",
          textAlign: "center",
        },
        tablet: { fontSize: 50 },
        mobile: { fontSize: 36 },
      },
    },
    {
      ...element(
        "hero-description",
        "text",
        "Description",
        "Des mots qui inspirent, une foi qui grandit.\nPrenez le temps de nourrir votre cœur et votre esprit.",
      ),
      role: "hero-description",
      styles: {
        desktop: { fontSize: 15, color: "#ffffff", textAlign: "center" },
        mobile: { fontSize: 12 },
      },
    },
    {
      ...element("hero-actions", "container", "Boutons de la section", "", [
        {
          ...element(
            "hero-button",
            "button",
            "Découvrir les méditations",
            "Explorer les méditations",
          ),
          href: "/site/meditations",
          role: "primary-button",
        },
        {
          ...element(
            "hero-secondary",
            "button",
            "Notre mission",
            "Notre mission",
          ),
          href: "#mission",
          role: "secondary-button",
        },
      ]),
      role: "hero-actions",
      styles: {
        desktop: { direction: "row", gap: 12 },
        mobile: { direction: "column" },
      },
    },
  ]);
  hero.role = "hero";
  hero.src = "/images/mountains.jpg";
  hero.alt = "Le soleil se lève sur une vallée de montagnes paisible";
  const verse = element("daily-verse", "section", "La parole du jour", "", [
    {
      ...element(
        "verse-label",
        "text",
        "Libellé du verset",
        "LA PAROLE DU JOUR",
      ),
      role: "verse-label",
    },
    {
      ...element(
        "verse-text",
        "text",
        "Verset",
        "« Ta parole est une lampe à mes pieds, une lumière sur mon sentier. »",
      ),
      role: "verse-quote",
    },
    {
      ...element(
        "verse-reference",
        "text",
        "Référence biblique",
        "Psaume 119:105",
      ),
      role: "verse-reference",
    },
  ]);
  verse.role = "verse";
  const cards = demoRows.slice(0, 3).map((row, i) => ({
    ...element(`article-${i}`, "card", `Carte — ${row.category}`, "", [
      {
        ...element(`article-image-${i}`, "image", "Image de l’article"),
        src: [
          "/images/peace.jpg",
          "/images/bible.jpg",
          "/images/mountains.jpg",
        ][i],
        alt: [
          "Une femme dans la lumière du soleil",
          "Une Bible ouverte",
          "Une vallée au lever du soleil",
        ][i],
      },
      {
        ...element(`article-category-${i}`, "text", "Rubrique", row.category),
        role: "article-category",
      },
      {
        ...element(
          `article-title-${i}`,
          "heading",
          "Titre de l’article",
          row.title,
        ),
        styles: { desktop: { fontSize: 23, fontWeight: 400 } },
        binding: {
          source: "articles" as const,
          rowId: row.id,
          field: "title",
          fallback: row.title,
        },
      },
      {
        ...element(
          `article-date-${i}`,
          "text",
          "Auteur et date",
          `${row.author} · ${14 - i * 2} juin 2026`,
        ),
        role: "article-date",
      },
    ]),
    role: "article-card",
  }));
  const articles = element(
    "latest-section",
    "section",
    "Dernières inspirations",
    "",
    [
      {
        ...element("latest-heading", "container", "Titre de rubrique", "", [
          {
            ...element(
              "latest-title",
              "heading",
              "Titre de la rubrique",
              "Pour nourrir votre inspiration",
            ),
            styles: { desktop: { fontSize: 31, fontWeight: 400 } },
          },
          {
            ...element(
              "latest-link",
              "button",
              "Voir les publications",
              "Toutes les publications →",
            ),
            href: "/site/actualites",
            role: "text-link",
          },
        ]),
        role: "section-heading",
      },
      {
        ...element(
          "article-grid",
          "container",
          "Grille des articles",
          "",
          cards,
        ),
        role: "article-grid",
        styles: {
          desktop: { direction: "row", gap: 22 },
          mobile: { direction: "column" },
        },
      },
    ],
  );
  articles.role = "latest";
  const footer = {
    ...element(
      "site-footer",
      "footer",
      "Pied de page",
      "Paroles Inspirées — Des paroles qui éclairent, une foi qui nous relie.",
    ),
    role: "site-footer",
    shared: true,
  };
  const doc: PageDocument = {
    version: 1,
    title,
    slug,
    theme: { primary: "#74634b", background: "#ffffff", font: "Georgia" },
    elements: [header, hero, verse, articles, footer],
    sheet: structuredClone(demoRows),
    graph: {
      nodes: [
        {
          id: "source-articles",
          type: "source",
          title: "Articles",
          x: 65,
          y: 145,
          field: "articles",
          value: "Données de démonstration",
        },
        {
          id: "field-title",
          type: "field",
          title: "Titre de l’article",
          x: 375,
          y: 100,
          field: "title",
          value: "a1",
        },
        {
          id: "filter-published",
          type: "filter",
          title: "Contenus publiés",
          x: 375,
          y: 315,
          field: "status",
          value: "Publié",
        },
        {
          id: "display-title",
          type: "display",
          title: "Titre de la carte",
          x: 695,
          y: 145,
          field: "article-title-0",
          value: "Texte",
        },
      ],
      edges: [
        { id: "e1", from: "source-articles", to: "field-title" },
        { id: "e2", from: "source-articles", to: "filter-published" },
        { id: "e3", from: "field-title", to: "display-title" },
      ],
    },
  };
  if (title !== "Accueil") {
    const h = doc.elements[1];
    h.children[1].text = title;
    h.children[2].text = `Découvrez nos ${title.toLocaleLowerCase("fr")} et laissez-vous inspirer, un jour à la fois.`;
    h.styles.desktop = { padding: 55 };
  }
  return doc;
}
export const demoPages = [
  {
    id: "accueil",
    title: "Accueil",
    slug: "/",
    category: "Pages publiques",
    kind: "page",
    compatible: true,
  },
  {
    id: "actualites",
    title: "Actualités",
    slug: "/actualites",
    category: "Pages publiques",
    kind: "rubrique",
    compatible: true,
  },
  {
    id: "foi-bible",
    title: "Foi & Bible",
    slug: "/foi-bible",
    category: "Pages publiques",
    kind: "rubrique",
    compatible: true,
  },
  {
    id: "meditations",
    title: "Méditations",
    slug: "/meditations",
    category: "Pages publiques",
    kind: "rubrique",
    compatible: true,
  },
  {
    id: "temoignages",
    title: "Témoignages",
    slug: "/temoignages",
    category: "Pages publiques",
    kind: "rubrique",
    compatible: true,
  },
  {
    id: "bible",
    title: "La Bible",
    slug: "/bible",
    category: "Pages publiques",
    kind: "page",
    compatible: true,
  },
  {
    id: "medias",
    title: "Vidéos & podcasts",
    slug: "/medias",
    category: "Pages publiques",
    kind: "rubrique",
    compatible: true,
  },
  {
    id: "agenda",
    title: "Agenda",
    slug: "/agenda",
    category: "Pages publiques",
    kind: "rubrique",
    compatible: true,
  },
  {
    id: "soutenir",
    title: "Nous soutenir",
    slug: "/soutenir",
    category: "Pages publiques",
    kind: "page",
    compatible: true,
  },
  {
    id: "modele-article",
    title: "Modèle d’article",
    slug: "/modele-article",
    category: "Modèles",
    kind: "modèle",
    compatible: true,
  },
  {
    id: "espace-membre",
    title: "Espace membre",
    slug: "/membre",
    category: "Espaces privés",
    kind: "modèle",
    compatible: false,
  },
  {
    id: "administration",
    title: "Administration",
    slug: "/administration",
    category: "Espaces privés",
    kind: "administration",
    compatible: false,
  },
];
