import type {
  PageDocument,
  PageRecord,
  PageSummary,
  VersionRecord,
} from "./model";
let csrf = "";
async function request<T>(
  path: string,
  method = "GET",
  body?: unknown,
): Promise<T> {
  const response = await fetch(`/api/atelier${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(method !== "GET" ? { "x-atelier-csrf": csrf } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
    cache: "no-store",
  });
  let data;
  try {
    data = await response.json();
  } catch {
    throw new Error(
      "Réponse du serveur incertaine. Vérifiez l’état avant de recommencer.",
    );
  }
  if (!response.ok) throw new Error(data.error || "La requête a échoué.");
  return data;
}
export type Review = {
  revision: number;
  publishedRevision: number;
  token: string;
  draft: PageDocument;
  published: PageDocument | null;
};
export const atelierApi = {
  async initialize() {
    const data = await request<{ pages: PageSummary[]; csrf: string }>("");
    csrf = data.csrf;
    return data.pages;
  },
  get: (id: string) => request<PageRecord>(`/${encodeURIComponent(id)}`),
  save: (id: string, revision: number, document: PageDocument) =>
    request<PageRecord>(`/${encodeURIComponent(id)}`, "PUT", {
      expectedRevision: revision,
      document,
    }),
  create: (title: string, slug: string, sourceId?: string, blank = false) =>
    request<PageRecord>("", "POST", { title, slug, sourceId, blank }),
  review: (id: string) =>
    request<Review>(`/${id}`, "POST", { action: "review" }),
  publish: (id: string, token: string) =>
    request<PageRecord>(`/${id}`, "POST", {
      action: "publish",
      token,
      confirmed: true,
    }),
  versions: (id: string) => request<VersionRecord[]>(`/${id}?mode=versions`),
  restore: (id: string, versionId: string, revision: number) =>
    request<PageRecord>(`/${id}`, "POST", {
      action: "restore",
      versionId,
      expectedPublishedRevision: revision,
      confirmed: true,
    }),
  delete: (id: string) =>
    request<{ ok: true }>(`/${id}`, "POST", {
      action: "delete",
      confirmed: true,
    }),
};
export function downloadFile(
  name: string,
  data: string,
  type = "application/json",
) {
  const url = URL.createObjectURL(new Blob([data], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
