import { z } from "zod";

export type Device = "desktop" | "tablet" | "mobile";
export type ElementKind =
  | "header"
  | "footer"
  | "section"
  | "container"
  | "heading"
  | "text"
  | "button"
  | "image"
  | "card";
export type ElementStyle = {
  fontSize?: number;
  fontWeight?: number;
  color?: string;
  backgroundColor?: string;
  padding?: number;
  gap?: number;
  borderRadius?: number;
  opacity?: number;
  width?: number;
  height?: number;
  textAlign?: "left" | "center" | "right";
  direction?: "row" | "column";
  hidden?: boolean;
  x?: number;
  y?: number;
};
export type Binding = {
  source: "articles";
  rowId: string;
  field: string;
  fallback: string;
};
export type PageElement = {
  id: string;
  kind: ElementKind;
  name: string;
  text?: string;
  href?: string;
  src?: string;
  alt?: string;
  locked?: boolean;
  hidden?: boolean;
  shared?: boolean;
  role?: string;
  styles: Partial<Record<Device, ElementStyle>>;
  children: PageElement[];
  binding?: Binding;
  interaction?: {
    trigger: "click" | "hover";
    action: "link" | "toggle";
    target: string;
  };
};
export type GraphNode = {
  id: string;
  type: "source" | "field" | "filter" | "display";
  title: string;
  x: number;
  y: number;
  field: string;
  value: string;
};
export type GraphEdge = { id: string; from: string; to: string };
export type SheetRow = {
  id: string;
  title: string;
  category: string;
  author: string;
  status: string;
  date: string;
};
export type PageDocument = {
  version: 1;
  title: string;
  slug: string;
  theme: { primary: string; background: string; font: string };
  elements: PageElement[];
  graph: { nodes: GraphNode[]; edges: GraphEdge[] };
  sheet: SheetRow[];
};
export type PageSummary = {
  id: string;
  title: string;
  slug: string;
  kind: string;
  category: string;
  status: string;
  compatible: boolean;
  revision: number;
  publishedRevision: number;
  updatedAt: string;
};
export type PageRecord = PageSummary & {
  draft: PageDocument;
  published: PageDocument | null;
};
export type VersionRecord = {
  id: string;
  revision: number;
  label: string;
  document: PageDocument;
  createdAt: string;
};

const safeColor = z.string().regex(/^(#[0-9a-fA-F]{3,8}|transparent)$/);
const styleSchema = z
  .object({
    fontSize: z.number().min(8).max(180).optional(),
    fontWeight: z.number().min(100).max(900).optional(),
    color: safeColor.optional(),
    backgroundColor: safeColor.optional(),
    padding: z.number().min(0).max(300).optional(),
    gap: z.number().min(0).max(160).optional(),
    borderRadius: z.number().min(0).max(200).optional(),
    opacity: z.number().min(0).max(1).optional(),
    width: z.number().min(20).max(2400).optional(),
    height: z.number().min(20).max(2000).optional(),
    textAlign: z.enum(["left", "center", "right"]).optional(),
    direction: z.enum(["row", "column"]).optional(),
    hidden: z.boolean().optional(),
    x: z.number().min(-1000).max(2400).optional(),
    y: z.number().min(-1000).max(2400).optional(),
  })
  .strict();
export function isSafeUrl(value: string, image = false) {
  if (!value) return true;
  if (value.startsWith("/") && !value.startsWith("//") && !/[\\\s]/.test(value))
    return true;
  if (!image && /^#[a-zA-Z0-9_-]*$/.test(value)) return true;
  try {
    const u = new URL(value);
    return (
      u.protocol === "https:" ||
      (!image && ["mailto:", "tel:"].includes(u.protocol))
    );
  } catch {
    return false;
  }
}
const elementSchema: z.ZodType<PageElement> = z.lazy(() =>
  z
    .object({
      id: z
        .string()
        .min(1)
        .max(100)
        .regex(/^[a-zA-Z0-9_-]+$/),
      kind: z.enum([
        "header",
        "footer",
        "section",
        "container",
        "heading",
        "text",
        "button",
        "image",
        "card",
      ]),
      name: z.string().max(150),
      text: z.string().max(10000).optional(),
      href: z
        .string()
        .max(2000)
        .refine(
          (v) => isSafeUrl(v),
          "Adresse non autorisée. Utilisez https://, / ou #.",
        )
        .optional(),
      src: z
        .string()
        .max(2000)
        .refine((v) => isSafeUrl(v, true), "Adresse d’image non autorisée.")
        .optional(),
      alt: z.string().max(500).optional(),
      locked: z.boolean().optional(),
      hidden: z.boolean().optional(),
      shared: z.boolean().optional(),
      role: z.string().max(40).optional(),
      styles: z
        .object({
          desktop: styleSchema.optional(),
          tablet: styleSchema.optional(),
          mobile: styleSchema.optional(),
        })
        .strict(),
      children: z.array(elementSchema).max(100),
      binding: z
        .object({
          source: z.literal("articles"),
          rowId: z.string().max(100),
          field: z.enum(["title", "category", "author", "date"]),
          fallback: z.string().max(1000),
        })
        .optional(),
      interaction: z
        .object({
          trigger: z.enum(["click", "hover"]),
          action: z.enum(["link", "toggle"]),
          target: z.string().max(2000),
        })
        .refine(
          (v) => v.action !== "link" || isSafeUrl(v.target),
          "Destination non autorisée.",
        )
        .optional(),
    })
    .strict(),
);
export const graphSchema = z
  .object({
    nodes: z
      .array(
        z
          .object({
            id: z.string().max(100),
            type: z.enum(["source", "field", "filter", "display"]),
            title: z.string().max(100),
            x: z.number().min(0).max(4000),
            y: z.number().min(0).max(4000),
            field: z.string().max(100),
            value: z.string().max(1000),
          })
          .strict(),
      )
      .max(100),
    edges: z
      .array(
        z
          .object({
            id: z.string().max(100),
            from: z.string().max(100),
            to: z.string().max(100),
          })
          .strict(),
      )
      .max(150),
  })
  .strict()
  .superRefine((g, ctx) => {
    const ids = new Set(g.nodes.map((n) => n.id));
    if (ids.size !== g.nodes.length)
      ctx.addIssue({
        code: "custom",
        message: "Identifiants de nœuds dupliqués.",
      });
    const ranks = { source: 0, field: 2, filter: 1, display: 3 };
    if (
      new Set(g.edges.map((e) => e.id)).size !== g.edges.length ||
      new Set(g.edges.map((e) => e.to)).size !== g.edges.length
    )
      ctx.addIssue({
        code: "custom",
        message:
          "Chaque connexion doit être unique et chaque entrée ne peut recevoir qu’une connexion.",
      });
    for (const e of g.edges) {
      const from = g.nodes.find((n) => n.id === e.from),
        to = g.nodes.find((n) => n.id === e.to);
      if (!from || !to || ranks[from.type] >= ranks[to.type])
        ctx.addIssue({
          code: "custom",
          message:
            "Connexion incompatible : reliez une source à un champ, un filtre ou un affichage.",
        });
    }
  });
export const documentSchema = z
  .object({
    version: z.literal(1),
    title: z.string().min(1).max(150),
    slug: z
      .string()
      .regex(/^\/[a-z0-9\-/]*$/)
      .max(200),
    theme: z
      .object({
        primary: safeColor,
        background: safeColor,
        font: z.enum(["Georgia", "Arial", "Inter"]),
      })
      .strict(),
    elements: z.array(elementSchema).max(100),
    graph: graphSchema,
    sheet: z
      .array(
        z
          .object({
            id: z.string().max(100),
            title: z.string().max(500),
            category: z.string().max(100),
            author: z.string().max(100),
            status: z.enum(["Publié", "Brouillon", "Masqué"]),
            date: z.string().max(30),
          })
          .strict(),
      )
      .max(500),
  })
  .strict()
  .superRefine((d, ctx) => {
    const all = flatten(d.elements);
    for (const el of all) {
      if (
        el.interaction?.action === "toggle" &&
        !all.some((e) => e.id === el.interaction?.target)
      )
        ctx.addIssue({
          code: "custom",
          message: `La cible de l’interaction « ${el.name} » n’existe plus. Choisissez une cible valide.`,
        });
    }
    if (all.length > 500)
      ctx.addIssue({
        code: "custom",
        message: "La page dépasse 500 éléments.",
      });
    if (new Set(all.map((e) => e.id)).size !== all.length)
      ctx.addIssue({
        code: "custom",
        message: "Identifiants d’éléments dupliqués.",
      });
    const depth = (nodes: PageElement[], n: number): number =>
      Math.max(n, ...nodes.map((e) => depth(e.children, n + 1)));
    if (depth(d.elements, 0) > 12)
      ctx.addIssue({
        code: "custom",
        message: "Imbrication maximale : 12 niveaux.",
      });
  });

export function flatten(elements: PageElement[]): PageElement[] {
  return elements.flatMap((e) => [e, ...flatten(e.children)]);
}
export function findElement(doc: PageDocument, id: string) {
  return flatten(doc.elements).find((e) => e.id === id);
}
export function updateElement(
  doc: PageDocument,
  id: string,
  patch: Partial<PageElement>,
): PageDocument {
  const walk = (els: PageElement[]): PageElement[] =>
    els.map((e) =>
      e.id === id ? { ...e, ...patch } : { ...e, children: walk(e.children) },
    );
  return { ...doc, elements: walk(doc.elements) };
}
export function removeElement(doc: PageDocument, id: string): PageDocument {
  const el = findElement(doc, id);
  if (el?.locked || el?.shared) return doc;
  const walk = (els: PageElement[]): PageElement[] =>
    els
      .filter((e) => e.id !== id)
      .map((e) => ({ ...e, children: walk(e.children) }));
  return { ...doc, elements: walk(doc.elements) };
}
export function cloneElement(el: PageElement): PageElement {
  return {
    ...structuredClone(el),
    id: crypto.randomUUID(),
    shared: false,
    locked: false,
    name: `${el.name} — copie`,
    children: el.children.map(cloneElement),
  };
}
export function insertAfter(
  doc: PageDocument,
  targetId: string,
  el: PageElement,
): PageDocument {
  let inserted = false;
  const walk = (els: PageElement[]): PageElement[] =>
    els.flatMap((e) => {
      const out = { ...e, children: walk(e.children) };
      if (e.id === targetId) {
        inserted = true;
        return [out, el];
      }
      return [out];
    });
  const elements = walk(doc.elements);
  return { ...doc, elements: inserted ? elements : [...elements, el] };
}
export function moveElement(
  doc: PageDocument,
  id: string,
  target: string,
): PageDocument {
  const el = findElement(doc, id);
  if (
    !el ||
    el.locked ||
    el.shared ||
    id === target ||
    flatten(el.children).some((e) => e.id === target)
  )
    return doc;
  return insertAfter(removeElement(doc, id), target, el);
}
export function resolveStyle(el: PageElement, device: Device): ElementStyle {
  return {
    ...el.styles.desktop,
    ...(device !== "desktop" ? el.styles.tablet : {}),
    ...(device === "mobile" ? el.styles.mobile : {}),
  };
}
export function resolveText(
  el: PageElement,
  doc: PageDocument,
  publishedOnly = false,
) {
  if (!el.binding) return el.text || "";
  const row = doc.sheet.find(
    (r) =>
      r.id === el.binding?.rowId && (!publishedOnly || r.status === "Publié"),
  );
  return row
    ? String(row[el.binding.field as keyof SheetRow] || el.binding.fallback)
    : el.binding.fallback;
}
export function diffDocuments(
  before: PageDocument | null,
  after: PageDocument,
) {
  if (!before)
    return [
      {
        name: "Nouvelle page",
        detail: `${flatten(after.elements).length} éléments à publier`,
      },
    ];
  const changes: { name: string; detail: string }[] = [];
  if (
    before.elements.map((e) => e.id).join("|") !==
    after.elements.map((e) => e.id).join("|")
  )
    changes.push({
      name: "Structure de la page",
      detail: "Ordre ou composition des sections modifié",
    });
  const a = flatten(before.elements),
    b = flatten(after.elements);
  for (const el of b) {
    const old = a.find((e) => e.id === el.id);
    if (!old) changes.push({ name: el.name, detail: "Élément ajouté" });
    else if (JSON.stringify(old) !== JSON.stringify(el)) {
      const fields = [];
      if (old.text !== el.text) fields.push("contenu");
      if (JSON.stringify(old.styles) !== JSON.stringify(el.styles))
        fields.push("style");
      if (old.href !== el.href) fields.push("lien");
      if (old.src !== el.src) fields.push("image");
      changes.push({
        name: el.name,
        detail: `Modification : ${fields.join(", ") || "structure ou propriétés"}`,
      });
    }
  }
  for (const el of a)
    if (!b.some((e) => e.id === el.id))
      changes.push({ name: el.name, detail: "Élément supprimé" });
  if (JSON.stringify(before.theme) !== JSON.stringify(after.theme))
    changes.push({
      name: "Identité visuelle",
      detail: "Styles de la page modifiés",
    });
  if (JSON.stringify(before.sheet) !== JSON.stringify(after.sheet))
    changes.push({
      name: "Tableur",
      detail: "Données de démonstration modifiées",
    });
  if (JSON.stringify(before.graph) !== JSON.stringify(after.graph))
    changes.push({ name: "Blueprint", detail: "Liaisons modifiées" });
  if (before.title !== after.title || before.slug !== after.slug)
    changes.push({ name: "Page", detail: "Nom ou adresse modifié" });
  return changes;
}
