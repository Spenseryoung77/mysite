import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";

const globalSecrets = globalThis as typeof globalThis & {
  __atelierSecret?: string;
};
const secret =
  process.env.ATELIER_SESSION_SECRET ||
  (globalSecrets.__atelierSecret ??= randomBytes(48).toString("hex"));
const sign = (value: string) =>
  createHmac("sha256", secret).update(value).digest("base64url");
export function seal(payload: Record<string, unknown>) {
  const value = Buffer.from(JSON.stringify(payload)).toString("base64url");
  return `${value}.${sign(value)}`;
}
export function unseal(token: string): Record<string, unknown> | null {
  try {
    const [value, signature] = token.split(".");
    const expected = sign(value);
    if (
      !signature ||
      signature.length !== expected.length ||
      !timingSafeEqual(Buffer.from(signature), Buffer.from(expected))
    )
      return null;
    const data = JSON.parse(Buffer.from(value, "base64url").toString());
    if (typeof data.exp !== "number" || data.exp < Date.now()) return null;
    return data;
  } catch {
    return null;
  }
}
export async function demoSession() {
  const jar = await cookies();
  const current = jar.get("atelier_demo_session")?.value;
  const session = current ? unseal(current) : null;
  if (session && typeof session.csrf === "string") return session.csrf;
  const csrf = randomBytes(24).toString("hex");
  jar.set(
    "atelier_demo_session",
    seal({ role: "demo-admin", csrf, exp: Date.now() + 86400000 }),
    {
      httpOnly: true,
      sameSite: "strict",
      secure:
        process.env.NODE_ENV === "production" &&
        process.env.ATELIER_SECURE_COOKIE === "true",
      path: "/",
      maxAge: 86400,
    },
  );
  return csrf;
}
export class ApiError extends Error {
  constructor(
    message: string,
    public status = 400,
  ) {
    super(message);
  }
}
export async function requireWrite(request: Request) {
  const origin = request.headers.get("origin");
  if (
    origin &&
    origin !== new URL(request.url).origin &&
    new URL(origin).host !== request.headers.get("x-forwarded-host") &&
    new URL(origin).host !== request.headers.get("host")
  )
    throw new ApiError("Origine de la requête refusée.", 403);
  const token = (await cookies()).get("atelier_demo_session")?.value;
  const session = token ? unseal(token) : null;
  if (!session || session.role !== "demo-admin")
    throw new ApiError(
      "Session de démonstration expirée. Rechargez l’Atelier.",
      401,
    );
  if (request.headers.get("x-atelier-csrf") !== session.csrf)
    throw new ApiError(
      "Vérification de sécurité invalide. Rechargez l’Atelier.",
      403,
    );
  const length = Number(request.headers.get("content-length") || 0);
  if (length > 1_500_000)
    throw new ApiError("Le document dépasse la taille autorisée.", 413);
}
export async function readBody(request: Request) {
  const text = await request.text();
  if (text.length > 1_500_000)
    throw new ApiError("Document trop volumineux.", 413);
  try {
    return JSON.parse(text);
  } catch {
    throw new ApiError("Le fichier JSON est illisible.");
  }
}
export function apiFailure(error: unknown) {
  if (error instanceof ApiError)
    return Response.json({ error: error.message }, { status: error.status });
  if (
    error &&
    typeof error === "object" &&
    (("code" in error && error.code === "23505") ||
      ("cause" in error &&
        error.cause &&
        typeof error.cause === "object" &&
        "code" in error.cause &&
        error.cause.code === "23505"))
  )
    return Response.json(
      { error: "Cette adresse est déjà utilisée par une autre page." },
      { status: 409 },
    );
  console.error("[Atelier]", error);
  return Response.json(
    {
      error:
        "Le stockage est indisponible. Votre travail reste dans l’éditeur ; exportez-le avant de recharger.",
    },
    { status: 503 },
  );
}
