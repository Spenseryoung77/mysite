import {
  pgTable,
  text,
  integer,
  boolean,
  jsonb,
  timestamp,
} from "drizzle-orm/pg-core";
import type { PageDocument } from "@/lib/atelier/model";

export const atelierPages = pgTable("atelier_demo_pages", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  kind: text("kind").notNull().default("page"),
  category: text("category").notNull().default("Pages publiques"),
  status: text("status").notNull().default("Brouillon"),
  compatible: boolean("compatible").notNull().default(true),
  draft: jsonb("draft").$type<PageDocument>().notNull(),
  published: jsonb("published").$type<PageDocument>(),
  revision: integer("revision").notNull().default(1),
  publishedRevision: integer("published_revision").notNull().default(0),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});
export const atelierVersions = pgTable("atelier_demo_versions", {
  id: text("id").primaryKey(),
  pageId: text("page_id")
    .notNull()
    .references(() => atelierPages.id, { onDelete: "cascade" }),
  revision: integer("revision").notNull(),
  document: jsonb("document").$type<PageDocument>().notNull(),
  label: text("label").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});
