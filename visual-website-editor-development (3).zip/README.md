# L’Atelier — Paroles Inspirées

Prototype autonome en français, à l’adresse `/admin/atelier` (également présenté à `/`). **Aucun raccordement au site réel.** Le faux site public se trouve à `/site/accueil`.

## Lancer

Prérequis : Node.js 20.9+ (22 recommandé), npm, PostgreSQL 14+ et une base **isolée**. Créer une variable `DATABASE_URL` dans `.env`, par exemple une connexion locale à une base dédiée. `ATELIER_SESSION_SECRET` est facultatif en démo : prévoir une longue valeur aléatoire et stable pour des sessions qui survivent au redémarrage. `ATELIER_SECURE_COOKIE=true` active les cookies Secure sur un hébergement HTTPS.

1. `npm install`
2. `npx drizzle-kit push` (uniquement sur la base de démonstration)
3. `npm run dev`
4. Ouvrir http://localhost:3000/admin/atelier

En production de démonstration : `npm run build` puis le gestionnaire d’exécution habituel. Les 12 pages fictives sont créées au premier accès par une transaction idempotente. Aucune page existante n’est écrasée. Les noms des tables sont préfixés `atelier_demo_`.

## Tests

- Unités : `npx tsx --test tests/model.test.ts`
- Navigateur : `npx playwright install --with-deps chromium`, démarrer l’application séparément, puis `npx playwright test`.
- Serveur distant de démo : `PLAYWRIGHT_BASE_URL=https://... npx playwright test`.
- Le scénario d’API utilise aussi la base de démo configurée dans `.env` pour nettoyer uniquement les pages dont l’adresse commence par `/test-`. **Ne jamais utiliser ces tests sur une base réelle.**
- Validation : `npx next typegen`, `npm exec tsc -- --noEmit --pretty false`, `npm run build`.

## Dossiers

- `src/components/atelier/` : interface React, rendu commun, tableur et blueprint.
- `src/lib/atelier/model.ts` : types, schéma Zod, commandes et comparaison.
- `src/lib/atelier/api.ts` : seul adaptateur HTTP du navigateur, remplaçable pour Flask.
- `src/lib/atelier/repository.ts` : stockage Drizzle, révisions et transactions.
- `src/lib/atelier/security.ts` : session publique d’administrateur de démo signée, contrôle d’origine et CSRF. **Pas une authentification de production.**
- `src/db/schema.ts` : tables PostgreSQL isolées.
- `src/app/api/atelier/` : API proposée ; pas une API existante du site Flask.
- `public/documentation-atelier.md` : schéma, contrat, lot de 20 et limites.
- `docs/INTEGRATION-FLASK.md` : procédure d’intégration et exigences de sécurité.
- `tests/` : tests de modèle, de sécurité de démo, de publication et d’interface.

Les variables de couleur de l’interface sont réunies au début de `globals.css`. Les classes du moteur de page sont préfixées `page-`, `pe-` et `role-`, distinctes des classes de l’interface.

## Dépendances et droits

Next.js 16, React 19, pg 8, Zod 4, tsx 4 : MIT ; Drizzle ORM 0.45, drizzle-kit 0.31, TypeScript 5 et Playwright : Apache-2.0 ; Lucide React : ISC ; Tailwind CSS 4 : MIT ; dotenv : BSD-2-Clause ; Prettier : MIT. Versions résolues exactes dans `package-lock.json`. Inter : SIL Open Font License 1.1 (paquet Fontsource MIT). Les licences intégrales des dépendances sont dans leurs paquets npm.

Photographies locales Pexels : Quang Nguyen Vinh (11334345), Nothing Ahead (4567409), RAY LEI (13865966). Licence Pexels, distincte de la licence du code : https://www.pexels.com/license/. Aucune photo ni donnée de production n’est utilisée.

## Livrable

L’aide de l’Atelier propose la documentation et l’archive `/atelier-source.zip`. L’archive exclut `.env`, `node_modules`, `.next`, les journaux et la base. Elle ne constitue donc **pas** une sauvegarde complète des données. Sauvegarder PostgreSQL et les médias séparément, et tester leur restauration dans une base isolée.

## Audit de dépendances

Audit npm réalisé dans ce sandbox : 13 avis modérés, aucun avis élevé ni critique. Les avis concernent Drizzle Kit / esbuild et la chaîne ESLint / TypeScript-ESLint. Les correctifs suggérés impliquent notamment des changements de versions majeures ; aucun `audit fix --force` automatique n’a été appliqué. Réexaminer ces avis, figer les versions et retirer les outils de développement du runtime lors de l’intégration.
