// Logique métier pure de l'Atelier (sans DOM, sans réseau).
// Testable avec node : voir tests/model.test.mjs.

export const DEVICE_WIDTHS = { desktop: 1200, tablet: 768, mobile: 390 };
export const DEVICE_LABELS = {
  desktop: "Ordinateur",
  tablet: "Tablette",
  mobile: "Mobile",
};

export const KIND_LABELS = {
  header: "En-tête",
  footer: "Pied de page",
  section: "Section",
  container: "Conteneur",
  heading: "Titre",
  text: "Texte",
  button: "Bouton",
  image: "Image",
  card: "Carte",
};

// Même règle que le serveur : https://, chemin relatif (/) ou ancre (#).
export function isSafeUrl(value) {
  if (typeof value !== "string" || value.length > 2000) return false;
  const v = value.trim().toLowerCase();
  if ((v.startsWith("/") || v.startsWith("#")) && !v.startsWith("//")) return true;
  return v.startsWith("https://");
}

// Parcourt l'arbre en profondeur ; fn(el, parentList, index) ; arrêt si fn renvoie true.
export function walk(elements, fn) {
  for (let i = 0; i < elements.length; i++) {
    if (fn(elements[i], elements, i)) return true;
    if (walk(elements[i].children || [], fn)) return true;
  }
  return false;
}

export function findElement(doc, id) {
  let found = null;
  walk(doc.elements, (el) => {
    if (el.id === id) {
      found = el;
      return true;
    }
    return false;
  });
  return found;
}

export function countElements(doc) {
  let n = 0;
  walk(doc.elements, () => {
    n += 1;
    return false;
  });
  return n;
}

// Copie immuable du document avec une modification d'élément.
// Les champs non autorisés sont ignorés ; une URL non sûre lève une erreur.
const EDITABLE_FIELDS = ["text", "href", "alt", "name", "hidden"];

export function updateElement(doc, id, patch) {
  for (const key of Object.keys(patch)) {
    if (!EDITABLE_FIELDS.includes(key)) throw new Error(`Champ non modifiable : ${key}`);
  }
  if ("href" in patch && patch.href !== "" && !isSafeUrl(patch.href)) {
    throw new Error("Adresse non autorisée. Utilisez https://, / ou #.");
  }
  const next = structuredClone(doc);
  const target = findElement(next, id);
  if (!target) throw new Error("Élément introuvable.");
  if (target.locked) throw new Error("Cet élément est verrouillé.");
  for (const [key, value] of Object.entries(patch)) {
    if (value === "" || value === undefined) delete target[key];
    else target[key] = value;
  }
  return next;
}

export function isDirty(savedDoc, currentDoc) {
  return JSON.stringify(savedDoc) !== JSON.stringify(currentDoc);
}

// Résumé des changements entre la version publiée et le brouillon (comparaison par identifiant).
export function summarizeChanges(publishedDoc, draftDoc) {
  const before = new Map();
  const after = new Map();
  walk(publishedDoc ? publishedDoc.elements : [], (el) => {
    before.set(el.id, JSON.stringify(stripChildren(el)));
    return false;
  });
  walk(draftDoc.elements, (el) => {
    after.set(el.id, JSON.stringify(stripChildren(el)));
    return false;
  });
  let added = 0, removed = 0, changed = 0;
  for (const [id, value] of after) {
    if (!before.has(id)) added += 1;
    else if (before.get(id) !== value) changed += 1;
  }
  for (const id of before.keys()) if (!after.has(id)) removed += 1;
  return { added, removed, changed, titleChanged: !publishedDoc || publishedDoc.title !== draftDoc.title };
}

function stripChildren(el) {
  const { children, ...rest } = el;
  return rest;
}

export function hasChanges(summary) {
  return summary.added + summary.removed + summary.changed > 0 || summary.titleChanged;
}

// Messages d'erreur serveur affichés tels quels (déjà en français).
export function describeError(err) {
  if (err && err.status === 0) {
    return "Réponse réseau perdue : vérifiez l’état de la page avant de recommencer.";
  }
  return (err && err.message) || "Erreur inconnue.";
}
