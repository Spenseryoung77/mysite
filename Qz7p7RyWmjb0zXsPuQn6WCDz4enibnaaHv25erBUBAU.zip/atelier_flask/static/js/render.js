// Rendu de la planche (interface). Toutes les valeurs passent par textContent /
// setAttribute : aucun HTML issu des données n'est injecté.

import { isSafeUrl, DEVICE_WIDTHS, KIND_LABELS } from "./model.js";

const TAGS = {
  header: "header",
  footer: "footer",
  section: "section",
  container: "div",
  heading: "h2",
  text: "p",
  button: "a",
  image: "img",
  card: "article",
};

function renderElement(el, device, selectedId, onSelect) {
  if (el.hidden) return null;
  const node = document.createElement(TAGS[el.kind] || "div");
  node.className = `page-element pe-${el.kind}${el.role ? ` role-${el.role}` : ""} is-editable`;
  node.dataset.id = el.id;
  node.dataset.kind = el.kind;
  if (el.id === selectedId) node.classList.add("element-selected", "element-editing");
  if (el.shared) node.classList.add("shared-layer");
  node.setAttribute("aria-label", el.name || KIND_LABELS[el.kind]);

  if (el.kind === "image") {
    if (el.src && isSafeUrl(el.src)) node.setAttribute("src", el.src);
    node.setAttribute("alt", el.alt || "");
  } else if (el.text) {
    node.textContent = el.text;
  }
  if (el.kind === "button" && el.href && isSafeUrl(el.href)) {
    node.setAttribute("href", el.href);
  }
  if (el.kind === "button") node.setAttribute("role", "button");

  node.addEventListener("click", (event) => {
    // Un clic sur la planche sélectionne l'élément, sans suivre le lien.
    event.preventDefault();
    event.stopPropagation();
    onSelect(el.id);
  });

  for (const child of el.children || []) {
    const childNode = renderElement(child, device, selectedId, onSelect);
    if (childNode) node.appendChild(childNode);
  }
  return node;
}

export function renderArtboard(container, doc, { device, selectedId, onSelect, pageLabel, isHome }) {
  const width = DEVICE_WIDTHS[device];
  container.replaceChildren();
  container.style.width = `${width}px`;

  const caption = document.createElement("div");
  caption.className = "artboard-caption";
  const left = document.createElement("span");
  left.textContent = isHome ? "PAGE D’ACCUEIL" : pageLabel.toUpperCase();
  const right = document.createElement("span");
  right.textContent = `${width} px`;
  caption.append(left, right);

  const inner = document.createElement("div");
  inner.className = "artboard-inner page-document";
  inner.style.setProperty("--site-primary", doc.theme.primary);
  inner.style.setProperty("--site-bg", doc.theme.background);
  inner.style.setProperty("--site-font", doc.theme.font);
  inner.style.background = doc.theme.background;
  inner.style.fontFamily = doc.theme.font;
  inner.addEventListener("click", () => onSelect(null));

  for (const el of doc.elements) {
    const node = renderElement(el, device, selectedId, onSelect);
    if (node) inner.appendChild(node);
  }
  if (!inner.childElementCount) {
    const empty = document.createElement("p");
    empty.className = "empty-document";
    empty.textContent = "Cette page ne contient encore aucun élément.";
    inner.appendChild(empty);
  }

  const wrap = document.createElement("div");
  wrap.className = "artboard-outer";
  wrap.appendChild(inner);
  container.append(caption, wrap);
}
