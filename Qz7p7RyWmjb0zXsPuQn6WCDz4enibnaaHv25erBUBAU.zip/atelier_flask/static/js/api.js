// Appels serveur de l'Atelier. Aucune logique d'interface ici.

export class ApiError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

const BASE = "/api/atelier";

async function request(method, path, { body, csrf } = {}) {
  const headers = {};
  if (body !== undefined) headers["Content-Type"] = "application/json";
  if (csrf) headers["x-atelier-csrf"] = csrf;
  let response;
  try {
    response = await fetch(path, {
      method,
      headers,
      credentials: "same-origin",
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    // Réseau coupé : on ne sait pas si l'écriture a abouti.
    throw new ApiError(0, "Réponse réseau perdue.");
  }
  let data = null;
  try {
    data = await response.json();
  } catch {
    if (!response.ok) throw new ApiError(response.status, "Réponse serveur illisible.");
    throw new ApiError(0, "Réponse serveur illisible.");
  }
  if (!response.ok) {
    throw new ApiError(response.status, (data && data.error) || "Erreur serveur.");
  }
  return data;
}

export const atelierApi = {
  list: () => request("GET", BASE),
  get: (id) => request("GET", `${BASE}/${encodeURIComponent(id)}`),
  saveDraft: (id, { expectedRevision, document }, csrf) =>
    request("PUT", `${BASE}/${encodeURIComponent(id)}`, {
      body: { expectedRevision, document },
      csrf,
    }),
  review: (id, csrf) =>
    request("POST", `${BASE}/${encodeURIComponent(id)}`, {
      body: { action: "review" },
      csrf,
    }),
  publish: (id, token, csrf) =>
    request("POST", `${BASE}/${encodeURIComponent(id)}`, {
      body: { action: "publish", token, confirmed: true },
      csrf,
    }),
};
