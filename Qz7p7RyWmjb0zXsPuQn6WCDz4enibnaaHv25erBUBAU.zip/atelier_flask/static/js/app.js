// Contrôleur de l'interface : relie la planche, l'inspecteur, la liste des pages
// et les appels serveur. La logique métier est dans model.js.

import { atelierApi } from "./api.js";
import {
  DEVICE_LABELS,
  DEVICE_WIDTHS,
  KIND_LABELS,
  countElements,
  describeError,
  findElement,
  hasChanges,
  isDirty,
  isSafeUrl,
  summarizeChanges,
  updateElement,
} from "./model.js";
import { renderArtboard } from "./render.js";

const $ = (sel) => document.querySelector(sel);

const state = {
  pages: [],
  csrf: null,
  current: null, // { id, title, slug, revision, publishedRevision, published, draft }
  doc: null, // brouillon en cours d'édition
  saved: null, // dernier brouillon enregistré
  selectedId: null,
  device: "desktop",
  busy: false,
  filter: "",
};

// ---------------------------------------------------------------- utilitaires

function toast(message, kind = "info") {
  const box = $("#toasts");
  const item = document.createElement("div");
  item.className = `toast${kind === "error" ? " toast-error" : ""}`;
  item.setAttribute("role", kind === "error" ? "alert" : "status");
  item.textContent = message;
  box.appendChild(item);
  setTimeout(() => item.remove(), 5000);
}

function setBusy(on) {
  state.busy = on;
  refreshControls();
}

function currentDirty() {
  return !!state.doc && isDirty(state.saved, state.doc);
}

function setSaveStatus() {
  const el = $("#save-status");
  if (!state.current) {
    el.textContent = "";
    return;
  }
  el.className = "save-status";
  if (state.busy) {
    el.classList.add("save-saving");
    el.textContent = "Enregistrement…";
  } else if (currentDirty()) {
    el.classList.add("save-unsaved");
    el.textContent = "Modifications non enregistrées";
  } else {
    el.textContent = "Tout est enregistré";
  }
}

function refreshControls() {
  const hasPage = !!state.current;
  const dirty = currentDirty();
  $("#btn-save").disabled = !hasPage || !dirty || state.busy;
  const alreadyPublished = hasPage && state.current.publishedRevision === state.current.revision;
  $("#btn-review").disabled = !hasPage || dirty || state.busy || alreadyPublished;
  $("#btn-preview").disabled = !hasPage;
  document.querySelectorAll("[data-device]").forEach((b) => {
    b.classList.toggle("active", b.dataset.device === state.device);
    b.setAttribute("aria-pressed", String(b.dataset.device === state.device));
  });
  setSaveStatus();
  renderSidebar();
}

// ------------------------------------------------------------------ rendu

function renderSidebar() {
  const list = $("#page-list");
  list.replaceChildren();
  const query = state.filter.trim().toLowerCase();
  const pages = state.pages.filter(
    (p) => !query || p.title.toLowerCase().includes(query) || p.slug.toLowerCase().includes(query),
  );
  if (!pages.length) {
    const empty = document.createElement("p");
    empty.className = "empty-small";
    empty.textContent = "Aucune page ne correspond à la recherche.";
    list.appendChild(empty);
    return;
  }
  for (const page of pages) {
    const item = document.createElement("button");
    item.type = "button";
    item.className = `page-list-item${state.current && state.current.id === page.id ? " page-item-current" : ""}`;
    item.dataset.id = page.id;
    const dot = document.createElement("span");
    dot.className = `page-status-dot dot-${page.status === "Publié" ? "publi" : page.status === "Brouillon" ? "brouillon" : "masqu"}`;
    const title = document.createElement("strong");
    title.textContent = page.title;
    const slug = document.createElement("small");
    slug.textContent = `${page.slug} · ${page.status}${page.compatible ? "" : " · non compatible"}`;
    item.append(dot, title, slug);
    item.addEventListener("click", () => openPage(page.id));
    list.appendChild(item);
  }
}

function renderCanvas() {
  const artboard = $("#artboard");
  if (!state.current || !state.doc) {
    artboard.replaceChildren();
    const empty = document.createElement("p");
    empty.className = "empty-document";
    empty.textContent = "Choisissez une page dans la liste de gauche.";
    artboard.appendChild(empty);
    return;
  }
  renderArtboard(artboard, state.doc, {
    device: state.device,
    selectedId: state.selectedId,
    onSelect: selectElement,
    pageLabel: state.current.title,
    isHome: state.current.slug === "/",
  });
  $("#status-count").textContent = `${countElements(state.doc)} éléments`;
  $("#status-device").textContent = `${DEVICE_LABELS[state.device]} · ${DEVICE_WIDTHS[state.device]} px`;
}

function renderInspector() {
  const panel = $("#inspector-body");
  panel.replaceChildren();
  const el = state.doc && state.selectedId ? findElement(state.doc, state.selectedId) : null;
  $("#inspector-title").textContent = el ? `${KIND_LABELS[el.kind]} · ${el.name || el.id}` : "Inspecteur";
  if (!el) {
    const p = document.createElement("p");
    p.className = "inspector-empty";
    p.textContent = state.current
      ? "Cliquez sur un élément de la planche pour le modifier."
      : "Aucune page ouverte.";
    panel.appendChild(p);
    return;
  }
  const form = document.createElement("form");
  form.className = "inspector-fieldset";
  form.addEventListener("submit", (e) => e.preventDefault());
  if (el.locked) {
    const note = document.createElement("p");
    note.className = "locked-warning";
    note.textContent = "Élément verrouillé : modification impossible.";
    form.appendChild(note);
  }
  if (el.kind !== "image") {
    addField(form, "Texte", "text", el.text || "", el.locked, true);
  }
  if (el.kind === "button" || el.href !== undefined) {
    addField(form, "Lien (https://, / ou #)", "href", el.href || "", el.locked, false);
  }
  if (el.kind === "image") {
    addField(form, "Texte alternatif", "alt", el.alt || "", el.locked, false);
  }
  panel.appendChild(form);
}

function addField(form, label, key, value, disabled, multiline) {
  const wrap = document.createElement("label");
  wrap.className = "property-row";
  const span = document.createElement("span");
  span.className = "field-label";
  span.textContent = label;
  const input = document.createElement(multiline ? "textarea" : "input");
  if (!multiline) input.type = "text";
  input.value = value;
  input.disabled = !!disabled;
  input.dataset.field = key;
  input.setAttribute("aria-label", label);
  const hint = document.createElement("small");
  hint.className = "field-error";
  hint.setAttribute("role", "alert");
  input.addEventListener("input", () => {
    const next = input.value;
    if (key === "href" && next !== "" && !isSafeUrl(next)) {
      hint.textContent = "Adresse non autorisée. Utilisez https://, / ou #.";
      input.setAttribute("aria-invalid", "true");
      return;
    }
    hint.textContent = "";
    input.removeAttribute("aria-invalid");
    try {
      state.doc = updateElement(state.doc, state.selectedId, { [key]: next });
      renderCanvas();
      refreshControls();
    } catch (err) {
      hint.textContent = describeError(err);
    }
  });
  wrap.append(span, input, hint);
  form.appendChild(wrap);
}

function renderPageHeader() {
  const title = $("#page-title");
  title.textContent = state.current ? state.current.title : "Aucune page";
  $("#page-slug").textContent = state.current ? state.current.slug : "";
  const badge = $("#draft-badge");
  badge.hidden = !state.current;
}

function renderAll() {
  renderPageHeader();
  renderCanvas();
  renderInspector();
  refreshControls();
}

// ------------------------------------------------------------ actions

function selectElement(id) {
  state.selectedId = id;
  renderCanvas();
  renderInspector();
}

async function loadPages() {
  const data = await atelierApi.list();
  state.pages = data.pages;
  state.csrf = data.csrf;
  renderSidebar();
}

async function openPage(id) {
  if (currentDirty() && !confirm("Des modifications ne sont pas enregistrées. Changer de page ?")) return;
  setBusy(true);
  try {
    const page = await atelierApi.get(id);
    state.current = page;
    state.doc = structuredClone(page.draft);
    state.saved = structuredClone(page.draft);
    state.selectedId = null;
    history.replaceState(null, "", `#${page.id}`);
    renderAll();
  } catch (err) {
    toast(describeError(err), "error");
  } finally {
    setBusy(false);
  }
}

async function saveDraft() {
  if (!currentDirty()) return;
  setBusy(true);
  try {
    const page = await atelierApi.saveDraft(
      state.current.id,
      { expectedRevision: state.current.revision, document: state.doc },
      state.csrf,
    );
    state.current = { ...state.current, ...page };
    state.saved = structuredClone(state.doc);
    toast("Brouillon enregistré.");
  } catch (err) {
    if (err.status === 409) {
      toast("Cette page a été modifiée ailleurs. Rechargez avant d’enregistrer.", "error");
    } else {
      toast(describeError(err), "error");
    }
  } finally {
    setBusy(false);
  }
}

function openPreview() {
  const dialog = $("#preview-dialog");
  const host = $("#preview-host");
  renderArtboard(host, state.doc, {
    device: state.device,
    selectedId: null,
    onSelect: () => {},
    pageLabel: state.current.title,
    isHome: state.current.slug === "/",
  });
  $("#preview-device").textContent = `${DEVICE_LABELS[state.device]} · ${DEVICE_WIDTHS[state.device]} px`;
  dialog.showModal();
}

async function openReview() {
  if (currentDirty()) return;
  setBusy(true);
  try {
    const review = await atelierApi.review(state.current.id, state.csrf);
    const summary = summarizeChanges(state.current.published, state.doc);
    const changed = hasChanges(summary);
    const list = $("#review-summary");
    list.replaceChildren();
    const lines = [
      `Révision à publier : ${review.revision}`,
      `Éléments ajoutés : ${summary.added}`,
      `Éléments modifiés : ${summary.changed}`,
      `Éléments supprimés : ${summary.removed}`,
      summary.titleChanged ? "Titre modifié" : "Titre inchangé",
    ];
    for (const line of lines) {
      const li = document.createElement("li");
      li.textContent = line;
      list.appendChild(li);
    }
    const confirmBox = $("#publish-confirm");
    confirmBox.checked = false;
    $("#publish-submit").disabled = true;
    $("#publish-submit").dataset.token = review.token;
    $("#publish-note").textContent = changed
      ? "La publication remplace la version visible du site."
      : "Aucune différence avec la version publiée. Publier quand même ?";
    $("#publish-dialog").showModal();
  } catch (err) {
    toast(describeError(err), "error");
  } finally {
    setBusy(false);
  }
}

async function publish() {
  const token = $("#publish-submit").dataset.token;
  setBusy(true);
  try {
    const page = await atelierApi.publish(state.current.id, token, state.csrf);
    state.current = { ...state.current, ...page };
    $("#publish-dialog").close();
    toast(`Page publiée (révision ${page.publishedRevision}).`);
    await loadPages();
    renderAll();
  } catch (err) {
    $("#publish-dialog").close();
    toast(describeError(err), "error");
  } finally {
    setBusy(false);
  }
}

// ------------------------------------------------------------ démarrage

function bindEvents() {
  $("#btn-save").addEventListener("click", saveDraft);
  $("#btn-review").addEventListener("click", openReview);
  $("#btn-preview").addEventListener("click", openPreview);
  $("#publish-confirm").addEventListener("change", (e) => {
    $("#publish-submit").disabled = !e.target.checked;
  });
  $("#publish-submit").addEventListener("click", publish);
  $("#publish-cancel").addEventListener("click", () => $("#publish-dialog").close());
  $("#preview-close").addEventListener("click", () => $("#preview-dialog").close());
  document.querySelectorAll("[data-device]").forEach((b) =>
    b.addEventListener("click", () => {
      state.device = b.dataset.device;
      renderCanvas();
      refreshControls();
    }),
  );
  $("#page-search").addEventListener("input", (e) => {
    state.filter = e.target.value;
    renderSidebar();
  });
  window.addEventListener("beforeunload", (e) => {
    if (currentDirty()) {
      e.preventDefault();
      e.returnValue = "";
    }
  });
  document.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") {
      e.preventDefault();
      saveDraft();
    }
  });
}

async function start() {
  bindEvents();
  try {
    await loadPages();
    const wanted = location.hash.slice(1);
    const first = state.pages.find((p) => p.id === wanted) || state.pages[0];
    if (first) await openPage(first.id);
    else renderAll();
  } catch (err) {
    toast(describeError(err), "error");
  }
}

start();
