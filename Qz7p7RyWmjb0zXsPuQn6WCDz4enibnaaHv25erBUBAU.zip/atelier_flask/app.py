"""Serveur Flask de la démo Atelier (données fictives uniquement).

Implémente le contrat décrit dans docs/INTEGRATION-FLASK.md :
GET/POST /api/atelier, GET/PUT/POST /api/atelier/<id>, et les actions
review / publish / restore / delete. Les erreurs sont en JSON avec un
message en français.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

import psycopg
from psycopg.rows import dict_row
from flask import Flask, g, jsonify, make_response, render_template, request

BASE_DIR = Path(__file__).resolve().parent
SEED_PATH = BASE_DIR / "seed.json"
MAX_BODY_BYTES = 1_500_000
TOKEN_TTL_SECONDS = 600
SESSION_COOKIE = "atelier_demo_session"
SESSION_TTL_SECONDS = 8 * 3600

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_BODY_BYTES

DATABASE_URL = os.environ.get(
    "ATELIER_DATABASE_URL", "postgresql://demo@localhost/demo_flask"
)
SECRET = os.environ.get("ATELIER_SECRET") or secrets.token_hex(32)

SCHEMA = """
CREATE TABLE IF NOT EXISTS atelier_demo_pages (
  id text PRIMARY KEY,
  title text NOT NULL,
  slug text NOT NULL UNIQUE,
  kind text NOT NULL,
  category text NOT NULL,
  status text NOT NULL,
  compatible boolean NOT NULL DEFAULT true,
  revision integer NOT NULL DEFAULT 1,
  published_revision integer NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now(),
  draft jsonb NOT NULL,
  published jsonb
);
CREATE TABLE IF NOT EXISTS atelier_demo_versions (
  id text PRIMARY KEY,
  page_id text NOT NULL REFERENCES atelier_demo_pages(id) ON DELETE CASCADE,
  revision integer NOT NULL,
  document jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
"""


# ---------------------------------------------------------------- utilitaires

class ApiError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


def db():
    if "db" not in g:
        g.db = psycopg.connect(DATABASE_URL, row_factory=dict_row, autocommit=False)
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def sign(payload: str) -> str:
    return hmac.new(SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()


def seal(data: dict) -> str:
    body = json.dumps(data, sort_keys=True, separators=(",", ":"))
    return f"{body}.{sign(body)}"


def unseal(token: str) -> dict | None:
    if not token or "." not in token:
        return None
    body, _, mac = token.rpartition(".")
    if not hmac.compare_digest(mac, sign(body)):
        return None
    try:
        return json.loads(body)
    except json.JSONDecodeError:
        return None


def doc_hash(document: dict) -> str:
    raw = json.dumps(document, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode()).hexdigest()


def new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:12]}"


def require_session() -> dict:
    """Session de démo : cookie HttpOnly signé, expiration contrôlée."""
    session = unseal(request.cookies.get(SESSION_COOKIE, ""))
    if not session or session.get("exp", 0) < time.time():
        raise ApiError(401, "Session de démo expirée. Rechargez la page.")
    return session


def require_write() -> dict:
    """Écritures : origine vérifiée, session, CSRF et taille du corps."""
    origin = request.headers.get("Origin")
    if origin and origin.rstrip("/") != request.host_url.rstrip("/"):
        raise ApiError(403, "Origine refusée.")
    session = require_session()
    if not secrets.compare_digest(
        request.headers.get("x-atelier-csrf", ""), session["csrf"]
    ):
        raise ApiError(403, "Jeton CSRF invalide.")
    if request.content_length and request.content_length > MAX_BODY_BYTES:
        raise ApiError(413, "Contenu trop volumineux.")
    return session


def read_body() -> dict:
    raw = request.get_data(cache=False)
    if len(raw) > MAX_BODY_BYTES:
        raise ApiError(413, "Contenu trop volumineux.")
    try:
        data = json.loads(raw or b"{}")
    except json.JSONDecodeError:
        raise ApiError(400, "Corps JSON invalide.")
    if not isinstance(data, dict):
        raise ApiError(400, "Le corps doit être un objet JSON.")
    return data


@app.errorhandler(ApiError)
def handle_api_error(err: ApiError):
    return jsonify(error=err.message), err.status


@app.errorhandler(413)
def handle_too_large(_err):
    return jsonify(error="Contenu trop volumineux."), 413


@app.errorhandler(psycopg.Error)
def handle_db_error(_err):
    return jsonify(error="Stockage indisponible. Réessayez plus tard."), 503


# ------------------------------------------------------------ validation

ALLOWED_KINDS = {"header", "footer", "section", "container", "heading",
                 "text", "button", "image", "card"}


def validate_document(document) -> dict:
    """Contrôle structurel minimal ; le schéma complet reste à porter."""
    if not isinstance(document, dict):
        raise ApiError(400, "Le document doit être un objet.")
    if document.get("version") != 1:
        raise ApiError(400, "Version de document non prise en charge.")
    title = document.get("title")
    if not isinstance(title, str) or not 1 <= len(title) <= 150:
        raise ApiError(400, "Titre de page invalide.")
    elements = document.get("elements")
    if not isinstance(elements, list) or len(elements) > 100:
        raise ApiError(400, "Liste d'éléments invalide.")
    if len(json.dumps(document)) > MAX_BODY_BYTES:
        raise ApiError(413, "Contenu trop volumineux.")
    _check_elements(elements, depth=0)
    return document


def _check_elements(items: list, depth: int) -> None:
    if depth > 12:
        raise ApiError(400, "Imbrication d'éléments trop profonde.")
    for el in items:
        if not isinstance(el, dict):
            raise ApiError(400, "Élément invalide.")
        if el.get("kind") not in ALLOWED_KINDS:
            raise ApiError(400, "Type d'élément non autorisé.")
        for key in ("href", "src"):
            value = el.get(key)
            if value is not None and not is_safe_url(value, allow_image=key == "src"):
                raise ApiError(400, "Adresse non autorisée. Utilisez https://, / ou #.")
        children = el.get("children", [])
        if not isinstance(children, list) or len(children) > 100:
            raise ApiError(400, "Enfants d'élément invalides.")
        _check_elements(children, depth + 1)


def is_safe_url(value: str, allow_image: bool = False) -> bool:
    if not isinstance(value, str) or len(value) > 2000:
        return False
    v = value.strip().lower()
    if v.startswith(("/", "#")) and not v.startswith("//"):
        return True
    if v.startswith("https://"):
        return True
    return False  # médias non persistés dans la démo ; data: refusé


def check_slug(slug) -> str:
    import re
    if not isinstance(slug, str) or len(slug) > 200 or not re.fullmatch(r"/[a-z0-9\-/]*", slug):
        raise ApiError(400, "Adresse de page invalide.")
    return slug


# ------------------------------------------------------------- présentation

def page_summary(row: dict) -> dict:
    return {
        "id": row["id"],
        "title": row["title"],
        "slug": row["slug"],
        "kind": row["kind"],
        "category": row["category"],
        "status": row["status"],
        "compatible": row["compatible"],
        "revision": row["revision"],
        "publishedRevision": row["published_revision"],
        "updatedAt": row["updated_at"].isoformat(),
    }


def page_detail(row: dict) -> dict:
    data = page_summary(row)
    data["draft"] = row["draft"]
    data["published"] = row["published"]
    return data


def get_page_row(page_id: str, lock: bool = False) -> dict:
    sql = "SELECT * FROM atelier_demo_pages WHERE id = %s"
    if lock:
        sql += " FOR UPDATE"
    row = db().execute(sql, (page_id,)).fetchone()
    if row is None:
        raise ApiError(404, "Page introuvable.")
    return row


# ------------------------------------------------------------- démarrage

def seed_if_empty() -> None:
    conn = db()
    conn.execute(SCHEMA)
    count = conn.execute("SELECT count(*) AS n FROM atelier_demo_pages").fetchone()["n"]
    if count == 0 and SEED_PATH.exists():
        for page in json.loads(SEED_PATH.read_text(encoding="utf-8")):
            conn.execute(
                """INSERT INTO atelier_demo_pages
                   (id, title, slug, kind, category, status, compatible,
                    revision, published_revision, updated_at, draft, published)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                (page["id"], page["title"], page["slug"], page["kind"],
                 page["category"], page["status"], page["compatible"],
                 page["revision"], page["publishedRevision"], page["updatedAt"],
                 json.dumps(page["document"]),
                 json.dumps(page["document"]) if page["publishedRevision"] else None),
            )
            if page["publishedRevision"]:
                conn.execute(
                    """INSERT INTO atelier_demo_versions (id, page_id, revision, document)
                       VALUES (%s,%s,1,%s)""",
                    (new_id("ver"), page["id"], json.dumps(page["document"])),
                )
    conn.commit()


with app.app_context():
    try:
        seed_if_empty()
    except psycopg.Error as exc:  # le serveur démarre, les routes répondront 503
        app.logger.error("Stockage indisponible au démarrage : %s", exc)


# ------------------------------------------------------------------ routes

@app.get("/admin/atelier")
def atelier_page():
    return render_template("atelier.html")


@app.get("/api/atelier")
def list_pages():
    session = unseal(request.cookies.get(SESSION_COOKIE, ""))
    resp_session = session
    if not session or session.get("exp", 0) < time.time():
        resp_session = {"csrf": secrets.token_urlsafe(24),
                        "exp": int(time.time()) + SESSION_TTL_SECONDS}
    rows = db().execute(
        "SELECT * FROM atelier_demo_pages ORDER BY updated_at DESC, id"
    ).fetchall()
    body = {
        "pages": [page_summary(r) for r in rows],
        "csrf": resp_session["csrf"],
        "environment": "demo",
        "role": "demo",
    }
    resp = make_response(jsonify(body))
    if resp_session is not session:
        resp.set_cookie(SESSION_COOKIE, seal(resp_session), httponly=True,
                        samesite="Lax", secure=request.is_secure,
                        max_age=SESSION_TTL_SECONDS)
    return resp


@app.post("/api/atelier")
def create_page():
    require_write()
    data = read_body()
    title = data.get("title")
    if not isinstance(title, str) or not 1 <= len(title.strip()) <= 150:
        raise ApiError(400, "Titre requis (150 caractères maximum).")
    slug = check_slug(data.get("slug"))
    conn = db()
    if conn.execute("SELECT 1 FROM atelier_demo_pages WHERE slug = %s", (slug,)).fetchone():
        raise ApiError(409, "Cette adresse existe déjà.")
    source = None
    if data.get("sourceId") and not data.get("blank"):
        source = get_page_row(str(data["sourceId"]))["draft"]
    document = validate_document(source or {
        "version": 1, "title": title.strip(), "slug": slug,
        "theme": {"primary": "#1d4ed8", "background": "#ffffff", "font": "Georgia"},
        "elements": [], "graph": {"nodes": [], "edges": []}, "sheet": [],
    })
    document = {**document, "title": title.strip(), "slug": slug}
    page_id = new_id("page")
    conn.execute(
        """INSERT INTO atelier_demo_pages
           (id, title, slug, kind, category, status, compatible, revision,
            published_revision, updated_at, draft, published)
           VALUES (%s,%s,%s,'page','Pages','Brouillon',true,1,0,now(),%s,NULL)""",
        (page_id, title.strip(), slug, json.dumps(document)),
    )
    conn.commit()
    return jsonify(page_detail(get_page_row(page_id))), 201


@app.get("/api/atelier/<page_id>")
def get_page(page_id: str):
    row = get_page_row(page_id)
    if request.args.get("mode") == "versions":
        versions = db().execute(
            """SELECT id, revision, document, created_at FROM atelier_demo_versions
               WHERE page_id = %s ORDER BY revision DESC""", (page_id,)
        ).fetchall()
        return jsonify(versions=[{
            "id": v["id"], "revision": v["revision"], "document": v["document"],
            "createdAt": v["created_at"].isoformat(),
        } for v in versions])
    return jsonify(page_detail(row))


@app.put("/api/atelier/<page_id>")
def save_draft(page_id: str):
    require_write()
    data = read_body()
    expected = data.get("expectedRevision")
    if not isinstance(expected, int):
        raise ApiError(400, "Révision attendue requise.")
    document = validate_document(data.get("document"))
    conn = db()
    row = get_page_row(page_id, lock=True)
    if row["revision"] != expected:
        conn.rollback()
        raise ApiError(409, "Cette page a été modifiée ailleurs. Rechargez avant d'enregistrer.")
    conn.execute(
        """UPDATE atelier_demo_pages
           SET draft = %s, title = %s, revision = revision + 1, updated_at = now()
           WHERE id = %s""",
        (json.dumps(document), document["title"], page_id),
    )
    conn.commit()
    return jsonify(page_detail(get_page_row(page_id)))


@app.post("/api/atelier/<page_id>")
def page_action(page_id: str):
    require_write()
    data = read_body()
    action = data.get("action")
    conn = db()

    if action == "review":
        row = get_page_row(page_id)
        token = seal({
            "page": page_id,
            "revision": row["revision"],
            "hash": doc_hash(row["draft"]),
            "exp": int(time.time()) + TOKEN_TTL_SECONDS,
        })
        return jsonify(token=token, expiresInSeconds=TOKEN_TTL_SECONDS,
                       draft=row["draft"], revision=row["revision"])

    if action == "publish":
        if data.get("confirmed") is not True:
            raise ApiError(400, "Publication non confirmée.")
        claims = unseal(str(data.get("token", "")))
        if not claims or claims.get("page") != page_id or claims.get("exp", 0) < time.time():
            raise ApiError(409, "Jeton de vérification expiré. Vérifiez à nouveau.")
        row = get_page_row(page_id, lock=True)
        if row["revision"] != claims["revision"] or doc_hash(row["draft"]) != claims["hash"]:
            conn.rollback()
            raise ApiError(409, "La page a changé depuis la vérification. Vérifiez à nouveau.")
        if row["published_revision"] == row["revision"]:
            conn.rollback()
            raise ApiError(409, "Cette révision est déjà publiée. Vérifiez à nouveau avant une nouvelle publication.")
        conn.execute(
            """INSERT INTO atelier_demo_versions (id, page_id, revision, document)
               VALUES (%s,%s,%s,%s)""",
            (new_id("ver"), page_id, row["revision"], json.dumps(row["draft"])),
        )
        conn.execute(
            """UPDATE atelier_demo_pages
               SET published = draft, published_revision = revision,
                   status = 'Publié', updated_at = now()
               WHERE id = %s""", (page_id,),
        )
        conn.commit()
        return jsonify(page_detail(get_page_row(page_id)))

    if action == "restore":
        if data.get("confirmed") is not True:
            raise ApiError(400, "Restauration non confirmée.")
        version = conn.execute(
            "SELECT * FROM atelier_demo_versions WHERE id = %s AND page_id = %s",
            (str(data.get("versionId", "")), page_id),
        ).fetchone()
        if version is None:
            raise ApiError(404, "Version introuvable.")
        row = get_page_row(page_id, lock=True)
        if row["published_revision"] != data.get("expectedPublishedRevision"):
            conn.rollback()
            raise ApiError(409, "La publication a changé. Rechargez avant de restaurer.")
        conn.execute(
            """INSERT INTO atelier_demo_versions (id, page_id, revision, document)
               VALUES (%s,%s,%s,%s)""",
            (new_id("ver"), page_id, row["revision"], json.dumps(version["document"])),
        )
        conn.execute(
            """UPDATE atelier_demo_pages
               SET published = %s, published_revision = revision,
                   updated_at = now() WHERE id = %s""",
            (json.dumps(version["document"]), page_id),
        )
        conn.commit()
        return jsonify(page_detail(get_page_row(page_id)))

    if action == "delete":
        if data.get("confirmed") is not True:
            raise ApiError(400, "Suppression non confirmée.")
        row = get_page_row(page_id, lock=True)
        if row["published_revision"]:
            conn.rollback()
            raise ApiError(403, "Une page publiée ne peut pas être supprimée.")
        conn.execute("DELETE FROM atelier_demo_pages WHERE id = %s", (page_id,))
        conn.commit()
        return jsonify(ok=True)

    raise ApiError(400, "Action inconnue.")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=False)
