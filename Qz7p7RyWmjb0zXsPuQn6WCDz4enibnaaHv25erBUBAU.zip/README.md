# Atelier — version Flask (démo, données fictives)

Statut honnête :

| Partie | Statut |
|---|---|
| Serveur Flask, contrat `/api/atelier` (liste, création, lecture, sauvegarde, versions, publication par jeton, restauration, suppression) | fonctionnel (démo) |
| Contrôles de sécurité de base (CSRF, origine, cookie signé, URL sûres, taille du corps) | fonctionnel en démo, pas de production |
| Éditeur `/admin/atelier` : liste des pages, planche, sélection, texte/lien/alt, brouillon, aperçu, formats, comparaison, publication confirmée | fonctionnel (vérifié navigateur 18/18) |
| Inspecteur complet (styles par appareil, calques, historique) | non réalisé |
| Blueprint, tableur, médias, menu mobile | non réalisé |
| Schéma complet des éléments (validation portée depuis `model.ts`) | partiel : contrôle structurel seulement |
| Design | `static/css/globals.css` repris tel quel + `atelier-flask.css` (ajustements) |

Architecture front : `static/js/model.js` (logique pure), `api.js` (appels serveur), `render.js` (planche), `app.js` (contrôleur), `templates/atelier.html`.

## Lancer

```
pip install -r requirements.txt
export ATELIER_DATABASE_URL=postgresql://USER:MOT_DE_PASSE@localhost/BASE
PORT=5055 python atelier_flask/app.py
```
Ouvrir http://127.0.0.1:5055/admin/atelier

Tests (serveur lancé) :
```
python tests/api_check.py        # API : 21 vérifications
node tests/ui_check.mjs          # navigateur : 18 vérifications (Playwright requis)
```

Les 12 pages de démo viennent de `atelier_flask/seed.json`, exporté depuis `src/lib/atelier/seed.ts`.
