# Vérifications de contrat de l API Flask. Lancer le serveur (PORT=5055) puis : python tests/api_check.py
import json, urllib.request, http.cookiejar
B="http://127.0.0.1:5055"
cj=http.cookiejar.CookieJar(); op=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
def call(method, path, body=None, csrf=None, origin=None):
    data=None if body is None else json.dumps(body).encode()
    req=urllib.request.Request(B+path, data=data, method=method)
    if data is not None: req.add_header("Content-Type","application/json")
    if csrf: req.add_header("x-atelier-csrf", csrf)
    if origin: req.add_header("Origin", origin)
    try:
        with op.open(req) as r: return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")
ok=[]
def check(name, cond, extra=""):
    ok.append(cond); print(("PASS" if cond else "FAIL"), name, extra)
s,d=call("GET","/api/atelier"); check("liste 200 + 12 pages", s==200 and len(d["pages"])==12, str(len(d.get("pages",[]))))
csrf=d["csrf"]
pid=next(p["id"] for p in d["pages"] if p["id"]=="accueil")
s,d=call("GET",f"/api/atelier/{pid}"); check("détail", s==200 and "draft" in d and d["revision"]>=1)
rev=d["revision"]; draft=d["draft"]
s,_=call("PUT",f"/api/atelier/{pid}",{"expectedRevision":rev,"document":draft}); check("PUT sans CSRF refusé 403", s==403, str(s))
s,_=call("PUT",f"/api/atelier/{pid}",{"expectedRevision":rev+5,"document":draft},csrf=csrf); check("PUT révision périmée 409", s==409, str(s))
s,_=call("PUT",f"/api/atelier/{pid}",{"expectedRevision":rev,"document":draft},csrf=csrf,origin="https://evil.example"); check("PUT mauvaise origine 403", s==403, str(s))
bad=json.loads(json.dumps(draft)); bad["elements"][0]["href"]="javascript:alert(1)"
s,_=call("PUT",f"/api/atelier/{pid}",{"expectedRevision":rev,"document":bad},csrf=csrf); check("lien javascript: refusé 400", s==400, str(s))
s,d=call("PUT",f"/api/atelier/{pid}",{"expectedRevision":rev,"document":draft},csrf=csrf); check("PUT valide -> révision+1", s==200 and d["revision"]==rev+1, str(s))
rev=d["revision"]
s,d=call("POST",f"/api/atelier/{pid}",{"action":"review"},csrf=csrf); tok=d.get("token"); check("review -> jeton", s==200 and bool(tok))
s,_=call("POST",f"/api/atelier/{pid}",{"action":"publish","token":tok,"confirmed":False},csrf=csrf); check("publication non confirmée 400", s==400, str(s))
s,d=call("POST",f"/api/atelier/{pid}",{"action":"publish","token":tok[:-3]+"abc","confirmed":True},csrf=csrf); check("jeton falsifié 409", s==409, str(s))
s,d=call("POST",f"/api/atelier/{pid}",{"action":"publish","token":tok,"confirmed":True},csrf=csrf); check("publication confirmée", s==200 and d["publishedRevision"]==rev, str(s))
s,d=call("POST",f"/api/atelier/{pid}",{"action":"publish","token":tok,"confirmed":True},csrf=csrf); check("rejeu du jeton refusé (révision inchangée)", s==409, str(s))
s,d=call("GET",f"/api/atelier/{pid}?mode=versions"); vers=d.get("versions",[]); check("versions listées", s==200 and len(vers)>=2, str(len(vers)))
old=vers[-1]["id"]
s,d=call("POST",f"/api/atelier/{pid}",{"action":"restore","versionId":old,"expectedPublishedRevision":999,"confirmed":True},csrf=csrf); check("restauration pub. périmée 409", s==409, str(s))
s,d=call("GET",f"/api/atelier/{pid}"); pr=d["publishedRevision"]
s,d=call("POST",f"/api/atelier/{pid}",{"action":"restore","versionId":old,"expectedPublishedRevision":pr,"confirmed":True},csrf=csrf); check("restauration confirmée", s==200, str(s))
s,d=call("POST",f"/api/atelier/{pid}",{"action":"delete","confirmed":True},csrf=csrf); check("suppression d'une page publiée refusée 403", s==403, str(s))
s,d=call("POST","/api/atelier",{"title":"Essai vide","slug":"/essai-flask","blank":True},csrf=csrf); check("création 201", s==201, str(s))
newid=d.get("id")
s,d=call("POST","/api/atelier",{"title":"Doublon","slug":"/essai-flask"},csrf=csrf); check("adresse en double 409", s==409, str(s))
s,d=call("POST",f"/api/atelier/{newid}",{"action":"delete","confirmed":True},csrf=csrf); check("suppression brouillon 200", s==200, str(s))
s,d=call("GET","/api/atelier/introuvable"); check("absent 404", s==404, str(s))
s,d=call("GET","/api/atelier"); check("publication visible en liste", any(p["id"]==pid and p["publishedRevision"]>=1 for p in d["pages"]))
print(f"\n{sum(ok)}/{len(ok)} vérifications réussies")
