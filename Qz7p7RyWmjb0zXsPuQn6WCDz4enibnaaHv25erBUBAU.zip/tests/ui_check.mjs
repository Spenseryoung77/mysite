// Parcours navigateur de l'éditeur Flask. Lancer avec le serveur sur PORT=5055.
// Usage : node tests/ui_check.mjs   (utilise le Chromium installé pour le projet Next.js)
import { chromium } from "/home/user/atelier/node_modules/playwright/index.mjs";

const BASE = process.env.BASE || "http://127.0.0.1:5055";
const results = [];
const check = (name, cond, extra = "") => {
  results.push(!!cond);
  console.log(`${cond ? "PASS" : "FAIL"} ${name} ${extra}`);
};

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
page.on("dialog", (d) => d.accept()); // confirmation de changement de page

await page.goto(`${BASE}/admin/atelier#accueil`);
await page.waitForSelector("#page-list .page-list-item");
check("12 pages listées", (await page.locator("#page-list .page-list-item").count()) === 12);
await page.waitForSelector("#artboard .pe-heading, #artboard .page-element");
check("planche rendue", (await page.locator("#artboard .page-element").count()) > 0);
check("bouton publier désactivé sans brouillon", await page.isDisabled("#btn-review"));
check("titre en français affiché", (await page.textContent("#page-title")).length > 0);

// Sélection et modification d'un titre
const heading = page.locator("#artboard .pe-heading").first();
await heading.click();
const textField = page.locator('#inspector-body [data-field="text"]');
check("inspecteur ouvert sur l'élément", await textField.isVisible());
const stamp = `Essai ${Date.now() % 100000}`;
await textField.fill(stamp);
check("planche mise à jour", (await heading.textContent()) === stamp);
check("statut non enregistré", (await page.textContent("#save-status")).includes("non enregistrées"));
check("publier reste désactivé avant enregistrement", await page.isDisabled("#btn-review"));

// Lien non sûr refusé dans l'inspecteur
await page.locator("#artboard .pe-button").first().click();
const hrefField = page.locator('#inspector-body [data-field="href"]');
await hrefField.fill("javascript:alert(1)");
check("lien javascript: signalé", (await page.locator('label:has([data-field="href"]) .field-error').textContent()).includes("non autorisée"));
await hrefField.fill("/site/accueil");
check("lien relatif accepté", (await page.locator('label:has([data-field="href"]) .field-error').textContent()) === "");

// Enregistrement du brouillon
await page.click("#btn-save");
await page.waitForFunction(() => document.querySelector("#save-status").textContent.includes("Tout est enregistré"));
check("brouillon enregistré", true);

// Formats responsive
await page.click('[data-device="mobile"]');
const mobileWidth = await page.locator("#artboard").evaluate((n) => n.getBoundingClientRect().width);
check("format mobile 390 px", Math.round(mobileWidth) === 390, `(${Math.round(mobileWidth)})`);
await page.click('[data-device="tablet"]');
await page.click('[data-device="desktop"]');

// Aperçu
await page.click("#btn-preview");
check("aperçu ouvert", await page.locator("#preview-dialog[open]").count() === 1);
await page.click("#preview-close");

// Publication confirmée
await page.click("#btn-review");
await page.waitForSelector("#publish-dialog[open]");
check("comparaison affichée", (await page.locator("#review-summary li").count()) === 5);
check("publication bloquée sans confirmation", await page.isDisabled("#publish-submit"));
await page.check("#publish-confirm");
await page.click("#publish-submit");
await page.waitForFunction(() => document.body.textContent.includes("Page publiée"));
check("publication confirmée", true);
check("bouton publier de nouveau désactivé", await page.isDisabled("#btn-review"));

await page.screenshot({ path: "/tmp/flask-ui.png", fullPage: false });

// Erreurs de script
check("aucune erreur JavaScript", errors.length === 0, errors.join(" | "));

await browser.close();
console.log(`\n${results.filter(Boolean).length}/${results.length} vérifications réussies`);
process.exit(results.every(Boolean) ? 0 : 1);
